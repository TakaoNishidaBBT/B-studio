/*
 Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.addTemplates(
	"default",
	{
		imagesPath:CKEDITOR.config.baseHref + "visualeditor/article1/templates/images/",
		templates:[
			{
				title:"Image at top right, wraparound text",
				image:"template4.gif",
				description:"",
				html:'<div class="textbox-img-right"><img alt="dummy-image" src="files/images/dummy_gray_300x200.png" /> The European languages are members of the same family. Their separate existence is a myth. For science, music, sport, etc, Europe uses the same vocabulary. The languages only differ in their grammar, their pronunciation and their most common words.<br />The European languages are members of the same family. Their separate existence is a myth. For science, music, sport, etc, Europe uses the same vocabulary. The languages only differ in their grammar, their pronunciation and their most common words.<br />The European languages are members of the same family. Their separate existence is a myth. For science, music, sport, etc, Europe uses the same vocabulary. The languages only differ in their grammar, their pronunciation and their most common words.</div>'
			},
			{
				title:"Image at top left, wraparound text",
				image:"template5.gif",
				description:"",
				html:'<div class="textbox-img-left"><img alt="dummy-image" src="files/images/dummy_gray_300x200.png" /> The European languages are members of the same family. Their separate existence is a myth. For science, music, sport, etc, Europe uses the same vocabulary. The languages only differ in their grammar, their pronunciation and their most common words.<br />The European languages are members of the same family. Their separate existence is a myth. For science, music, sport, etc, Europe uses the same vocabulary. The languages only differ in their grammar, their pronunciation and their most common words.<br />The European languages are members of the same family. Their separate existence is a myth. For science, music, sport, etc, Europe uses the same vocabulary. The languages only differ in their grammar, their pronunciation and their most common words.</div>'
			},
		]
	}
);
