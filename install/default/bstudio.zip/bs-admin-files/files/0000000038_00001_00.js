/*
 Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.addTemplates(
	"default",
	{
		imagesPath:CKEDITOR.config.baseHref + "/visualeditor/article3/templates/images/",
		templates:[
			{
				title:"見出し3",
				image:"template1.gif",
				description:"",
				html:'<div class="ttl_h3_box"><h3>見出し3</h3></div>'
			},
			{
				title:"見出し4",
				image:"template1.gif",
				description:"",
				html:'<div class="ttl_h4_box"><h4>見出し4</h4></div>'
			},
		]
	}
);
