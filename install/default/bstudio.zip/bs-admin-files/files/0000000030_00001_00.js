/*
 Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.addTemplates(
	"default",
	{
		imagesPath:CKEDITOR.config.baseHref + "visualeditor/article2/templates/images/",
		templates:[
			{
				title:"Heading 3",
				image:"template1.gif",
				description:"",
				html:'<div class="ttl_h3_box"><h3>Heading 3</h3></div>'
			},
			{
				title:"Heading 4",
				image:"template1.gif",
				description:"",
				html:'<div class="ttl_h4_box"><h4>Heading 4</h4></div>'
			},
		]
	}
);
