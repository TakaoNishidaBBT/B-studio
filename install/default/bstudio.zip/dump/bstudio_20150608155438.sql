-- B-studio dump
--
-- ------------------------------------------------------
-- Server version	5.0.77-community-nt

--
-- Temporary table structure for view `%PREFIX%v_admin_article`
--
DROP TABLE IF EXISTS `%PREFIX%v_admin_article`;
DROP VIEW IF EXISTS `%PREFIX%v_admin_article`;
CREATE TABLE `%PREFIX%v_admin_article` (
  `article_id` char(10),
  `article_date_t` text,
  `article_date_u` text,
  `category_id` char(10),
  `tag` text,
  `publication` char(1),
  `title` text,
  `title_img_file` text,
  `description_flag` char(1),
  `external_link` char(1),
  `external_window` char(1),
  `url` text,
  `description` text,
  `del_flag` char(1),
  `folder_id` text,
  `reserve1` text,
  `reserve2` text,
  `reserve3` text,
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text,
  `article_date` longtext,
  `category` text,
  `color` text,
  `background_color` text,
  `icon_file` text
);

--
-- Temporary table structure for view `%PREFIX%v_admin_article2`
--
DROP TABLE IF EXISTS `%PREFIX%v_admin_article2`;
DROP VIEW IF EXISTS `%PREFIX%v_admin_article2`;
CREATE TABLE `%PREFIX%v_admin_article2` (
  `article_id` char(10),
  `article_date_t` text,
  `article_date_u` text,
  `category_id` char(10),
  `tag` text,
  `publication` char(1),
  `title` text,
  `title_img_file` text,
  `description_flag` char(1),
  `external_link` char(1),
  `external_window` char(1),
  `url` text,
  `description` text,
  `del_flag` char(1),
  `folder_id` text,
  `reserve1` text,
  `reserve2` text,
  `reserve3` text,
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text,
  `article_date` longtext,
  `category` text,
  `color` text,
  `background_color` text,
  `icon_file` text
);

--
-- Temporary table structure for view `%PREFIX%v_admin_article3`
--
DROP TABLE IF EXISTS `%PREFIX%v_admin_article3`;
DROP VIEW IF EXISTS `%PREFIX%v_admin_article3`;
CREATE TABLE `%PREFIX%v_admin_article3` (
  `article_id` char(10),
  `article_date_t` text,
  `article_date_u` text,
  `category_id` char(10),
  `tag` text,
  `publication` char(1),
  `title` text,
  `title_img_file` text,
  `description_flag` char(1),
  `external_link` char(1),
  `external_window` char(1),
  `url` text,
  `description` text,
  `del_flag` char(1),
  `folder_id` text,
  `reserve1` text,
  `reserve2` text,
  `reserve3` text,
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text,
  `article_date` longtext,
  `category` text,
  `color` text,
  `background_color` text,
  `icon_file` text
);

--
-- Temporary table structure for view `%PREFIX%v_article`
--
DROP TABLE IF EXISTS `%PREFIX%v_article`;
DROP VIEW IF EXISTS `%PREFIX%v_article`;
CREATE TABLE `%PREFIX%v_article` (
  `article_id` char(10),
  `article_date_t` text,
  `article_date_u` text,
  `category_id` char(10),
  `tag` text,
  `publication` char(1),
  `title` text,
  `title_img_file` text,
  `description_flag` char(1),
  `external_link` char(1),
  `external_window` char(1),
  `url` text,
  `description` text,
  `del_flag` char(1),
  `folder_id` text,
  `reserve1` text,
  `reserve2` text,
  `reserve3` text,
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text,
  `article_date` longtext,
  `category` text,
  `color` text,
  `background_color` text,
  `icon_file` text
);

--
-- Temporary table structure for view `%PREFIX%v_article2`
--
DROP TABLE IF EXISTS `%PREFIX%v_article2`;
DROP VIEW IF EXISTS `%PREFIX%v_article2`;
CREATE TABLE `%PREFIX%v_article2` (
  `article_id` char(10),
  `article_date_t` text,
  `article_date_u` text,
  `category_id` char(10),
  `tag` text,
  `publication` char(1),
  `title` text,
  `title_img_file` text,
  `description_flag` char(1),
  `external_link` char(1),
  `external_window` char(1),
  `url` text,
  `description` text,
  `del_flag` char(1),
  `folder_id` text,
  `reserve1` text,
  `reserve2` text,
  `reserve3` text,
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text,
  `article_date` longtext,
  `category` text,
  `color` text,
  `background_color` text,
  `icon_file` text
);

--
-- Temporary table structure for view `%PREFIX%v_article3`
--
DROP TABLE IF EXISTS `%PREFIX%v_article3`;
DROP VIEW IF EXISTS `%PREFIX%v_article3`;
CREATE TABLE `%PREFIX%v_article3` (
  `article_id` char(10),
  `article_date_t` text,
  `article_date_u` text,
  `category_id` char(10),
  `tag` text,
  `publication` char(1),
  `title` text,
  `title_img_file` text,
  `description_flag` char(1),
  `external_link` char(1),
  `external_window` char(1),
  `url` text,
  `description` text,
  `del_flag` char(1),
  `folder_id` text,
  `reserve1` text,
  `reserve2` text,
  `reserve3` text,
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text,
  `article_date` longtext,
  `category` text,
  `color` text,
  `background_color` text,
  `icon_file` text
);

--
-- Temporary table structure for view `%PREFIX%v_c_contents`
--
DROP TABLE IF EXISTS `%PREFIX%v_c_contents`;
DROP VIEW IF EXISTS `%PREFIX%v_c_contents`;
CREATE TABLE `%PREFIX%v_c_contents` (
  `version_id` char(5),
  `revision_id` char(2),
  `contents_id` char(10),
  `contents_date` char(10),
  `template_id` char(10),
  `title` text,
  `breadcrumbs` text,
  `html1` mediumtext,
  `html2` text,
  `html3` text,
  `html4` text,
  `css` mediumtext,
  `php` mediumtext,
  `keywords` text,
  `description` text,
  `external_css` text,
  `external_js` text,
  `header_element` text,
  `del_flag` char(1),
  `reserve1` text,
  `reserve2` text,
  `reserve3` text,
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text
);

--
-- Temporary table structure for view `%PREFIX%v_c_contents_node`
--
DROP TABLE IF EXISTS `%PREFIX%v_c_contents_node`;
DROP VIEW IF EXISTS `%PREFIX%v_c_contents_node`;
CREATE TABLE `%PREFIX%v_c_contents_node` (
  `version_id` char(5),
  `revision_id` char(2),
  `node_id` char(10),
  `parent_node` char(10),
  `node_type` char(10),
  `node_class` char(10),
  `node_name` text,
  `contents_id` char(10),
  `disp_seq` int(11),
  `del_flag` char(1),
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text
);

--
-- Temporary table structure for view `%PREFIX%v_c_resource_node`
--
DROP TABLE IF EXISTS `%PREFIX%v_c_resource_node`;
DROP VIEW IF EXISTS `%PREFIX%v_c_resource_node`;
CREATE TABLE `%PREFIX%v_c_resource_node` (
  `version_id` char(5),
  `revision_id` char(2),
  `node_id` char(10),
  `parent_node` char(10),
  `node_type` char(10),
  `node_class` char(10),
  `node_name` text,
  `file_size` int(11),
  `human_file_size` text,
  `image_size` int(11),
  `human_image_size` text,
  `contents_id` char(19),
  `disp_seq` int(11),
  `del_flag` char(1),
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text
);

--
-- Temporary table structure for view `%PREFIX%v_c_template`
--
DROP TABLE IF EXISTS `%PREFIX%v_c_template`;
DROP VIEW IF EXISTS `%PREFIX%v_c_template`;
CREATE TABLE `%PREFIX%v_c_template` (
  `version_id` char(5),
  `revision_id` char(2),
  `contents_id` char(10),
  `contents_date` char(10),
  `template_id` char(10),
  `start_html` mediumtext,
  `end_html` mediumtext,
  `css` mediumtext,
  `php` mediumtext,
  `external_css` text,
  `external_js` text,
  `header_element` text,
  `del_flag` char(1),
  `reserve1` text,
  `reserve2` text,
  `reserve3` text,
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text
);

--
-- Temporary table structure for view `%PREFIX%v_c_template_node`
--
DROP TABLE IF EXISTS `%PREFIX%v_c_template_node`;
DROP VIEW IF EXISTS `%PREFIX%v_c_template_node`;
CREATE TABLE `%PREFIX%v_c_template_node` (
  `version_id` char(5),
  `revision_id` char(2),
  `node_id` char(10),
  `parent_node` char(10),
  `node_type` char(10),
  `node_class` char(10),
  `node_name` text,
  `contents_id` char(10),
  `disp_seq` int(11),
  `del_flag` char(1),
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text
);

--
-- Temporary table structure for view `%PREFIX%v_c_widget`
--
DROP TABLE IF EXISTS `%PREFIX%v_c_widget`;
DROP VIEW IF EXISTS `%PREFIX%v_c_widget`;
CREATE TABLE `%PREFIX%v_c_widget` (
  `version_id` char(5),
  `revision_id` char(2),
  `contents_id` char(10),
  `contents_date` char(10),
  `widget_id` char(10),
  `html` text,
  `css` text,
  `php` text,
  `del_flag` char(1),
  `reserve1` text,
  `reserve2` text,
  `reserve3` text,
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text
);

--
-- Temporary table structure for view `%PREFIX%v_c_widget_node`
--
DROP TABLE IF EXISTS `%PREFIX%v_c_widget_node`;
DROP VIEW IF EXISTS `%PREFIX%v_c_widget_node`;
CREATE TABLE `%PREFIX%v_c_widget_node` (
  `version_id` char(5),
  `revision_id` char(2),
  `node_id` char(10),
  `parent_node` char(10),
  `node_type` char(10),
  `node_class` char(10),
  `node_name` text,
  `contents_id` char(10),
  `disp_seq` int(11),
  `del_flag` char(1),
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text
);

--
-- Temporary table structure for view `%PREFIX%v_category`
--
DROP TABLE IF EXISTS `%PREFIX%v_category`;
DROP VIEW IF EXISTS `%PREFIX%v_category`;
CREATE TABLE `%PREFIX%v_category` (
  `node_id` char(10),
  `parent_node` char(10),
  `node_type` char(10),
  `node_class` char(10),
  `node_name` text,
  `disp_seq` int(11),
  `color` text,
  `background_color` text,
  `icon_file` text,
  `del_flag` char(1),
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text
);

--
-- Temporary table structure for view `%PREFIX%v_category2`
--
DROP TABLE IF EXISTS `%PREFIX%v_category2`;
DROP VIEW IF EXISTS `%PREFIX%v_category2`;
CREATE TABLE `%PREFIX%v_category2` (
  `node_id` char(10),
  `parent_node` char(10),
  `node_type` char(10),
  `node_class` char(10),
  `node_name` text,
  `disp_seq` int(11),
  `color` text,
  `background_color` text,
  `icon_file` text,
  `del_flag` char(1),
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text
);

--
-- Temporary table structure for view `%PREFIX%v_category3`
--
DROP TABLE IF EXISTS `%PREFIX%v_category3`;
DROP VIEW IF EXISTS `%PREFIX%v_category3`;
CREATE TABLE `%PREFIX%v_category3` (
  `node_id` char(10),
  `parent_node` char(10),
  `node_type` char(10),
  `node_class` char(10),
  `node_name` text,
  `disp_seq` int(11),
  `color` text,
  `background_color` text,
  `icon_file` text,
  `del_flag` char(1),
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text
);

--
-- Temporary table structure for view `%PREFIX%v_compare_contents_node`
--
DROP TABLE IF EXISTS `%PREFIX%v_compare_contents_node`;
DROP VIEW IF EXISTS `%PREFIX%v_compare_contents_node`;
CREATE TABLE `%PREFIX%v_compare_contents_node` (
  `version_id` char(5),
  `revision_id` char(2),
  `node_id` char(10),
  `parent_node` char(10),
  `node_type` char(10),
  `node_class` char(10),
  `node_name` text,
  `contents_id` char(10),
  `disp_seq` int(11),
  `del_flag` char(1),
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text
);

--
-- Temporary table structure for view `%PREFIX%v_compare_resource_node`
--
DROP TABLE IF EXISTS `%PREFIX%v_compare_resource_node`;
DROP VIEW IF EXISTS `%PREFIX%v_compare_resource_node`;
CREATE TABLE `%PREFIX%v_compare_resource_node` (
  `version_id` char(5),
  `revision_id` char(2),
  `node_id` char(10),
  `parent_node` char(10),
  `node_type` char(10),
  `node_class` char(10),
  `node_name` text,
  `contents_id` char(19),
  `disp_seq` int(11),
  `del_flag` char(1),
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text
);

--
-- Temporary table structure for view `%PREFIX%v_compare_template_node`
--
DROP TABLE IF EXISTS `%PREFIX%v_compare_template_node`;
DROP VIEW IF EXISTS `%PREFIX%v_compare_template_node`;
CREATE TABLE `%PREFIX%v_compare_template_node` (
  `version_id` char(5),
  `revision_id` char(2),
  `node_id` char(10),
  `parent_node` char(10),
  `node_type` char(10),
  `node_class` char(10),
  `node_name` text,
  `contents_id` char(10),
  `disp_seq` int(11),
  `del_flag` char(1),
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text
);

--
-- Temporary table structure for view `%PREFIX%v_compare_widget_node`
--
DROP TABLE IF EXISTS `%PREFIX%v_compare_widget_node`;
DROP VIEW IF EXISTS `%PREFIX%v_compare_widget_node`;
CREATE TABLE `%PREFIX%v_compare_widget_node` (
  `version_id` char(5),
  `revision_id` char(2),
  `node_id` char(10),
  `parent_node` char(10),
  `node_type` char(10),
  `node_class` char(10),
  `node_name` text,
  `contents_id` char(10),
  `disp_seq` int(11),
  `del_flag` char(1),
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text
);

--
-- Temporary table structure for view `%PREFIX%v_current_version`
--
DROP TABLE IF EXISTS `%PREFIX%v_current_version`;
DROP VIEW IF EXISTS `%PREFIX%v_current_version`;
CREATE TABLE `%PREFIX%v_current_version` (
  `reserved_version_id` char(5),
  `publication_datetime_u` text,
  `current_version_id` varchar(5),
  `current_version` longtext,
  `working_version_id` char(5),
  `working_version` text,
  `revision_id` char(2)
);

--
-- Temporary table structure for view `%PREFIX%v_w_contents`
--
DROP TABLE IF EXISTS `%PREFIX%v_w_contents`;
DROP VIEW IF EXISTS `%PREFIX%v_w_contents`;
CREATE TABLE `%PREFIX%v_w_contents` (
  `version_id` char(5),
  `revision_id` char(2),
  `contents_id` char(10),
  `contents_date` char(10),
  `template_id` char(10),
  `title` text,
  `breadcrumbs` text,
  `html1` mediumtext,
  `html2` text,
  `html3` text,
  `html4` text,
  `css` mediumtext,
  `php` mediumtext,
  `keywords` text,
  `description` text,
  `external_css` text,
  `external_js` text,
  `header_element` text,
  `del_flag` char(1),
  `reserve1` text,
  `reserve2` text,
  `reserve3` text,
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text
);

--
-- Temporary table structure for view `%PREFIX%v_w_contents_node`
--
DROP TABLE IF EXISTS `%PREFIX%v_w_contents_node`;
DROP VIEW IF EXISTS `%PREFIX%v_w_contents_node`;
CREATE TABLE `%PREFIX%v_w_contents_node` (
  `version_id` char(5),
  `revision_id` char(2),
  `node_id` char(10),
  `parent_node` char(10),
  `node_type` char(10),
  `node_class` char(10),
  `node_name` text,
  `contents_id` char(10),
  `disp_seq` int(11),
  `del_flag` char(1),
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text
);

--
-- Temporary table structure for view `%PREFIX%v_w_resource_node`
--
DROP TABLE IF EXISTS `%PREFIX%v_w_resource_node`;
DROP VIEW IF EXISTS `%PREFIX%v_w_resource_node`;
CREATE TABLE `%PREFIX%v_w_resource_node` (
  `version_id` char(5),
  `revision_id` char(2),
  `node_id` char(10),
  `parent_node` char(10),
  `node_type` char(10),
  `node_class` char(10),
  `node_name` text,
  `file_size` int(11),
  `human_file_size` text,
  `image_size` int(11),
  `human_image_size` text,
  `contents_id` char(19),
  `disp_seq` int(11),
  `del_flag` char(1),
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text
);

--
-- Temporary table structure for view `%PREFIX%v_w_template`
--
DROP TABLE IF EXISTS `%PREFIX%v_w_template`;
DROP VIEW IF EXISTS `%PREFIX%v_w_template`;
CREATE TABLE `%PREFIX%v_w_template` (
  `version_id` char(5),
  `revision_id` char(2),
  `contents_id` char(10),
  `contents_date` char(10),
  `template_id` char(10),
  `start_html` mediumtext,
  `end_html` mediumtext,
  `css` mediumtext,
  `php` mediumtext,
  `external_css` text,
  `external_js` text,
  `header_element` text,
  `del_flag` char(1),
  `reserve1` text,
  `reserve2` text,
  `reserve3` text,
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text
);

--
-- Temporary table structure for view `%PREFIX%v_w_template_node`
--
DROP TABLE IF EXISTS `%PREFIX%v_w_template_node`;
DROP VIEW IF EXISTS `%PREFIX%v_w_template_node`;
CREATE TABLE `%PREFIX%v_w_template_node` (
  `version_id` char(5),
  `revision_id` char(2),
  `node_id` char(10),
  `parent_node` char(10),
  `node_type` char(10),
  `node_class` char(10),
  `node_name` text,
  `contents_id` char(10),
  `disp_seq` int(11),
  `del_flag` char(1),
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text
);

--
-- Temporary table structure for view `%PREFIX%v_w_widget`
--
DROP TABLE IF EXISTS `%PREFIX%v_w_widget`;
DROP VIEW IF EXISTS `%PREFIX%v_w_widget`;
CREATE TABLE `%PREFIX%v_w_widget` (
  `version_id` char(5),
  `revision_id` char(2),
  `contents_id` char(10),
  `contents_date` char(10),
  `widget_id` char(10),
  `html` text,
  `css` text,
  `php` text,
  `del_flag` char(1),
  `reserve1` text,
  `reserve2` text,
  `reserve3` text,
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text
);

--
-- Temporary table structure for view `%PREFIX%v_w_widget_node`
--
DROP TABLE IF EXISTS `%PREFIX%v_w_widget_node`;
DROP VIEW IF EXISTS `%PREFIX%v_w_widget_node`;
CREATE TABLE `%PREFIX%v_w_widget_node` (
  `version_id` char(5),
  `revision_id` char(2),
  `node_id` char(10),
  `parent_node` char(10),
  `node_type` char(10),
  `node_class` char(10),
  `node_name` text,
  `contents_id` char(10),
  `disp_seq` int(11),
  `del_flag` char(1),
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text
);

--
-- Definition of table `%PREFIX%article`
--

DROP TABLE IF EXISTS `%PREFIX%article`;
CREATE TABLE `%PREFIX%article` (
  `article_id` char(10) NOT NULL default '',
  `article_date_t` text,
  `article_date_u` text,
  `category_id` char(10) default NULL,
  `tag` text,
  `publication` char(1) default NULL,
  `title` text,
  `title_img_file` text,
  `description_flag` char(1) default NULL,
  `external_link` char(1) default NULL,
  `external_window` char(1) default NULL,
  `url` text,
  `description` text,
  `del_flag` char(1) default NULL,
  `folder_id` text,
  `reserve1` text,
  `reserve2` text,
  `reserve3` text,
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text,
  PRIMARY KEY  (`article_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `%PREFIX%article`
--

/*!40000 ALTER TABLE `%PREFIX%article` DISABLE KEYS */;
INSERT INTO `%PREFIX%article` (`article_id`,`article_date_t`,`article_date_u`,`category_id`,`tag`,`publication`,`title`,`title_img_file`,`description_flag`,`external_link`,`external_window`,`url`,`description`,`del_flag`,`folder_id`,`reserve1`,`reserve2`,`reserve3`,`create_user`,`create_datetime`,`update_user`,`update_datetime`) VALUES 
 ('0000000001','2014/02/23','1393081200','0000000001','','1','This is 1st NEWS','','1','','','','','0','','','','','admin','1393122822','admin','1393126124'),
 ('0000000002','2014/02/11','1392044400','0000000002','','1','This is 1st TOPICS','','1','','','','','0','','','','','admin','1393125934','admin','1393126086'),
 ('0000000003','2014/03/12','1394550000','0000000002','','1','This is 2nd NEWS','','1','','','','','0','','','','','admin','1393130010','admin','1413969365'),
 ('0000000004','2014/02/20','1392822000','0000000001','','1','Tshi is 2nd TOPICS','','1','','','','','0','','','','','admin','1393130036','admin','1413969373'),
 ('0000000005','2014/04/01','1396278000','0000000003','','2','This is 3rd NEWS','','1','','','','<p>\r\n	<img alt=\"dummy-image\" src=\"files/images/dummy_gray_300x200.png\" style=\"width: 300px; height: 200px; float: right; margin-left: 40px; margin-bottom: 30px\" />The European languages are members of the same family. Their separate existence is a myth. For science, music, sport, etc, Europe uses the same vocabulary. The languages only differ in their grammar, their pronunciation and their most common words.\r\n</p>\r\n\r\n<p>\r\n	Everyone realizes why a new common language would be desirable: one could refuse to pay expensive translators. To achieve this, it would be necessary to have uniform grammar, pronunciation and more common words.\r\n</p>\r\n\r\n<p>\r\n	If several languages coalesce, the grammar of the resulting language is more simple and regular than that of the individual languages. The new common language will be more simple and regular than the existing European languages.\r\n</p>\r\n\r\n<p>\r\n	It will be as simple as Occidental; in fact, it will be Occidental. To an English person, it will seem like simplified English, as a skeptical Cambridge friend of mine told me what Occidental is. The European languages are members of the same family.\r\n</p>\r\n\r\n<p>\r\n	Their separate existence is a myth. For science, music, sport, etc, Europe uses the same vocabulary. The languages only differ in their grammar, their pronunciation and their most common words.\r\n</p>\r\n\r\n<p>\r\n	Everyone realizes why a new common language would be desirable: one could refuse to pay expensive translators. To achieve this, it would be necessary to have uniform grammar, pronunciation and more common words.\r\n</p>\r\n\r\n<p>\r\n	If several languages coalesce, the grammar of the resulting language is more simple and regular than that of the individual languages. The new common language will be more simple and regular than the existing European languages.\r\n</p>\r\n\r\n<p>\r\n	It will be as simple as Occidental; in fact, it will be Occidental. To an English person, it will seem like simplified English, as a skeptical Cambridge friend of mine told me what Occidental is. The European languages are members of the same family.\r\n</p>\r\n\r\n<p>\r\n	Their separate existence is a myth. For science, music, sport, etc, Europe uses the same vocabulary. The languages only differ in their grammar, their pronunciation and their most common words.\r\n</p>\r\n','0','','','','','admin','1393130246','admin','1432798151'),
 ('0000000006','2014/05/21','1400598000','0000000001','','2','This is 4th NEWS','','1','','','','<div class=\"textbox-img-left\">\r\n	<img alt=\"dummy-image\" src=\"files/images/dummy_gray_300x200.png\" /> The European languages are members of the same family. Their separate existence is a myth. For science, music, sport, etc, Europe uses the same vocabulary. The languages only differ in their grammar, their pronunciation and their most common words.<br />\r\n	The European languages are members of the same family. Their separate existence is a myth. For science, music, sport, etc, Europe uses the same vocabulary. The languages only differ in their grammar, their pronunciation and their most common words.<br />\r\n	The European languages are members of the same family. Their separate existence is a myth. For science, music, sport, etc, Europe uses the same vocabulary. The languages only differ in their grammar, their pronunciation and their most common words.\r\n</div>\r\n','0','','','','','admin','1400656390','admin','1432197065');
/*!40000 ALTER TABLE `%PREFIX%article` ENABLE KEYS */;


--
-- Definition of table `%PREFIX%article2`
--

DROP TABLE IF EXISTS `%PREFIX%article2`;
CREATE TABLE `%PREFIX%article2` (
  `article_id` char(10) NOT NULL default '',
  `article_date_t` text,
  `article_date_u` text,
  `category_id` char(10) default NULL,
  `tag` text,
  `publication` char(1) default NULL,
  `title` text,
  `title_img_file` text,
  `description_flag` char(1) default NULL,
  `external_link` char(1) default NULL,
  `external_window` char(1) default NULL,
  `url` text,
  `description` text,
  `del_flag` char(1) default NULL,
  `folder_id` text,
  `reserve1` text,
  `reserve2` text,
  `reserve3` text,
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text,
  PRIMARY KEY  (`article_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `%PREFIX%article2`
--

/*!40000 ALTER TABLE `%PREFIX%article2` DISABLE KEYS */;
/*!40000 ALTER TABLE `%PREFIX%article2` ENABLE KEYS */;


--
-- Definition of table `%PREFIX%article3`
--

DROP TABLE IF EXISTS `%PREFIX%article3`;
CREATE TABLE `%PREFIX%article3` (
  `article_id` char(10) NOT NULL default '',
  `article_date_t` text,
  `article_date_u` text,
  `category_id` char(10) default NULL,
  `tag` text,
  `publication` char(1) default NULL,
  `title` text,
  `title_img_file` text,
  `description_flag` char(1) default NULL,
  `external_link` char(1) default NULL,
  `external_window` char(1) default NULL,
  `url` text,
  `description` text,
  `del_flag` char(1) default NULL,
  `folder_id` text,
  `reserve1` text,
  `reserve2` text,
  `reserve3` text,
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text,
  PRIMARY KEY  (`article_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `%PREFIX%article3`
--

/*!40000 ALTER TABLE `%PREFIX%article3` DISABLE KEYS */;
/*!40000 ALTER TABLE `%PREFIX%article3` ENABLE KEYS */;


--
-- Definition of table `%PREFIX%category`
--

DROP TABLE IF EXISTS `%PREFIX%category`;
CREATE TABLE `%PREFIX%category` (
  `node_id` char(10) NOT NULL default '',
  `parent_node` char(10) default NULL,
  `node_type` char(10) default NULL,
  `node_class` char(10) default NULL,
  `node_name` text,
  `disp_seq` int(11) default NULL,
  `color` text,
  `background_color` text,
  `icon_file` text,
  `del_flag` char(1) default NULL,
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text,
  PRIMARY KEY  (`node_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `%PREFIX%category`
--

/*!40000 ALTER TABLE `%PREFIX%category` DISABLE KEYS */;
INSERT INTO `%PREFIX%category` (`node_id`,`parent_node`,`node_type`,`node_class`,`node_name`,`disp_seq`,`color`,`background_color`,`icon_file`,`del_flag`,`create_user`,`create_datetime`,`update_user`,`update_datetime`) VALUES 
 ('0000000001','root','category','category','event','0','#fff','#999','','0','admin','1393122783','admin','1416550937'),
 ('0000000002','root','category','category','topics','1','#fff','#999','','0','admin','1393125897','admin','1413969419'),
 ('0000000003','root','category','category','release','2','#fff','#999','','0','admin','1413967239','admin','1413969429'),
 ('0000000004','root','category','category','test','3',NULL,'#00ff00','','1','admin','1413967329','admin','1413967344');
/*!40000 ALTER TABLE `%PREFIX%category` ENABLE KEYS */;


--
-- Definition of table `%PREFIX%category2`
--

DROP TABLE IF EXISTS `%PREFIX%category2`;
CREATE TABLE `%PREFIX%category2` (
  `node_id` char(10) NOT NULL default '',
  `parent_node` char(10) default NULL,
  `node_type` char(10) default NULL,
  `node_class` char(10) default NULL,
  `node_name` text,
  `disp_seq` int(11) default NULL,
  `color` text,
  `background_color` text,
  `icon_file` text,
  `del_flag` char(1) default NULL,
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text,
  PRIMARY KEY  (`node_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `%PREFIX%category2`
--

/*!40000 ALTER TABLE `%PREFIX%category2` DISABLE KEYS */;
/*!40000 ALTER TABLE `%PREFIX%category2` ENABLE KEYS */;


--
-- Definition of table `%PREFIX%category3`
--

DROP TABLE IF EXISTS `%PREFIX%category3`;
CREATE TABLE `%PREFIX%category3` (
  `node_id` char(10) NOT NULL default '',
  `parent_node` char(10) default NULL,
  `node_type` char(10) default NULL,
  `node_class` char(10) default NULL,
  `node_name` text,
  `disp_seq` int(11) default NULL,
  `color` text,
  `background_color` text,
  `icon_file` text,
  `del_flag` char(1) default NULL,
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text,
  PRIMARY KEY  (`node_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `%PREFIX%category3`
--

/*!40000 ALTER TABLE `%PREFIX%category3` DISABLE KEYS */;
/*!40000 ALTER TABLE `%PREFIX%category3` ENABLE KEYS */;


--
-- Definition of table `%PREFIX%compare_version`
--

DROP TABLE IF EXISTS `%PREFIX%compare_version`;
CREATE TABLE `%PREFIX%compare_version` (
  `compare_version_id` char(5) NOT NULL default '',
  PRIMARY KEY  (`compare_version_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `%PREFIX%compare_version`
--

/*!40000 ALTER TABLE `%PREFIX%compare_version` DISABLE KEYS */;
INSERT INTO `%PREFIX%compare_version` (`compare_version_id`) VALUES 
 ('00008');
/*!40000 ALTER TABLE `%PREFIX%compare_version` ENABLE KEYS */;


--
-- Definition of table `%PREFIX%contents`
--

DROP TABLE IF EXISTS `%PREFIX%contents`;
CREATE TABLE `%PREFIX%contents` (
  `version_id` char(5) NOT NULL default '',
  `revision_id` char(2) NOT NULL default '',
  `contents_id` char(10) NOT NULL default '',
  `contents_date` char(10) default NULL,
  `template_id` char(10) default NULL,
  `title` text,
  `breadcrumbs` text,
  `html1` mediumtext,
  `html2` text,
  `html3` text,
  `html4` text,
  `css` mediumtext,
  `php` mediumtext,
  `keywords` text,
  `description` text,
  `external_css` text,
  `external_js` text,
  `header_element` text,
  `del_flag` char(1) default NULL,
  `reserve1` text,
  `reserve2` text,
  `reserve3` text,
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text,
  PRIMARY KEY  (`version_id`,`revision_id`,`contents_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `%PREFIX%contents`
--

/*!40000 ALTER TABLE `%PREFIX%contents` DISABLE KEYS */;
INSERT INTO `%PREFIX%contents` (`version_id`,`revision_id`,`contents_id`,`contents_date`,`template_id`,`title`,`breadcrumbs`,`html1`,`html2`,`html3`,`html4`,`css`,`php`,`keywords`,`description`,`external_css`,`external_js`,`header_element`,`del_flag`,`reserve1`,`reserve2`,`reserve3`,`create_user`,`create_datetime`,`update_user`,`update_datetime`) VALUES 
 ('00001','00','0000000001','','0000000001','site title','','<div class=\"main-image\">\r\n	<img alt=\"main-image\" src=\"images/main-image.png\" />\r\n</div>\r\n\r\n<div class=\"main-contents\">\r\n	<div id=\"title\">\r\n		<h1>TITLE</h1>\r\n\r\n		<p>\r\n			one morning, when Gregor Samsa woke from troubled dreams, he found himself transformed in his bed into a horrible vermin. He lay on his armour-like back, and if he lifted his head a little he could see his brown belly, slightly domed and divided by arches into stiff sections. The bedding was hardly able to cover it and ......\r\n		</p>\r\n	</div>\r\n\r\n	<div class=\"clearfix\" id=\"headline\">\r\n		<div id=\"news\">\r\n			<h2>NEWS &amp; TOPICS</h2>\r\n			<?php widget(\'0000000002\'); // news_top ?>\r\n		</div>\r\n\r\n		<div id=\"special-feature\">\r\n			<h2>SPECIAL FEATURES</h2>\r\n\r\n			<div class=\"special-feature\">\r\n				<div class=\"header\">\r\n					TITLE\r\n				</div>\r\n\r\n				<div class=\"image\">\r\n					<img alt=\"dummy\" src=\"images/dummy_gray_300x200.png\" />\r\n				</div>\r\n\r\n				<div class=\"message\">\r\n					Doing business like this takes much more effort than doing your own ...\r\n				</div>\r\n			</div>\r\n		</div>\r\n	</div>\r\n\r\n	<div id=\"features\">\r\n		<h2>FEATURES</h2>\r\n\r\n		<div class=\"features\">\r\n			<ul class=\"clearfix\">\r\n				<li>\r\n					<a href=\"features\">\r\n						<div class=\"header\">\r\n							<h3>TITLE</h3>\r\n						</div>\r\n\r\n						<div class=\"image\">\r\n							<img alt=\"dummy\" src=\"images/dummy_gray_300x200.png\" />\r\n						</div>\r\n\r\n						<div class=\"message\">\r\n							&quot;What&#39;s happened to me?&quot; he thought.\r\n						</div>\r\n						</a>\r\n				</li>\r\n				<li>\r\n					<a href=\"features\">\r\n						<div class=\"header\">\r\n							<h3>TITLE</h3>\r\n						</div>\r\n\r\n						<div class=\"image\">\r\n							<img alt=\"dummy\" src=\"images/dummy_gray_300x200.png\" />\r\n						</div>\r\n\r\n						<div class=\"message\">\r\n							It wasn&#39;t a dream. His room, a proper human room although a little too small, lay peacefully between its four familiar walls.\r\n						</div>\r\n						</a>\r\n				</li>\r\n				<li>\r\n					<a href=\"features\">\r\n						<div class=\"header\">\r\n							<h3>TITLE</h3>\r\n						</div>\r\n\r\n						<div class=\"image\">\r\n							<img alt=\"dummy\" src=\"images/dummy_gray_300x200.png\" />\r\n						</div>\r\n\r\n						<div class=\"message\">\r\n							A collection of textile samples lay spread out on the table - Samsa was a travelling salesman - and above it there hung ...\r\n						</div>\r\n						</a>\r\n				</li>\r\n				<li>\r\n					<a href=\"features\">\r\n						<div class=\"header\">\r\n							<h3>TITLE</h3>\r\n						</div>\r\n\r\n						<div class=\"image\">\r\n							<img alt=\"dummy\" src=\"images/dummy_gray_300x200.png\" />\r\n						</div>\r\n\r\n						<div class=\"message\">\r\n							It showed a lady fitted out with a fur hat and fur boa who sat upright, raising a heavy fur muff that covered the whole of her lower arm ...\r\n						</div>\r\n						</a>\r\n				</li>\r\n			</ul>\r\n\r\n			<ul class=\"clearfix\">\r\n				<li>\r\n					<a href=\"features\">\r\n						<div class=\"header\">\r\n							<h3>TITLE</h3>\r\n						</div>\r\n\r\n						<div class=\"image\">\r\n							<img alt=\"dummy\" src=\"images/dummy_gray_300x200.png\" />\r\n						</div>\r\n\r\n						<div class=\"message\">\r\n							Drops of rain could be heard hitting the pane, which made him feel quite sad.\r\n						</div>\r\n						</a>\r\n				</li>\r\n				<li>\r\n					<a href=\"features\">\r\n						<div class=\"header\">\r\n							<h3>TITLE</h3>\r\n						</div>\r\n\r\n						<div class=\"image\">\r\n							<img alt=\"dummy\" src=\"images/dummy_gray_300x200.png\" />\r\n						</div>\r\n\r\n						<div class=\"message\">\r\n							&quot;How about if I sleep a little bit longer and forget all this nonsense&quot;, he thought, but that was something he was unable to do because...\r\n						</div>\r\n						</a>\r\n				</li>\r\n				<li>\r\n					<a href=\"features\">\r\n						<div class=\"header\">\r\n							<h3>TITLE</h3>\r\n						</div>\r\n\r\n						<div class=\"image\">\r\n							<img alt=\"dummy\" src=\"images/dummy_gray_300x200.png\" />\r\n						</div>\r\n\r\n						<div class=\"message\">\r\n							However hard he threw himself onto his right, he always rolled back to where he was.\r\n						</div>\r\n						</a>\r\n				</li>\r\n				<li>\r\n					<a href=\"features\">\r\n						<div class=\"header\">\r\n							<h3>TITLE</h3>\r\n						</div>\r\n\r\n						<div class=\"image\">\r\n							<img alt=\"dummy\" src=\"images/dummy_gray_300x200.png\" />\r\n						</div>\r\n\r\n						<div class=\"message\">\r\n							He must have tried it a hundred times, shut his eyes so that he wouldn&#39;t have to look at the floundering legs, and only stopped when ...\r\n						</div>\r\n						</a>\r\n				</li>\r\n			</ul>\r\n		</div>\r\n	</div>\r\n</div>\r\n','','','','.main-image {\r\n	padding: 30px 0;\r\n	text-align: center;\r\n	border-bottom: 1px solid #999;\r\n}\r\n.main-contents {\r\n	padding-bottom: 60px;\r\n}\r\n.main-contents p {\r\n	padding: 4px 20px;\r\n}\r\n#title {\r\n	padding: 0 10px;\r\n}\r\n#headline {\r\n	margin-bottom: 40px;\r\n	padding: 0 10px 40px 10px;\r\n	border-bottom: 1px solid #999;\r\n}\r\n#news {\r\n	width: 570px;\r\n	float: left;\r\n}\r\n#special-feature {\r\n	width: 370px;\r\n	float: right;\r\n}\r\n.special-feature {\r\n	border: 1px solid #999;\r\n}\r\n#features {\r\n	padding: 0 10px;\r\n}\r\n.features ul {\r\n	margin: 0;\r\n	padding: 20px 0;\r\n	list-style: none;\r\n	height: 375px;\r\n}\r\n.features ul li {\r\n	float: left;\r\n	margin-left: 17px;\r\n	border: 1px solid #999;\r\n	width: 230px;\r\n	height: 100%;\r\n}\r\n.features ul li:first-child {\r\n	margin-left: 0;\r\n}\r\n.features ul li a:link,\r\n.features ul li a:visited {\r\n	display: block;\r\n	height: 100%;\r\n}\r\n\r\n.special-feature .header,\r\n.features .header {\r\n	padding: 8px 12px;\r\n	border-bottom: 1px solid #999;\r\n}\r\n.special-feature .image,\r\n.features .image {\r\n	text-align: center;\r\n	padding: 12px 0 12px 0;\r\n}\r\n.special-feature .image img {\r\n	width: 60%;\r\n}\r\n.features .image img {\r\n	width: 90%;\r\n}\r\n.special-feature .message,\r\n.features .message {\r\n	border-top: 1px solid #999;\r\n	padding: 4px 12px;\r\n}\r\n','<?php\r\n	global $global_navi;\r\n	$global_navi = \'home\';\r\n?>','','','','','','0','','','','admin','1392242739','admin','1421631036'),
 ('00001','00','0000000002','','0000000001','NEWS &amp; TOPICS ｜ B-studio','','<div class=\"main-contents\">\r\n	<div id=\"news\">\r\n		<h1>NEWS &amp; TOPICS</h1>\r\n		<?php widget(\'0000000003\'); // news_list ?>\r\n	</div>\r\n</div>','','','','.main-image {\r\n	padding: 30px 0;\r\n	border-bottom: 1px solid #999;\r\n}\r\n.main-image .image {\r\n	float: left;\r\n	width: 400px;\r\n	text-align: center;\r\n	border: 1px solid #999;\r\n	padding: 20px 0 12px 0;\r\n}\r\n.main-image .image img {\r\n	width: 70%;\r\n}\r\n.main-image .text {\r\n	float: right;\r\n	width: 550px;\r\n}\r\n.main-image .text p {\r\n	margin: 0;\r\n	padding: 0 10px;\r\n}\r\n.main-contents {\r\n	padding-bottom: 60px;\r\n}\r\n.main-contents p {\r\n	padding: 4px 20px;\r\n}\r\n#news {\r\n	padding: 0 10px;\r\n}\r\n#news ul {\r\n	margin: 0;\r\n	padding: 20px;\r\n	list-style: none;\r\n}\r\n#news ul li {\r\n	margin: 20px 0;\r\n}\r\n#features ul li .image {\r\n	float: left;\r\n	width: 250px;\r\n	text-align: center;\r\n	border-right: 1px solid #999;\r\n	padding: 20px 0 12px 0;\r\n}\r\n#features ul li .image img {\r\n	width: 70%;\r\n}\r\n#features ul li .text {\r\n	float: right;\r\n	width: 720px;\r\n}\r\n','<?php\r\n	global $global_navi;\r\n	$global_navi = \'features\';\r\n?>','','','','','','0','','','','admin','1392433671','admin','1393224117'),
 ('00001','00','0000000003','','0000000001','B-studio','','<h1>CATEGORY2</h1>\r\n\r\n<div class=\"contents\">\r\n</div>','','','','.catch {\r\n	margin: 0;\r\n	padding: 5px 0 30px 35px;\r\n}\r\n.contents {\r\n	padding: 0 10px;\r\n}\r\n.feature {\r\n	padding-bottom:70px;\r\n	width: 100%;\r\n}\r\n.feature ul {\r\n	margin : 0 auto;\r\n	width: 1000px;\r\n}\r\n.feature ul li {\r\n	float: left;\r\n	width: 230px;\r\n	padding: 0 10px;\r\n}\r\n.aligncenter {\r\n	text-align: center;\r\n}\r\n.aligncenter h3,\r\n.aligncenter p {\r\n	margin-left: 0;\r\n}\r\np.icon {\r\nmargin: 0 auto;\r\nwidth: 44px;\r\nheight: 44px;\r\nbackground-color: #dddddd;\r\nborder: solid 6px #fff;\r\nborder-radius: 60px;\r\n}\r\np.icon img.tree-icon {\r\n	vertical-align: -38px;\r\n}\r\np.icon img.html-icon {\r\n	vertical-align: -34px;\r\n	margin-left: 2px;\r\n}\r\np.icon img.visual-icon {\r\n	vertical-align: -38px;\r\n}\r\np.icon img.version-icon {\r\n	vertical-align: -39px;\r\n}\r\n','<?php\r\n	global $global_navi;\r\n	$global_navi = \'features\';\r\n?>','','','','','','0','','','','admin','1392435642','admin','1421630415'),
 ('00001','00','0000000004','','0000000001','B-studio','','<div class=\"main-image\">\r\n	<img alt=\"main-image\" src=\"images/main-image.png\" />\r\n</div>\r\n<?php widget(\'0000000005\'); // breadcrumbs ?>\r\n<div class=\"main-contents\">\r\n	<div class=\"clearfix\" id=\"features\">\r\n		<h1>CATEGORY1</h1>\r\n\r\n		<p>\r\n			A wonderful serenity has taken possession of my entire soul, like these sweet mornings of spring which I enjoy with my whole heart.\r\n		</p>\r\n\r\n		<div class=\"left clearfix\">\r\n			<ul>\r\n				<li class=\"clearfix\">\r\n					<a href=\"category1/item/\">\r\n						<div class=\"image\">\r\n							<img alt=\"image\" src=\"images/dummy_gray_300x200.png\" />\r\n						</div>\r\n	\r\n						<div class=\"text\">\r\n							<p>\r\n								A wonderful serenity has taken possession of my entire soul, like these sweet mornings of spring which I enjoy with my whole heart.\r\n							</p>\r\n						</div>\r\n					</a>\r\n				</li>\r\n				<li class=\"clearfix\">\r\n					<a href=\"category1/item/\">\r\n						<div class=\"image\">\r\n							<img alt=\"image\" src=\"images/dummy_gray_300x200.png\" />\r\n						</div>\r\n	\r\n						<div class=\"text\">\r\n							<p>\r\n								I am alone, and feel the charm of existence in this spot, which was created for the bliss of souls like mine. I am so happy, my dear fr\r\n							</p>\r\n						</div>\r\n					</a>\r\n				</li>\r\n				<li class=\"clearfix\">\r\n					<a href=\"category1/item/\">\r\n						<div class=\"image\">\r\n							<img alt=\"image\" src=\"images/dummy_gray_300x200.png\" />\r\n						</div>\r\n	\r\n						<div class=\"text\">\r\n							<p>\r\n								I should be incapable of drawing a single stroke at the present moment; and yet I feel that I never was a greater artist than now.\r\n							</p>\r\n						</div>\r\n					</a>\r\n				</li>\r\n				<li class=\"clearfix\">\r\n					<a href=\"category1/item/\">\r\n						<div class=\"image\">\r\n							<img alt=\"image\" src=\"images/dummy_gray_300x200.png\" />\r\n						</div>\r\n	\r\n						<div class=\"text\">\r\n							<p>\r\n								When, while the lovely valley teems with vapour around me, and the meridian sun strikes the upper surface of the impenetrable foliage of my trees, and but a few ...\r\n							</p>\r\n						</div>\r\n					</a>\r\n				</li>\r\n				<li class=\"clearfix\">\r\n					<a href=\"category1/item/\">\r\n						<div class=\"image\">\r\n							<img alt=\"image\" src=\"images/dummy_gray_300x200.png\" />\r\n						</div>\r\n	\r\n						<div class=\"text\">\r\n							<p>\r\n								When, while the lovely valley teems with vapour around me, and the meridian sun strikes the upper surface of the impenetrable foliage of my trees, and but a few ...\r\n							</p>\r\n						</div>\r\n					</a>\r\n				</li>\r\n				<li class=\"clearfix\">\r\n					<a href=\"category1/item/\">\r\n						<div class=\"image\">\r\n							<img alt=\"image\" src=\"images/dummy_gray_300x200.png\" />\r\n						</div>\r\n	\r\n						<div class=\"text\">\r\n							<p>\r\n								When, while the lovely valley teems with vapour around me, and the meridian sun strikes the upper surface of the impenetrable foliage of my trees, and but a few ...\r\n							</p>\r\n						</div>\r\n					</a>\r\n				</li>\r\n			</ul>\r\n		</div>\r\n\r\n		<div class=\"right\">\r\n			<ul>\r\n				<li class=\"clearfix\">\r\n					<div class=\"image\">\r\n						<img alt=\"image\" src=\"images/dummy_gray_300x200.png\" />\r\n					</div>\r\n\r\n					<div class=\"text\">\r\n						<p>\r\n							A wonderful serenity has taken possession of my entire soul, like\r\n						</p>\r\n					</div>\r\n				</li>\r\n				<li class=\"clearfix\">\r\n					<div class=\"image\">\r\n						<img alt=\"image\" src=\"images/dummy_gray_300x200.png\" />\r\n					</div>\r\n\r\n					<div class=\"text\">\r\n						<p>\r\n							I am alone, and feel the charm of existence in this spot,\r\n						</p>\r\n					</div>\r\n				</li>\r\n				<li class=\"clearfix\">\r\n					<div class=\"image\">\r\n						<img alt=\"image\" src=\"images/dummy_gray_300x200.png\" />\r\n					</div>\r\n\r\n					<div class=\"text\">\r\n						<p>\r\n							I am alone, and feel the charm of existence in this spot,\r\n						</p>\r\n					</div>\r\n				</li>\r\n				<li class=\"clearfix\">\r\n					<div class=\"image\">\r\n						<img alt=\"image\" src=\"images/dummy_gray_300x200.png\" />\r\n					</div>\r\n\r\n					<div class=\"text\">\r\n						<p>\r\n							I am alone, and feel the charm of existence in this spot,\r\n						</p>\r\n					</div>\r\n				</li>\r\n				<li class=\"clearfix\">\r\n					<div class=\"image\">\r\n						<img alt=\"image\" src=\"images/dummy_gray_300x200.png\" />\r\n					</div>\r\n\r\n					<div class=\"text\">\r\n						<p>\r\n							I am alone, and feel the charm of existence in this spot,\r\n						</p>\r\n					</div>\r\n				</li>\r\n			</ul>\r\n		</div>\r\n	</div>\r\n</div>\r\n','','','','.main-image {\r\n	padding: 30px 0;\r\n	text-align: center;\r\n	border-bottom: 1px solid #999;\r\n}\r\n.main-image .image {\r\n	float: left;\r\n	width: 400px;\r\n	text-align: center;\r\n	border: 1px solid #999;\r\n	padding: 20px 0 12px 0;\r\n}\r\n.main-image .image img {\r\n	width: 70%;\r\n}\r\n.main-image .text {\r\n	float: right;\r\n	width: 550px;\r\n}\r\n.main-image .text p {\r\n	margin: 0;\r\n	padding: 0 10px;\r\n}\r\n.main-contents {\r\n	padding-bottom: 60px;\r\n}\r\n.main-contents p {\r\n	padding: 4px 20px;\r\n}\r\n#features {\r\n	padding: 0 10px;\r\n}\r\n.left ul {\r\n	margin: 0;\r\n	padding: 20px 0;\r\n	list-style: none;\r\n}\r\n.left ul li {\r\n	border: 1px solid #999;\r\n	margin: 20px 0;\r\n}\r\n.left ul li .image {\r\n	float: left;\r\n	width: 250px;\r\n	text-align: center;\r\n	border-right: 1px solid #999;\r\n	padding: 15px 0 14px 0;\r\n}\r\n.left ul li .image img {\r\n	width: 70%;\r\n}\r\n.left ul li .text {\r\n	float: right;\r\n	width: 420px;\r\n}\r\n.left {\r\n	width: 700px;\r\n	float: left;\r\n}\r\n.right ul {\r\n	margin: 0;\r\n	padding: 20px 0;\r\n	list-style: none;\r\n}\r\n.right ul li {\r\n	border: 1px solid #999;\r\n	margin: 12px 0;\r\n}\r\n.right ul li:first-child {\r\n	margin: 20px 0 0 0;\r\n}\r\n.right ul li .image {\r\n	float: left;\r\n	width: 90px;\r\n	text-align: center;\r\n	border-right: 1px solid #999;\r\n	padding: 15px 0 12px 0;\r\n}\r\n.right ul li .image img {\r\n	width: 80%;\r\n}\r\n.right ul li .text {\r\n	float: right;\r\n	width: 157px;\r\n	font-size: 10px;\r\n}\r\n.right ul li .text p {\r\n	padding: 4px 8px;\r\n}\r\n.right {\r\n	width: 250px;\r\n	float: right;\r\n}','<?php\r\n	global $global_navi;\r\n	$global_navi = \'category1\';\r\n?>','','','','','','0','','','','admin','1392453810','admin','1421630389'),
 ('00001','00','0000000005','','0000000001','Function | B-studio','','<div class=\"main-image clearfix\">\r\n	<div class=\"image\">\r\n		<img alt=\"image\" src=\"images/dummy_gray_300x200.png\" />\r\n	</div>\r\n\r\n	<div class=\"text\">\r\n		<p>\r\n			One morning, when Gregor Samsa woke from troubled dreams, he found himself transformed in his bed into a horrible vermin. He lay on his armour-like back, and if he lifted his head a little he could see his brown belly, slightly domed and divided by arches into stiff sections. The bedding was hardly able to cover it and ......\r\n		</p>\r\n	</div>\r\n</div>\r\n\r\n<div class=\"main-contents\">\r\n	<div id=\"features\">\r\n		<h1>FEATURES</h1>\r\n\r\n		<p>\r\n			A wonderful serenity has taken possession of my entire soul, like these sweet mornings of spring which I enjoy with my whole heart.\r\n		</p>\r\n\r\n		<ul>\r\n			<li class=\"clearfix\">\r\n				<div class=\"image\">\r\n					<img alt=\"image\" src=\"images/dummy_gray_300x200.png\" />\r\n				</div>\r\n\r\n				<div class=\"text\">\r\n					<p>\r\n						A wonderful serenity has taken possession of my entire soul, like these sweet mornings of spring which I enjoy with my whole heart.\r\n					</p>\r\n				</div>\r\n			</li>\r\n			<li class=\"clearfix\">\r\n				<div class=\"image\">\r\n					<img alt=\"image\" src=\"images/dummy_gray_300x200.png\" />\r\n				</div>\r\n\r\n				<div class=\"text\">\r\n					<p>\r\n						I am alone, and feel the charm of existence in this spot, which was created for the bliss of souls like mine. I am so happy, my dear friend, so absorbed in the exquisite sense of mere tranquil existence, that I neglect my talents.\r\n					</p>\r\n				</div>\r\n			</li>\r\n			<li class=\"clearfix\">\r\n				<div class=\"image\">\r\n					<img alt=\"image\" src=\"images/dummy_gray_300x200.png\" />\r\n				</div>\r\n\r\n				<div class=\"text\">\r\n					<p>\r\n						I should be incapable of drawing a single stroke at the present moment; and yet I feel that I never was a greater artist than now.\r\n					</p>\r\n				</div>\r\n			</li>\r\n			<li class=\"clearfix\">\r\n				<div class=\"image\">\r\n					<img alt=\"image\" src=\"images/dummy_gray_300x200.png\" />\r\n				</div>\r\n\r\n				<div class=\"text\">\r\n					<p>\r\n						When, while the lovely valley teems with vapour around me, and the meridian sun strikes the upper surface of the impenetrable foliage of my trees, and but a few stray gleams steal into the inner sanctuary, I throw myself down among the tall grass by the trickling stream; and, as I lie close to the ...\r\n					</p>\r\n				</div>\r\n			</li>\r\n			<li class=\"clearfix\">\r\n				<div class=\"image\">\r\n					<img alt=\"image\" src=\"images/dummy_gray_300x200.png\" />\r\n				</div>\r\n\r\n				<div class=\"text\">\r\n					<p>\r\n						But I must explain to you how all this mistaken idea of denouncing pleasure and praising pain was born and I will give you a complete account of the system, and expound the actual teachings of the great explorer of the truth, the master-builder of human happiness.\r\n					</p>\r\n				</div>\r\n			</li>\r\n			<li class=\"clearfix\">\r\n				<div class=\"image\">\r\n					<img alt=\"image\" src=\"images/dummy_gray_300x200.png\" />\r\n				</div>\r\n\r\n				<div class=\"text\">\r\n					<p>\r\n						No one rejects, dislikes, or avoids pleasure itself, because it is pleasure, but because those who do not know how to pursue pleasure rationally encounter consequences that are extremely painful.\r\n					</p>\r\n				</div>\r\n			</li>\r\n			<li class=\"clearfix\">\r\n				<div class=\"image\">\r\n					<img alt=\"image\" src=\"images/dummy_gray_300x200.png\" />\r\n				</div>\r\n\r\n				<div class=\"text\">\r\n					<p>\r\n						Nor again is there anyone who loves or pursues or desires to obtain pain of itself, because it is pain, but because occasionally circumstances occur in which toil and pain can procure him some great pleasure.\r\n					</p>\r\n				</div>\r\n			</li>\r\n			<li class=\"clearfix\">\r\n				<div class=\"image\">\r\n					<img alt=\"image\" src=\"images/dummy_gray_300x200.png\" />\r\n				</div>\r\n\r\n				<div class=\"text\">\r\n					<p>\r\n						To take a trivial example, which of us ever undertakes laborious physical exercise, except to obtain some advantage from it?\r\n					</p>\r\n				</div>\r\n			</li>\r\n		</ul>\r\n	</div>\r\n</div>\r\n','','','','.main-image {\r\n	padding: 30px 0;\r\n	border-bottom: 1px solid #999;\r\n}\r\n.main-image .image {\r\n	float: left;\r\n	width: 400px;\r\n	text-align: center;\r\n	border: 1px solid #999;\r\n	padding: 20px 0 12px 0;\r\n}\r\n.main-image .image img {\r\n	width: 70%;\r\n}\r\n.main-image .text {\r\n	float: right;\r\n	width: 550px;\r\n}\r\n.main-image .text p {\r\n	margin: 0;\r\n	padding: 0 10px;\r\n}\r\n.main-contents {\r\n	padding-bottom: 60px;\r\n}\r\n.main-contents p {\r\n	padding: 4px 20px;\r\n}\r\n#features {\r\n	padding: 0 10px;\r\n}\r\n#features ul {\r\n	margin: 0;\r\n	padding: 20px 0;\r\n	list-style: none;\r\n}\r\n#features ul li {\r\n	border: 1px solid #999;\r\n	margin: 20px 0;\r\n}\r\n#features ul li .image {\r\n	float: left;\r\n	width: 250px;\r\n	text-align: center;\r\n	border-right: 1px solid #999;\r\n	padding: 20px 0 12px 0;\r\n}\r\n#features ul li .image img {\r\n	width: 70%;\r\n}\r\n#features ul li .text {\r\n	float: right;\r\n	width: 720px;\r\n}\r\n','<?php\r\n	global $global_navi;\r\n	$global_navi = \'function\';\r\n?>','','','','','','0','','','','admin','1392510099','admin','1421630447'),
 ('00001','00','0000000006','','0000000002','HTMLテンプレート | function | B-studio','','<h1>CATEGORY3</h1>\r\n','','','','','<?php\r\n	global $global_navi;\r\n	$global_navi = \'function\';\r\n?>','','','','','','0','','','','admin','1392510214','admin','1421630423'),
 ('00001','00','0000000007','','0000000001','CATEGORY4 | B-studio','','<h1>CATEGORY4</h1>\r\n','','','','','<?php\r\n	global $global_navi;\r\n	$global_navi = \'function\';\r\n?>','','','','','','0','','','','admin','1392518007','admin','1421630429'),
 ('00001','00','0000000008','','0000000002','ビジュアルエディター | Function | B-studio','','<h1>Function</h1>\r\n\r\n<div class=\"contents\">\r\n	<h2>ビジュアルエディター</h2>\r\n	<div class=\"contents-box clearfix\">\r\n		<div>\r\n			<p>HTMLエディタで作成したページ、続きをビジュアルエディタで編集することができます。 インラインエディタですので、ページ全体 すべてが表示された状態で編集することができます。\r\n			</p>\r\n		</div>\r\n	</div>\r\n	<div class=\"contents-box clearfix\">\r\n		<div>\r\n			<p class=\"center\"><img src=\"images/function/visual_editor_function.png\" alt=\"HTML editor\" /></p>\r\n			<p>テキストの編集や画像の差し替えなどはビジュアルエディタを使って簡単に行うことができますが、レイアウトにかかわる修正はHTMLエディタを使用することをお勧めします。</p>\r\n			<p><span class=\"caution\">※</span>ビジュアルエディタ内では、javascriptは機能しません</p>\r\n		</div>\r\n	</div>\r\n</div>','','','','','<?php\r\n	global $global_navi;\r\n	$global_navi = \'function\';\r\n?>','CMS','自由度を最優先したCMS、直感的なインターフェースによりWEBサイトを管理します。','','','','0','','','','admin','1392539461','admin','1392588283'),
 ('00001','00','0000000009','','','','','<p>string:<?php echo $string; ?></p>\r\n<p>new string:<?php echo $new_string; ?></p>\r\n','','','','','<?php\r\n	$string = \'\r\nCREATE ALGORITHM=UNDEFINED DEFINER=`aa131buw6haaaa`@`localhaaaaost` SQL SECURITY DEFINER VIEW `bs_v_w_widget` AS select `a`.`version_id` AS `version_id`,`a`.`revision_id` AS `revision_id`,`a`.`contents_id` AS `contents_id`,`a`.`contents_date` AS `contents_date`,`a`.`widget_id` AS `widget_id`,`a`.`html` AS `html`,`a`.`css` AS `css`,`a`.`php` AS `php`,`a`.`del_flag` AS `del_flag`,`a`.`reserve1` AS `reserve1`,`a`.`reserve2` AS `reserve2`,`a`.`reserve3` AS `reserve3`,`a`.`create_user` AS `create_user`,`a`.`create_datetime` AS `create_datetime`,`a`.`update_user` AS `update_user`,`a`.`update_datetime` AS `update_datetime` from `bs_widget` `a` where (concat(`a`.`version_id`,`a`.`revision_id`) = (select max(concat(`b`.`version_id`,`b`.`revision_id`)) from ((`bs_widget` `b` join `bs_v_current_version` `c`) join `bs_version` `d`) where ((`a`.`contents_id` = `b`.`contents_id`) and (`b`.`version_id` = `d`.`version_id`) and (((`b`.`version_id` < `c`.`working_version_id`) and (`b`.`revision_id` < `d`.`private_revision_id`)) or ((`b`.`version_id` = `c`.`working_version_id`) and (`b`.`revision_id` <= `d`.`private_revision_id`)))) group by `b`.`contents_id`));\';\r\n	$new_string = preg_replace(\'/DEFINER=`\\w*`@`\\w*`/\', \'\', $string);\r\n	$new_string = preg_replace(\'/ALGORITHM=\\w*/\', \'\', $new_string);\r\n	$new_string = preg_replace(\'/ SQL SECURITY DEFINER/\', \'\', $new_string);\r\n\r\n?>','','','','','','0','','','','admin','1393027240','admin','1393036396'),
 ('00001','00','0000000010','','0000000001','NEWS & TOPICS','','<div class=\"main-contents\">\r\n	<div id=\"news\">\r\n		<h1>NEWS &amp; TOPICS</h1>\r\n		<h2><?php echo $title; ?>\r\n		<div class=\"section\">\r\n			<?php echo $description; ?>\r\n		</div>\r\n	</div>\r\n</div>','','','','.section {\r\n	padding: 20px;\r\n	font-size: 16px;\r\n	font-weight: normal;\r\n}\r\n\r\n.section .textbox-img-right,\r\n.section .textbox-img-left {\r\n	overflow: hidden;\r\n	padding: 20px 0;\r\n}\r\n\r\n.section .textbox-img-right img {\r\n	float: right;\r\n	margin: 0 0 10px 10px;\r\n}\r\n\r\n.section .textbox-img-left img {\r\n	float: left;\r\n	margin: 0 10px 10px 0;\r\n}','<?php\r\n	// view_mode\r\n	if($bs_view_mode == \'preview\') {\r\n		$article_id = \'0000000001\';\r\n	}\r\n	else {\r\n		$article_id = $bs_db->real_escape_string($_REQUEST[\'id\']);\r\n		if(!$article_id) notfound();\r\n	}\r\n\r\n	$sql = \"select * from \" . B_ARTICLE_VIEW . \" where article_id=\'$article_id\'\";\r\n	$rs = $bs_db->query($sql);\r\n	$row = $bs_db->fetch_assoc($rs);\r\n	if(!$row) notfound();\r\n\r\n	$article_date = date(\'Y年n月j日\', $row[\'article_date_u\']);\r\n	$title = str_replace(\"n\", \"<br />\", $row[\'title\']);\r\n	$description = $row[\'description\'];\r\n\r\n	$bread_crumb_disp_name = $row[\'title\'];\r\n?>','','','','','','0','','','','admin','1393224181','admin','1432798080'),
 ('00001','00','0000000011','','0000000001','Detail | B-studio','','<div class=\"main-image clearfix\">\r\n	<div class=\"image\">\r\n		<img alt=\"image\" src=\"images/dummy_gray_300x200.png\" />\r\n	</div>\r\n\r\n	<div class=\"text\">\r\n		<p>\r\n			One morning, when Gregor Samsa woke from troubled dreams, he found himself transformed in his bed into a horrible vermin. He lay on his armour-like back, and if he lifted his head a little he could see his brown belly, slightly domed and divided by arches into stiff sections. The bedding was hardly able to cover it and ......\r\n		</p>\r\n	</div>\r\n</div>\r\n\r\n<div class=\"main-contents\">\r\n	<div id=\"detail\">\r\n		<h1>PRODUCT NAME Ver.1</h1>\r\n\r\n		<p>\r\n			A wonderful serenity has taken possession of my entire soul, like these sweet mornings of spring which I enjoy with my whole heart.\r\n		</p>\r\n\r\n		<ul>\r\n			<li class=\"clearfix\">\r\n				<div class=\"image\">\r\n					<img alt=\"image\" src=\"images/dummy_gray_300x200.png\" />\r\n				</div>\r\n\r\n				<div class=\"text\">\r\n					<p>\r\n						A wonderful serenity has taken possession of my entire soul, like these sweet mornings of spring which I enjoy with my whole heart.\r\n					</p>\r\n				</div>\r\n			</li>\r\n			<li class=\"clearfix\">\r\n				<div class=\"image\">\r\n					<img alt=\"image\" src=\"images/dummy_gray_300x200.png\" />\r\n				</div>\r\n\r\n				<div class=\"text\">\r\n					<p>\r\n						A wonderful serenity has taken possession of my entire soul, like these sweet mornings of spring which I enjoy with my whole heart.\r\n					</p>\r\n				</div>\r\n			</li>\r\n			<li class=\"clearfix\">\r\n				<div class=\"image\">\r\n					<img alt=\"image\" src=\"images/dummy_gray_300x200.png\" />\r\n				</div>\r\n\r\n				<div class=\"text\">\r\n					<p>\r\n						A wonderful serenity has taken possession of my entire soul, like these sweet mornings of spring which I enjoy with my whole heart.\r\n					</p>\r\n				</div>\r\n			</li>\r\n			<li class=\"clearfix\">\r\n				<div class=\"image\">\r\n					<img alt=\"image\" src=\"images/dummy_gray_300x200.png\" />\r\n				</div>\r\n\r\n				<div class=\"text\">\r\n					<p>\r\n						A wonderful serenity has taken possession of my entire soul, like these sweet mornings of spring which I enjoy with my whole heart.\r\n					</p>\r\n				</div>\r\n			</li>\r\n			<li class=\"clearfix\">\r\n				<div class=\"image\">\r\n					<img alt=\"image\" src=\"images/dummy_gray_300x200.png\" />\r\n				</div>\r\n\r\n				<div class=\"text\">\r\n					<p>\r\n						A wonderful serenity has taken possession of my entire soul, like these sweet mornings of spring which I enjoy with my whole heart.\r\n					</p>\r\n				</div>\r\n			</li>\r\n			<li class=\"clearfix\">\r\n				<div class=\"image\">\r\n					<img alt=\"image\" src=\"images/dummy_gray_300x200.png\" />\r\n				</div>\r\n\r\n				<div class=\"text\">\r\n					<p>\r\n						A wonderful serenity has taken possession of my entire soul, like these sweet mornings of spring which I enjoy with my whole heart.\r\n					</p>\r\n				</div>\r\n			</li>\r\n		</ul>\r\n	</div>\r\n</div>\r\n','','','','.main-image {\r\n	padding: 30px 0;\r\n	border-bottom: 1px solid #999;\r\n}\r\n.main-image .image {\r\n	float: left;\r\n	width: 400px;\r\n	text-align: center;\r\n	border: 1px solid #999;\r\n	padding: 20px 0 12px 0;\r\n}\r\n.main-image .image img {\r\n	width: 70%;\r\n}\r\n.main-image .text {\r\n	float: right;\r\n	width: 550px;\r\n}\r\n.main-image .text p {\r\n	margin: 0;\r\n	padding: 0 10px;\r\n}\r\n.main-contents {\r\n	padding-bottom: 60px;\r\n}\r\n.main-contents p {\r\n	padding: 4px 20px;\r\n}\r\n#detail {\r\n	padding: 0 10px;\r\n}\r\n#detail ul {\r\n	margin: 0;\r\n	padding: 20px 0;\r\n	list-style: none;\r\n}\r\n#detail ul li {\r\n	border-bottom: 1px solid #e5e5e5;\r\n	margin: 20px 0;\r\n}\r\n#detail ul li .image {\r\n	width: 250px;\r\n	text-align: center;\r\n	padding: 20px 0 12px 0;\r\n}\r\n#detail ul li .image img {\r\n	width: 70%;\r\n}\r\n#detail ul li .text {\r\n	width: 720px;\r\n}\r\n\r\n#detail ul li:nth-child(odd) .image {\r\n	float: right;\r\n}\r\n\r\n#detail ul li:nth-child(odd) .text {\r\n	float: left;\r\n}\r\n\r\n#detail ul li:nth-child(even) .image {\r\n	float: left;\r\n}\r\n\r\n#detail ul li:nth-child(even) .text {\r\n	float: right;\r\n}','<?php\r\n	global $global_navi;\r\n	$global_navi = \'function\';\r\n?>','','','','','','0','','','','admin','1400564115','admin','1421630439'),
 ('00001','00','0000000012','','0000000001','','','<div class=\"message\">404 Not Found</div>\r\n\r\n','','','','.message {\r\n	padding: 200px 0;\r\n	text-align: center;\r\n}','','','','','','','0','','','','admin','1432197193','admin','1432203187');
/*!40000 ALTER TABLE `%PREFIX%contents` ENABLE KEYS */;


--
-- Definition of table `%PREFIX%contents_node`
--

DROP TABLE IF EXISTS `%PREFIX%contents_node`;
CREATE TABLE `%PREFIX%contents_node` (
  `version_id` char(5) NOT NULL default '',
  `revision_id` char(2) NOT NULL default '',
  `node_id` char(10) NOT NULL default '',
  `parent_node` char(10) default NULL,
  `node_type` char(10) default NULL,
  `node_class` char(10) default NULL,
  `node_name` text,
  `contents_id` char(10) default NULL,
  `disp_seq` int(11) default NULL,
  `del_flag` char(1) default NULL,
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text,
  PRIMARY KEY  (`version_id`,`revision_id`,`node_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `%PREFIX%contents_node`
--

/*!40000 ALTER TABLE `%PREFIX%contents_node` DISABLE KEYS */;
INSERT INTO `%PREFIX%contents_node` (`version_id`,`revision_id`,`node_id`,`parent_node`,`node_type`,`node_class`,`node_name`,`contents_id`,`disp_seq`,`del_flag`,`create_user`,`create_datetime`,`update_user`,`update_datetime`) VALUES 
 ('00001','00','0000000001','root','page','leaf','index.html','0000000001','0','0','admin','1392242516','admin','1393185950'),
 ('00001','00','0000000002','root','folder','folder','news','','1','0','admin','1392433661','admin','1393185950'),
 ('00001','00','0000000003','0000000002','page','leaf','index.html','0000000002','0','0','admin','1392433671','admin','1392433671'),
 ('00001','00','0000000004','root','folder','folder','category2','','4','0','admin','1392435632','admin','1393225391'),
 ('00001','00','0000000005','0000000004','page','leaf','index.html','0000000003','0','0','admin','1392435642','admin','1392435642'),
 ('00001','00','0000000006','root','folder','folder','category1','','3','0','admin','1392453810','admin','1393225386'),
 ('00001','00','0000000007','0000000006','page','leaf','index.html','0000000004','0','0','admin','1392453810','admin','1392453810'),
 ('00001','00','0000000008','root','folder','folder','features','','2','0','admin','1392510099','admin','1393185959'),
 ('00001','00','0000000009','0000000008','page','leaf','index.html','0000000005','0','0','admin','1392510099','admin','1392510099'),
 ('00001','00','0000000010','0000000016','page','leaf','index.html','0000000006','0','0','admin','1392510214','admin','1393225413'),
 ('00001','00','0000000012','0000000017','page','leaf','index.html','0000000007','0','0','admin','1392518007','admin','1393225430'),
 ('00001','00','0000000015','0000000002','page','leaf','detail','0000000010','1','0','admin','1393223707','admin','1393223709'),
 ('00001','00','0000000016','root','folder','folder','category3','','5','0','admin','1393225401','admin','1393225403'),
 ('00001','00','0000000017','root','folder','folder','category4','','6','0','admin','1393225417','admin','1393225421'),
 ('00001','00','0000000019','0000000006','folder','folder','item','','1','0','admin','1400564098','admin','1400564101'),
 ('00001','00','0000000020','0000000019','page','leaf','index.html','0000000011','0','0','admin','1400564115','admin','1400564115'),
 ('00001','00','0000000021','root','page','leaf','notfound.html','0000000012','7','0','admin','1432197185','admin','1432197187');
/*!40000 ALTER TABLE `%PREFIX%contents_node` ENABLE KEYS */;


--
-- Definition of table `%PREFIX%current_version`
--

DROP TABLE IF EXISTS `%PREFIX%current_version`;
CREATE TABLE `%PREFIX%current_version` (
  `id` char(10) NOT NULL default '',
  `current_version_id` char(5) default NULL,
  `reserved_version_id` char(5) default NULL,
  `working_version_id` char(5) default NULL,
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `%PREFIX%current_version`
--

/*!40000 ALTER TABLE `%PREFIX%current_version` DISABLE KEYS */;
INSERT INTO `%PREFIX%current_version` (`id`,`current_version_id`,`reserved_version_id`,`working_version_id`,`create_user`,`create_datetime`,`update_user`,`update_datetime`) VALUES 
 ('0000000001','00001','00001','00001','installer','1392242480','','');
/*!40000 ALTER TABLE `%PREFIX%current_version` ENABLE KEYS */;


--
-- Definition of table `%PREFIX%resource_node`
--

DROP TABLE IF EXISTS `%PREFIX%resource_node`;
CREATE TABLE `%PREFIX%resource_node` (
  `version_id` char(5) NOT NULL default '',
  `revision_id` char(2) NOT NULL default '',
  `node_id` char(10) NOT NULL default '',
  `parent_node` char(10) default NULL,
  `node_type` char(10) default NULL,
  `node_class` char(10) default NULL,
  `node_name` text,
  `file_size` int(11) default NULL,
  `human_file_size` text,
  `image_size` int(11) default NULL,
  `human_image_size` text,
  `contents_id` char(19) default NULL,
  `disp_seq` int(11) default NULL,
  `del_flag` char(1) default NULL,
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text,
  PRIMARY KEY  (`version_id`,`revision_id`,`node_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `%PREFIX%resource_node`
--

/*!40000 ALTER TABLE `%PREFIX%resource_node` DISABLE KEYS */;
INSERT INTO `%PREFIX%resource_node` (`version_id`,`revision_id`,`node_id`,`parent_node`,`node_type`,`node_class`,`node_name`,`file_size`,`human_file_size`,`image_size`,`human_image_size`,`contents_id`,`disp_seq`,`del_flag`,`create_user`,`create_datetime`,`update_user`,`update_datetime`) VALUES 
 ('00001','00','0000000001','root','folder','folder','images','0','','0','','0000000001_00001_00','0','0','admin','1433746439','admin','1433746439'),
 ('00001','00','0000000002','0000000001','file','leaf','dummy_gray_300x200.png','2224','2.2KB','60000','300x200','0000000002_00001_00','0','0','admin','1433746439','admin','1433746439'),
 ('00001','00','0000000003','0000000001','file','leaf','dummy_white_300x200.png','2230','2.2KB','60000','300x200','0000000003_00001_00','1','0','admin','1433746439','admin','1433746439'),
 ('00001','00','0000000004','0000000001','file','leaf','main-image.png','1765','1.8KB','180000','900x200','0000000004_00001_00','2','0','admin','1433746439','admin','1433746439'),
 ('00001','00','0000000005','0000000001','file','leaf','new_image.jpg','17233','16.9KB','59899','301x199','0000000005_00001_00','3','0','admin','1433746439','admin','1433746439'),
 ('00001','00','0000000006','root','folder','folder','visualeditor','0','','0','','0000000006_00001_00','1','0','admin','1433746439','admin','1433746439'),
 ('00001','00','0000000007','0000000006','folder','folder','article1','0','','0','','0000000007_00001_00','0','0','admin','1433746439','admin','1433746439'),
 ('00001','00','0000000008','0000000007','folder','folder','css','0','','0','','0000000008_00001_00','0','0','admin','1433746439','admin','1433746439'),
 ('00001','00','0000000009','0000000008','file','leaf','default.css','2190','2.2KB','0','','0000000009_00001_00','0','0','admin','1433746439','admin','1433746439'),
 ('00001','00','0000000010','0000000007','folder','folder','styles','0','','0','','0000000010_00001_00','1','0','admin','1433746439','admin','1433746439'),
 ('00001','00','0000000011','0000000010','file','leaf','styles.js','3662','3.6KB','0','','0000000011_00001_00','0','0','admin','1433746439','admin','1433746439'),
 ('00001','00','0000000012','0000000007','folder','folder','templates','0','','0','','0000000012_00001_00','2','0','admin','1433746439','admin','1433746439'),
 ('00001','00','0000000013','0000000012','folder','folder','images','0','','0','','0000000013_00001_00','0','0','admin','1433746439','admin','1433746439'),
 ('00001','00','0000000014','0000000013','file','leaf','template1.gif','2181','2.2KB','7000','100x70','0000000014_00001_00','0','0','admin','1433746439','admin','1433746439'),
 ('00001','00','0000000015','0000000013','file','leaf','template2.gif','333','0.4KB','7000','100x70','0000000015_00001_00','1','0','admin','1433746439','admin','1433746439'),
 ('00001','00','0000000016','0000000013','file','leaf','template3.gif','2242','2.2KB','7000','100x70','0000000016_00001_00','2','0','admin','1433746439','admin','1433746439'),
 ('00001','00','0000000017','0000000013','file','leaf','template4.gif','1552','1.6KB','7000','100x70','0000000017_00001_00','3','0','admin','1433746439','admin','1433746439'),
 ('00001','00','0000000018','0000000013','file','leaf','template5.gif','1554','1.6KB','7000','100x70','0000000018_00001_00','4','0','admin','1433746439','admin','1433746439'),
 ('00001','00','0000000019','0000000012','file','leaf','default.js','2289','2.3KB','0','','0000000019_00001_00','1','0','admin','1433746439','admin','1433746439'),
 ('00001','00','0000000020','0000000006','folder','folder','article2','0','','0','','0000000020_00001_00','1','0','admin','1433746439','admin','1433746439'),
 ('00001','00','0000000021','0000000020','folder','folder','css','0','','0','','0000000021_00001_00','0','0','admin','1433746439','admin','1433746439'),
 ('00001','00','0000000022','0000000021','file','leaf','default.css','1841','1.8KB','0','','0000000022_00001_00','0','0','admin','1433746439','admin','1433746439'),
 ('00001','00','0000000023','0000000020','folder','folder','styles','0','','0','','0000000023_00001_00','1','0','admin','1433746439','admin','1433746439'),
 ('00001','00','0000000024','0000000023','file','leaf','styles.js','3662','3.6KB','0','','0000000024_00001_00','0','0','admin','1433746439','admin','1433746439'),
 ('00001','00','0000000025','0000000020','folder','folder','templates','0','','0','','0000000025_00001_00','2','0','admin','1433746439','admin','1433746439'),
 ('00001','00','0000000026','0000000025','folder','folder','images','0','','0','','0000000026_00001_00','0','0','admin','1433746439','admin','1433746439'),
 ('00001','00','0000000027','0000000026','file','leaf','template1.gif','2181','2.2KB','7000','100x70','0000000027_00001_00','0','0','admin','1433746439','admin','1433746439'),
 ('00001','00','0000000028','0000000026','file','leaf','template2.gif','333','0.4KB','7000','100x70','0000000028_00001_00','1','0','admin','1433746439','admin','1433746439'),
 ('00001','00','0000000029','0000000026','file','leaf','template3.gif','2242','2.2KB','7000','100x70','0000000029_00001_00','2','0','admin','1433746440','admin','1433746440'),
 ('00001','00','0000000030','0000000025','file','leaf','default.js','603','0.6KB','0','','0000000030_00001_00','1','0','admin','1433746440','admin','1433746440'),
 ('00001','00','0000000031','0000000006','folder','folder','article3','0','','0','','0000000031_00001_00','2','0','admin','1433746440','admin','1433746440'),
 ('00001','00','0000000032','0000000031','folder','folder','css','0','','0','','0000000032_00001_00','0','0','admin','1433746440','admin','1433746440'),
 ('00001','00','0000000033','0000000032','file','leaf','default.css','1841','1.8KB','0','','0000000033_00001_00','0','0','admin','1433746440','admin','1433746440'),
 ('00001','00','0000000034','0000000031','folder','folder','styles','0','','0','','0000000034_00001_00','1','0','admin','1433746440','admin','1433746440'),
 ('00001','00','0000000035','0000000034','file','leaf','styles.js','3662','3.6KB','0','','0000000035_00001_00','0','0','admin','1433746440','admin','1433746440'),
 ('00001','00','0000000036','0000000031','folder','folder','templates','0','','0','','0000000036_00001_00','2','0','admin','1433746440','admin','1433746440'),
 ('00001','00','0000000037','0000000036','folder','folder','images','0','','0','','0000000037_00001_00','0','0','admin','1433746440','admin','1433746440'),
 ('00001','00','0000000038','0000000037','file','leaf','template1.gif','2181','2.2KB','7000','100x70','0000000038_00001_00','0','0','admin','1433746440','admin','1433746440'),
 ('00001','00','0000000039','0000000037','file','leaf','template2.gif','333','0.4KB','7000','100x70','0000000039_00001_00','1','0','admin','1433746440','admin','1433746440'),
 ('00001','00','0000000040','0000000037','file','leaf','template3.gif','2242','2.2KB','7000','100x70','0000000040_00001_00','2','0','admin','1433746440','admin','1433746440'),
 ('00001','00','0000000041','0000000036','file','leaf','default.js','603','0.6KB','0','','0000000041_00001_00','1','0','admin','1433746440','admin','1433746440');
/*!40000 ALTER TABLE `%PREFIX%resource_node` ENABLE KEYS */;


--
-- Definition of table `%PREFIX%settings`
--

DROP TABLE IF EXISTS `%PREFIX%settings`;
CREATE TABLE `%PREFIX%settings` (
  `id` char(5) NOT NULL default '',
  `site_title` text,
  `admin_site_title` text,
  `memo` text,
  `reserve1` text,
  `reserve2` text,
  `reserve3` text,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `%PREFIX%settings`
--

/*!40000 ALTER TABLE `%PREFIX%settings` DISABLE KEYS */;
INSERT INTO `%PREFIX%settings` (`id`,`site_title`,`admin_site_title`,`memo`,`reserve1`,`reserve2`,`reserve3`) VALUES 
 ('00001','','B-studio Contents Management System','','','','');
/*!40000 ALTER TABLE `%PREFIX%settings` ENABLE KEYS */;


--
-- Definition of table `%PREFIX%template`
--

DROP TABLE IF EXISTS `%PREFIX%template`;
CREATE TABLE `%PREFIX%template` (
  `version_id` char(5) NOT NULL default '',
  `revision_id` char(2) NOT NULL default '',
  `contents_id` char(10) NOT NULL default '',
  `contents_date` char(10) default NULL,
  `template_id` char(10) default NULL,
  `start_html` mediumtext,
  `end_html` mediumtext,
  `css` mediumtext,
  `php` mediumtext,
  `external_css` text,
  `external_js` text,
  `header_element` text,
  `del_flag` char(1) default NULL,
  `reserve1` text,
  `reserve2` text,
  `reserve3` text,
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text,
  PRIMARY KEY  (`version_id`,`revision_id`,`contents_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `%PREFIX%template`
--

/*!40000 ALTER TABLE `%PREFIX%template` DISABLE KEYS */;
INSERT INTO `%PREFIX%template` (`version_id`,`revision_id`,`contents_id`,`contents_date`,`template_id`,`start_html`,`end_html`,`css`,`php`,`external_css`,`external_js`,`header_element`,`del_flag`,`reserve1`,`reserve2`,`reserve3`,`create_user`,`create_datetime`,`update_user`,`update_datetime`) VALUES 
 ('00001','00','0000000001','','','<body>\r\n	<div id=\"header-wrapper\">\r\n		<div id=\"header\">\r\n			<p id=\"logo\">\r\n				<a href=\".\" >LOGO HERE</a>\r\n			</p>\r\n	\r\n			<?php widget(\'0000000001\'); // navi ?>\r\n		</div>\r\n	</div>\r\n	\r\n	<div id=\"wrapper\">\r\n		<div id=\"contents\">\r\n','		</div>\r\n	</div>\r\n\r\n	<div id=\"footer-wrapper\">\r\n		<div id=\"footer\">\r\n			<?php widget(\'0000000004\'); // site_map ?>\r\n		</div>\r\n	\r\n		<p class=\"copyright\">\r\n			copyright &copy; <?php echo date(\'Y\', time()); ?> site-name all rights reserved\r\n		</p>\r\n	</div>\r\n</body>','@charset \'UTF-8\';\r\n\r\n/* clear fix */\r\n.clearfix:after {\r\n	content: \"\"; \r\n	display: block; \r\n	clear: both;\r\n}\r\n\r\nbody {\r\n	margin: 0;\r\n	padding: 0;\r\n	background-color: #fff;\r\n	color: #555;\r\n	font-family: \"メイリオ\", \"Meiryo\", \"ヒラギノ角ゴ Pro W3\", \"Hiragino Kaku Gothic Pro\", \"Osaka\", verdana, lucida, arial, helvetica, sans-serif;\r\n	font-size: 17px;\r\n}\r\nh1 {\r\n	margin: 22px 0;\r\n	font-size: 34px;\r\n}\r\nh2 {\r\n	margin: 20px 0;\r\n	font-size: 26px;\r\n}\r\nh3 {\r\n	margin: 0;\r\n	font-size: 17px;\r\n	font-weight: normal;\r\n}\r\na:link,\r\na:visited {\r\n	text-decoration: none;\r\n	color: #555;\r\n	outline: none;\r\n}\r\n#header-wrapper {\r\n	border-bottom: 1px solid #999;\r\n	overflow: hidden;\r\n}\r\n#header {\r\n	margin: 0 auto;\r\n	width: 1000px;\r\n}\r\n#logo {\r\n	float: left;\r\n	margin: 0;\r\n	padding: 18px 200px 12px 10px;\r\n	font-family: helvetica, sans-serif;\r\n	font-size: 20px;\r\n	font-weight: bold;\r\n}\r\n#wrapper {\r\n	width: 1000px;\r\n	margin: 0 auto;\r\n}\r\n#footer-wrapper {\r\n	background-color: #333;\r\n	color: #fff;\r\n}\r\n#footer {\r\n	width: 1000px;\r\n	margin: 0 auto;\r\n	padding: 10px 0;\r\n}\r\n#footer .sitemap {\r\n	margin: 0;\r\n	padding: 10px 0 0 0;\r\n	list-style: none;\r\n	height: 100px;\r\n	font-size: 13px;\r\n}\r\n#footer .sitemap li {\r\n	float: left;\r\n	margin-left: 35px;\r\n}\r\n#footer .sitemap li:first-child {\r\n	margin-left: 20px;\r\n}\r\n#footer-wrapper p.copyright {\r\n	margin: 0;\r\n	padding: 0 40px 15px 0;\r\n	text-align: right;\r\n	font-size: 12px;\r\n}','','','','','0','','','','admin','1392242646','admin','1411161856'),
 ('00001','00','0000000002','','','','','.contents-box {\r\n	margin: 20px 0 60px 0;\r\n	padding: 0 10px;\r\n	font-size: 16px;\r\n}\r\n.contents-box p {\r\n	margin: 6px 0;\r\n}\r\n.contents-box .overflow-none {\r\n	overflow: hidden;\r\n}\r\n.right {\r\n	float: right;\r\n	margin-left: 40px;\r\n}\r\n.left {\r\n	float: left;\r\n	margin-right: 40px;\r\n}\r\n.center {\r\n	text-align: center;\r\n	padding-bottom: 40px;\r\n}\r\n.more-info {\r\n	text-align: right;\r\n	font-weight: normal;\r\n	\r\n}\r\n.more-info {\r\n	margin: 20px 0;\r\n}\r\n.more-info a:link,\r\n.more-info a:visited {\r\n	color: #0088cc;\r\n	text-decoration: none;\r\n}\r\n.more-info a:hover {\r\n	text-decoration: underline;\r\n}\r\n.contents-box .shortcut-list {\r\n	text-align: left;\r\n	margin-left: 20px;\r\n	width: 100%;\r\n}\r\n.contents-box .shortcut-list th {\r\n	font-weight: normal;\r\n	width: 300px;\r\n}\r\n.contents-box .icon-list {\r\n	text-align: left;\r\n	margin: 8px 0 0 10px;\r\n	width: 100%;\r\n}\r\n.contents-box .icon-list th {\r\n	padding: 2px;\r\n	width: 40px;\r\n}\r\nspan.icon {\r\n	background-color: #3a3a3a;\r\n	padding: 2px 8px;\r\n}\r\nspan.icon img {\r\n	vertical-align: -4px;\r\n}\r\nspan.caution {\r\n	color: #d33;\r\n}\r\n','','','','','0','','','','admin','1392524260','admin','1392541259');
/*!40000 ALTER TABLE `%PREFIX%template` ENABLE KEYS */;


--
-- Definition of table `%PREFIX%template_node`
--

DROP TABLE IF EXISTS `%PREFIX%template_node`;
CREATE TABLE `%PREFIX%template_node` (
  `version_id` char(5) NOT NULL default '',
  `revision_id` char(2) NOT NULL default '',
  `node_id` char(10) NOT NULL default '',
  `parent_node` char(10) default NULL,
  `node_type` char(10) default NULL,
  `node_class` char(10) default NULL,
  `node_name` text,
  `contents_id` char(10) default NULL,
  `disp_seq` int(11) default NULL,
  `del_flag` char(1) default NULL,
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text,
  PRIMARY KEY  (`version_id`,`revision_id`,`node_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `%PREFIX%template_node`
--

/*!40000 ALTER TABLE `%PREFIX%template_node` DISABLE KEYS */;
INSERT INTO `%PREFIX%template_node` (`version_id`,`revision_id`,`node_id`,`parent_node`,`node_type`,`node_class`,`node_name`,`contents_id`,`disp_seq`,`del_flag`,`create_user`,`create_datetime`,`update_user`,`update_datetime`) VALUES 
 ('00001','00','0000000001','root','template','template','global','0000000001','0','0','admin','1392242544','admin','1392242548'),
 ('00001','00','0000000002','0000000001','template','template','function','0000000002','0','0','admin','1392443029','admin','1392524245'),
 ('00001','00','0000000003','0000000001','template','template','company','','1','0','admin','1392443048','admin','1392443056'),
 ('00001','00','0000000004','0000000001','template','template','products','','2','0','admin','1392443060','admin','1392443070');
/*!40000 ALTER TABLE `%PREFIX%template_node` ENABLE KEYS */;


--
-- Definition of table `%PREFIX%user`
--

DROP TABLE IF EXISTS `%PREFIX%user`;
CREATE TABLE `%PREFIX%user` (
  `id` char(10) NOT NULL default '',
  `user_id` char(10) default NULL,
  `pwd` char(20) default NULL,
  `user_status` text,
  `user_auth` text,
  `f_name` text,
  `g_name` text,
  `email` text,
  `memo` text,
  `del_flag` char(1) default NULL,
  `reserve1` text,
  `reserve2` text,
  `reserve3` text,
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `%PREFIX%user`
--

/*!40000 ALTER TABLE `%PREFIX%user` DISABLE KEYS */;
/*!40000 ALTER TABLE `%PREFIX%user` ENABLE KEYS */;


--
-- Definition of table `%PREFIX%version`
--

DROP TABLE IF EXISTS `%PREFIX%version`;
CREATE TABLE `%PREFIX%version` (
  `version_id` char(5) NOT NULL default '',
  `private_revision_id` char(2) default NULL,
  `publication_datetime_t` text,
  `publication_datetime_u` text,
  `publication_status` char(1) default NULL,
  `version` text,
  `memo` text,
  `del_flag` char(1) default NULL,
  `reserve1` text,
  `reserve2` text,
  `reserve3` text,
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text,
  PRIMARY KEY  (`version_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `%PREFIX%version`
--

/*!40000 ALTER TABLE `%PREFIX%version` DISABLE KEYS */;
INSERT INTO `%PREFIX%version` (`version_id`,`private_revision_id`,`publication_datetime_t`,`publication_datetime_u`,`publication_status`,`version`,`memo`,`del_flag`,`reserve1`,`reserve2`,`reserve3`,`create_user`,`create_datetime`,`update_user`,`update_datetime`) VALUES 
 ('00001','00','2014/02/13 07:01','1392242480','','V1.0','初期バージョン','0','','','','installer','1392242480','','');
/*!40000 ALTER TABLE `%PREFIX%version` ENABLE KEYS */;


--
-- Definition of table `%PREFIX%widget`
--

DROP TABLE IF EXISTS `%PREFIX%widget`;
CREATE TABLE `%PREFIX%widget` (
  `version_id` char(5) NOT NULL default '',
  `revision_id` char(2) NOT NULL default '',
  `contents_id` char(10) NOT NULL default '',
  `contents_date` char(10) default NULL,
  `widget_id` char(10) default NULL,
  `html` text,
  `css` text,
  `php` text,
  `del_flag` char(1) default NULL,
  `reserve1` text,
  `reserve2` text,
  `reserve3` text,
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text,
  PRIMARY KEY  (`version_id`,`revision_id`,`contents_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `%PREFIX%widget`
--

/*!40000 ALTER TABLE `%PREFIX%widget` DISABLE KEYS */;
INSERT INTO `%PREFIX%widget` (`version_id`,`revision_id`,`contents_id`,`contents_date`,`widget_id`,`html`,`css`,`php`,`del_flag`,`reserve1`,`reserve2`,`reserve3`,`create_user`,`create_datetime`,`update_user`,`update_datetime`) VALUES 
 ('00001','00','0000000001','','','<?php echo $navi->getHtml(); ?>','#gnavi {\r\n	float: left;\r\n	list-style: none;\r\n	margin: 0;\r\n	padding: 0;\r\n	font-size: 14px;\r\n}\r\n#gnavi li {\r\n	float: left;\r\n	width: 140px;\r\n	border-right: 1px solid #999;\r\n	text-align: center;\r\n	padding: 0;\r\n}\r\n#gnavi li:first-child {\r\n	border-left: 1px solid #999;\r\n}\r\n#gnavi li a {\r\n	display: block;\r\n	padding: 20px 0;\r\n	height: 100%;\r\n}\r\n#gnavi li a:hover {\r\n	color: #999;\r\n}\r\n','<?php\r\n	global $global_navi;\r\n	\r\n	$config =\r\n	array(\r\n		\'start_html\'	=> \'<ul class=\"clearfix\" id=\"gnavi\">\',\r\n		\'end_html\'		=> \'</ul>\',\r\n		array(\r\n			\'name\'			=> \'category1\',\r\n			\'start_html\'	=> \'<li>\',\r\n			\'start_html_c\'	=> \'<li class=\"current\">\',\r\n			\'end_html\'		=> \'</li>\',\r\n			\'value\'			=> \'<a href=\"category1\" >CATEGORY1</a>\',\r\n		),\r\n		array(\r\n			\'name\'			=> \'category2\',\r\n			\'start_html\'	=> \'<li>\',\r\n			\'start_html_c\'	=> \'<li class=\"current\">\',\r\n			\'end_html\'		=> \'</li>\',\r\n			\'value\'			=> \'<a href=\"category2\" >CATEGORY2</a>\',\r\n		),\r\n		array(\r\n			\'name\'			=> \'category3\',\r\n			\'start_html\'	=> \'<li>\',\r\n			\'start_html_c\'	=> \'<li class=\"current\">\',\r\n			\'end_html\'		=> \'</li>\',\r\n			\'value\'			=> \'<a href=\"category3\" >CATEGORY3</a>\',\r\n		),\r\n		array(\r\n			\'name\'			=> \'category4\',\r\n			\'start_html\'	=> \'<li>\',\r\n			\'start_html_c\'	=> \'<li class=\"current\">\',\r\n			\'end_html\'		=> \'</li>\',\r\n			\'value\'			=> \'<a href=\"category4\" >CATEGORY4</a>\',\r\n		),\r\n	);\r\n	\r\n	$navi = new B_Element($config);\r\n	\r\n	if($global_navi) {\r\n		$obj = $navi->getElementByName($global_navi);\r\n		if($obj) $obj->start_html = $obj->start_html_c;\r\n	}\r\n?>','0','','','','admin','1392434102','admin','1398238345'),
 ('00001','00','0000000002','','','<ul class=\"news\">\r\n	<?php echo $news_list->getHtml(); ?>\r\n</ul>','.news {\r\n	list-style: none;\r\n	margin: 0;\r\n	padding: 10px 0 10px 20px;\r\n	font-family: \"メイリオ\", \"Meiryo\", \"ヒラギノ角ゴ Pro W3\", \"Hiragino Kaku Gothic Pro\", \"Osaka\", verdana, lucida, arial, helvetica, sans-serif;\r\n	border: 1px solid #999;\r\n}\r\n.news li {\r\n	margin: 10px 0;\r\n}\r\n.news li .datetime {\r\n	font-size: 15px;\r\n	font-weight: bold;\r\n	line-height: 24px;\r\n}\r\n.news li span.category {\r\n	color: #fff;\r\n	padding: 2px 8px 0 8px;\r\n	margin-left: 10px;\r\n	font-size: 12px;\r\n}\r\n.news li .title {\r\n	padding-left: 20px;\r\n	font-size: 17px;\r\n}\r\n.news li .title a:link,\r\n.news li .title a:visited {\r\n	color: #555;\r\n	text-decoration: none;\r\n}\r\n.news li .title a:hover {\r\n	color: #999;\r\n}\r\n','<?php\r\n	$config =\r\n	array(\r\n		\'select_sql\'	=> \"select * from \" . B_ARTICLE_VIEW . \" where 1=1 \",\r\n		\'row\'			=>\r\n		array(\r\n			array(\r\n				\'start_html\'	=> \'<li>\',\r\n				\'end_html\'		=> \'</li>\',\r\n				array(\r\n					\'start_html\'	=> \'<div class=\"datetime\">\',\r\n					\'end_html\'		=> \'</div>\',\r\n					array(\r\n						\'name\'			=> \'article_date_t\',\r\n					),\r\n					array(\r\n						\'name\'			=> \'category\',\r\n						\'start_html\'	=> \'<span class=\"category\">\',\r\n						\'end_html\'		=> \'</span>\',\r\n					),\r\n				),\r\n				array(\r\n					\'name\'			=> \'detail_link\',\r\n					\'class\'			=> \'B_Link\',\r\n					\'start_html\'	=> \'<div class=\"title\">\',\r\n					\'end_html\'		=> \'</div>\',\r\n					\'link\'			=> \'news/detail\',\r\n					\'parmalink\'		=>\r\n					array(\r\n						\'id\'		=> \'article_id\',\r\n					),\r\n					array(\r\n						\'name\'			=> \'title\',\r\n						\'class\'			=> \'B_TextField\',\r\n						\'specialchars\'	=> \'none\',\r\n					),\r\n				),\r\n			),\r\n			array(\r\n				\'class\'			=> \'B_Data\',\r\n				\'name\'			=> \'color\',\r\n			),\r\n			array(\r\n				\'class\'			=> \'B_Data\',\r\n				\'name\'			=> \'background_color\',\r\n			),\r\n			array(\r\n				\'class\'			=> \'B_Data\',\r\n				\'name\'			=> \'icon_file\',\r\n			),\r\n			array(\r\n				\'class\'			=> \'B_Data\',\r\n				\'name\'			=> \'article_date_u\',\r\n			),\r\n			array(\r\n				\'class\'			=> \'B_Data\',\r\n				\'name\'			=> \'external_link\',\r\n			),\r\n			array(\r\n				\'class\'			=> \'B_Data\',\r\n				\'name\'			=> \'url\',\r\n			),\r\n			array(\r\n				\'class\'			=> \'B_Data\',\r\n				\'name\'			=> \'external_window\',\r\n			),\r\n			array(\r\n				\'class\'			=> \'B_Data\',\r\n				\'name\'			=> \'description_flag\',\r\n			),\r\n		),\r\n	);\r\n	\r\n	$news_list = new B_DataGrid($bs_db, $config);\r\n	$news_list->setCallBack(null, \'_call_back\');\r\n	$news_list->setSqlOrderBy(\" order by article_date_u desc, article_id desc \");\r\n	$news_list->setRowPerPage(4);\r\n	$news_list->setPage(1);\r\n	$news_list->bind();\r\n\r\n	function _call_back($param) {\r\n		$util = new B_Util();\r\n		$row = $param[\'row\'];\r\n\r\n		$date_u = $row->getElementByName(\'article_date_u\');\r\n		$date_t = $row->getElementByName(\'article_date_t\');\r\n		$date_t->value = date(\'M. jS, Y\', $date_u->value);\r\n		\r\n		// カテゴリ設定\r\n		$icon_file = $row->getElementByName(\'icon_file\');\r\n		$category = $row->getElementByName(\'category\');\r\n		// アイコン\r\n		if($icon_file->value) {\r\n			$category->value = \'<img src=\"\' . B_Util::getPath(B_UPLOAD_URL, $icon_file->value) . \'\" alt=\"\' . $category->value . \'\" />\';\r\n		}\r\n		// 文字色\r\n		$color = $row->getElementByName(\'color\');\r\n		if($color->value) {\r\n			$style.= \'color:\' . $color->value . \';\';\r\n		}\r\n		// 背景色\r\n		$background_color = $row->getElementByName(\'background_color\');\r\n		if($background_color->value) {\r\n			$style.= \'background-color:\' . $background_color->value . \';\';\r\n		}\r\n		if($style) {\r\n			$category->start_html = \'<span class=\"category\" style=\"\' . $style . \'\">\';\r\n		}\r\n\r\n		// リンク設定\r\n		$description_flag = $row->getElementByName(\'description_flag\');\r\n		$detail_link = $row->getElementByName(\'detail_link\');\r\n		if($description_flag->value != \'1\') {\r\n			// 詳細表示なし\r\n			$external_link = $row->getElementByName(\'external_link\');\r\n			if($external_link->value == \'1\') {\r\n				$url = $row->getElementByName(\'url\');\r\n				$detail_link->link = $url->value;\r\n				unset($detail_link->param);\r\n\r\n				$external_window = $row->getElementByName(\'external_window\');\r\n				if($external_window->value == \'1\') {\r\n					$detail_link->special_html = \'onclick=\"window.open(this.href); return false;\"\';\r\n				}\r\n			}\r\n			else {\r\n				$detail_link->link = \'none\';\r\n			}\r\n		}\r\n	}\r\n?>','0','','','','admin','1393122518','admin','1432798242'),
 ('00001','00','0000000003','','','<ul class=\"news\">\r\n	<?php echo $news_list->getHtml(); ?>\r\n</ul>','.news {\r\n	list-style: none;\r\n	margin: 0;\r\n	padding: 10px 0 10px 20px;\r\n	font-family: \"メイリオ\", \"Meiryo\", \"ヒラギノ角ゴ Pro W3\", \"Hiragino Kaku Gothic Pro\", \"Osaka\", verdana, lucida, arial, helvetica, sans-serif;\r\n}\r\n.news li {\r\n	margin: 10px 0;\r\n}\r\n.news li .datetime {\r\n	font-size: 15px;\r\n	font-weight: bold;\r\n	line-height: 24px;\r\n}\r\n.news li span.category {\r\n	color: #fff;\r\n	padding: 2px 8px 0 8px;\r\n	margin-left: 10px;\r\n	font-size: 12px;\r\n}\r\n.news li .title {\r\n	padding-left: 20px;\r\n	font-size: 17px;\r\n}\r\n.news li .title a:link,\r\n.news li .title a:visited {\r\n	color: #555;\r\n	text-decoration: none;\r\n}\r\n.news li .title a:hover {\r\n	color: #999;\r\n}\r\n','<?php\r\n	$config =\r\n	array(\r\n		\'select_sql\'	=> \"select * from \" . B_ARTICLE_VIEW . \" where 1=1 \",\r\n		\'row\'			=>\r\n		array(\r\n			array(\r\n				\'start_html\'	=> \'<li>\',\r\n				\'end_html\'		=> \'</li>\',\r\n				array(\r\n					\'start_html\'	=> \'<div class=\"datetime\">\',\r\n					\'end_html\'		=> \'</div>\',\r\n					array(\r\n						\'name\'			=> \'article_date_t\',\r\n					),\r\n					array(\r\n						\'name\'			=> \'category\',\r\n						\'start_html\'	=> \'<span class=\"category\">\',\r\n						\'end_html\'		=> \'</span>\',\r\n					),\r\n				),\r\n				array(\r\n					\'name\'			=> \'detail_link\',\r\n					\'class\'			=> \'B_Link\',\r\n					\'start_html\'	=> \'<div class=\"title\">\',\r\n					\'end_html\'		=> \'</div>\',\r\n					\'link\'			=> \'news/detail\',\r\n					\'parmalink\'		=>\r\n					array(\r\n						\'id\'		=> \'article_id\',\r\n					),\r\n					array(\r\n						\'name\'			=> \'title\',\r\n						\'class\'			=> \'B_TextField\',\r\n						\'specialchars\'	=> \'none\',\r\n					),\r\n				),\r\n			),\r\n			array(\r\n				\'class\'			=> \'B_Data\',\r\n				\'name\'			=> \'color\',\r\n			),\r\n			array(\r\n				\'class\'			=> \'B_Data\',\r\n				\'name\'			=> \'background_color\',\r\n			),\r\n			array(\r\n				\'class\'			=> \'B_Data\',\r\n				\'name\'			=> \'icon_file\',\r\n			),\r\n			array(\r\n				\'class\'			=> \'B_Data\',\r\n				\'name\'			=> \'article_date_u\',\r\n			),\r\n			array(\r\n				\'class\'			=> \'B_Data\',\r\n				\'name\'			=> \'external_link\',\r\n			),\r\n			array(\r\n				\'class\'			=> \'B_Data\',\r\n				\'name\'			=> \'url\',\r\n			),\r\n			array(\r\n				\'class\'			=> \'B_Data\',\r\n				\'name\'			=> \'external_window\',\r\n			),\r\n			array(\r\n				\'class\'			=> \'B_Data\',\r\n				\'name\'			=> \'description_flag\',\r\n			),\r\n		),\r\n	);\r\n\r\n	$news_list = new B_DataGrid($bs_db, $config);\r\n	$news_list->setCallBack(null, \'_call_back\');\r\n	$news_list->setSqlOrderBy(\" order by article_date_u desc, article_id desc \");\r\n	$news_list->setRowPerPage(\'all\');\r\n	$news_list->setPage(1);\r\n	$news_list->bind();\r\n\r\n	function _call_back($param) {\r\n		$util = new B_Util();\r\n		$row = $param[\'row\'];\r\n\r\n		$date_u = $row->getElementByName(\'article_date_u\');\r\n		$date_t = $row->getElementByName(\'article_date_t\');\r\n		$date_t->value = date(\'M. jS, Y\', $date_u->value);\r\n		\r\n		// カテゴリ設定\r\n		$icon_file = $row->getElementByName(\'icon_file\');\r\n		$category = $row->getElementByName(\'category\');\r\n		// アイコン\r\n		if($icon_file->value) {\r\n			$category->value = \'<img src=\"\' . B_Util::getPath(B_UPLOAD_URL, $icon_file->value) . \'\" alt=\"\' . $category->value . \'\" />\';\r\n		}\r\n		// 文字色\r\n		$color = $row->getElementByName(\'color\');\r\n		if($color->value) {\r\n			$style.= \'color:\' . $color->value . \';\';\r\n		}\r\n		// 背景色\r\n		$background_color = $row->getElementByName(\'background_color\');\r\n		if($background_color->value) {\r\n			$style.= \'background-color:\' . $background_color->value . \';\';\r\n		}\r\n		if($style) {\r\n			$category->start_html = \'<span class=\"category\" style=\"\' . $style . \'\">\';\r\n		}\r\n\r\n		// リンク設定\r\n		$description_flag = $row->getElementByName(\'description_flag\');\r\n		$detail_link = $row->getElementByName(\'detail_link\');\r\n		if($description_flag->value != \'1\') {\r\n			// 詳細表示なし\r\n			$external_link = $row->getElementByName(\'external_link\');\r\n			if($external_link->value == \'1\') {\r\n				$url = $row->getElementByName(\'url\');\r\n				$detail_link->link = $url->value;\r\n				unset($detail_link->param);\r\n\r\n				$external_window = $row->getElementByName(\'external_window\');\r\n				if($external_window->value == \'1\') {\r\n					$detail_link->special_html = \'onclick=\"window.open(this.href); return false;\"\';\r\n				}\r\n			}\r\n			else {\r\n				$detail_link->link = \'none\';\r\n			}\r\n		}\r\n	}\r\n?>','0','','','','admin','1393223792','admin','1432797962'),
 ('00001','00','0000000004','','','<ul class=\"sitemap\">\r\n	<li><a href=\".\">HOME</a></li>\r\n	<li><a href=\"category1\">CATEGORY1</a></li>\r\n	<li><a href=\"category2\">CATEGORY2</a></li>\r\n	<li><a href=\"category3\">CATEGORY3</a></li>\r\n	<li><a href=\"category4\">CATEGORY4</a></li>\r\n</ul>\r\n','.sitemap a:link,\r\n.sitemap a:visited {\r\n	color: #fff;\r\n}\r\n.sitemap a:hover {\r\n	color: #ccc;\r\n}','','0','','','','admin','1393225648','admin','1393236749'),
 ('00001','00','0000000005','','','<div id=\"breadcrumbs\">\r\n	<?php echo $html; ?>\r\n</div>\r\n','','<?php\r\n	for($i=0 ; $i<count($bs_breadcrumbs)-1; $i++) {\r\n		if(trim($bs_breadcrumbs[$i][\'value\']) == \'\') continue;\r\n\r\n		$item = \'<a href=\"\' . $bs_breadcrumbs[$i][\'url\'] . \'\" \';\r\n		$item.= \'title=\"\' . $bs_breadcrumbs[$i][\'value\'] . \'へ\">\';\r\n		$item.= $bs_breadcrumbs[$i][\'value\'] . \'</a>\';\r\n		$bc[] = $item;\r\n	}\r\n	$bc[] = $bs_breadcrumbs[$i][\'value\'];\r\n	$html = implode(\'&nbsp;&gt;&nbsp;\', $bc);\r\n?>','0','','','','admin','1421628423','admin','1421631069');
/*!40000 ALTER TABLE `%PREFIX%widget` ENABLE KEYS */;


--
-- Definition of table `%PREFIX%widget_node`
--

DROP TABLE IF EXISTS `%PREFIX%widget_node`;
CREATE TABLE `%PREFIX%widget_node` (
  `version_id` char(5) NOT NULL default '',
  `revision_id` char(2) NOT NULL default '',
  `node_id` char(10) NOT NULL default '',
  `parent_node` char(10) default NULL,
  `node_type` char(10) default NULL,
  `node_class` char(10) default NULL,
  `node_name` text,
  `contents_id` char(10) default NULL,
  `disp_seq` int(11) default NULL,
  `del_flag` char(1) default NULL,
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text,
  PRIMARY KEY  (`version_id`,`revision_id`,`node_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `%PREFIX%widget_node`
--

/*!40000 ALTER TABLE `%PREFIX%widget_node` DISABLE KEYS */;
INSERT INTO `%PREFIX%widget_node` (`version_id`,`revision_id`,`node_id`,`parent_node`,`node_type`,`node_class`,`node_name`,`contents_id`,`disp_seq`,`del_flag`,`create_user`,`create_datetime`,`update_user`,`update_datetime`) VALUES 
 ('00001','00','0000000001','root','widget','leaf','navi','0000000001','0','0','admin','1392433728','admin','1393226596'),
 ('00001','00','0000000002','root','widget','leaf','news_top','0000000002','2','0','admin','1393122470','admin','1393226596'),
 ('00001','00','0000000003','root','widget','leaf','news_list','0000000003','3','0','admin','1393223792','admin','1393226596'),
 ('00001','00','0000000004','root','widget','leaf','site_map','0000000004','1','0','admin','1393225648','admin','1393226596'),
 ('00001','00','0000000005','root','widget','leaf','breadcrumbs','0000000005','4','0','admin','1421628364','admin','1421628370');
/*!40000 ALTER TABLE `%PREFIX%widget_node` ENABLE KEYS */;


--
-- Definition of view `%PREFIX%v_admin_article`
--

DROP TABLE IF EXISTS `%PREFIX%v_admin_article`;
DROP VIEW IF EXISTS `%PREFIX%v_admin_article`;
CREATE   VIEW `%PREFIX%v_admin_article` AS select `a`.`article_id` AS `article_id`,`a`.`article_date_t` AS `article_date_t`,`a`.`article_date_u` AS `article_date_u`,`a`.`category_id` AS `category_id`,`a`.`tag` AS `tag`,`a`.`publication` AS `publication`,`a`.`title` AS `title`,`a`.`title_img_file` AS `title_img_file`,`a`.`description_flag` AS `description_flag`,`a`.`external_link` AS `external_link`,`a`.`external_window` AS `external_window`,`a`.`url` AS `url`,`a`.`description` AS `description`,`a`.`del_flag` AS `del_flag`,`a`.`folder_id` AS `folder_id`,`a`.`reserve1` AS `reserve1`,`a`.`reserve2` AS `reserve2`,`a`.`reserve3` AS `reserve3`,`a`.`create_user` AS `create_user`,`a`.`create_datetime` AS `create_datetime`,`a`.`update_user` AS `update_user`,`a`.`update_datetime` AS `update_datetime`,concat(`a`.`article_date_u`,`a`.`article_id`) AS `article_date`,`b`.`node_name` AS `category`,`b`.`color` AS `color`,`b`.`background_color` AS `background_color`,`b`.`icon_file` AS `icon_file` from (`%PREFIX%article` `a` left join `%PREFIX%v_category` `b` on((`a`.`category_id` = `b`.`node_id`))) where ((`a`.`del_flag` = _utf8'0') and (`a`.`publication` in (_utf8'1',_utf8'2')));

--
-- Definition of view `%PREFIX%v_admin_article2`
--

DROP TABLE IF EXISTS `%PREFIX%v_admin_article2`;
DROP VIEW IF EXISTS `%PREFIX%v_admin_article2`;
CREATE   VIEW `%PREFIX%v_admin_article2` AS select `a`.`article_id` AS `article_id`,`a`.`article_date_t` AS `article_date_t`,`a`.`article_date_u` AS `article_date_u`,`a`.`category_id` AS `category_id`,`a`.`tag` AS `tag`,`a`.`publication` AS `publication`,`a`.`title` AS `title`,`a`.`title_img_file` AS `title_img_file`,`a`.`description_flag` AS `description_flag`,`a`.`external_link` AS `external_link`,`a`.`external_window` AS `external_window`,`a`.`url` AS `url`,`a`.`description` AS `description`,`a`.`del_flag` AS `del_flag`,`a`.`folder_id` AS `folder_id`,`a`.`reserve1` AS `reserve1`,`a`.`reserve2` AS `reserve2`,`a`.`reserve3` AS `reserve3`,`a`.`create_user` AS `create_user`,`a`.`create_datetime` AS `create_datetime`,`a`.`update_user` AS `update_user`,`a`.`update_datetime` AS `update_datetime`,concat(`a`.`article_date_u`,`a`.`article_id`) AS `article_date`,`b`.`node_name` AS `category`,`b`.`color` AS `color`,`b`.`background_color` AS `background_color`,`b`.`icon_file` AS `icon_file` from (`%PREFIX%article2` `a` left join `%PREFIX%v_category2` `b` on((`a`.`category_id` = `b`.`node_id`))) where ((`a`.`del_flag` = _utf8'0') and (`a`.`publication` in (_utf8'1',_utf8'2')));

--
-- Definition of view `%PREFIX%v_admin_article3`
--

DROP TABLE IF EXISTS `%PREFIX%v_admin_article3`;
DROP VIEW IF EXISTS `%PREFIX%v_admin_article3`;
CREATE   VIEW `%PREFIX%v_admin_article3` AS select `a`.`article_id` AS `article_id`,`a`.`article_date_t` AS `article_date_t`,`a`.`article_date_u` AS `article_date_u`,`a`.`category_id` AS `category_id`,`a`.`tag` AS `tag`,`a`.`publication` AS `publication`,`a`.`title` AS `title`,`a`.`title_img_file` AS `title_img_file`,`a`.`description_flag` AS `description_flag`,`a`.`external_link` AS `external_link`,`a`.`external_window` AS `external_window`,`a`.`url` AS `url`,`a`.`description` AS `description`,`a`.`del_flag` AS `del_flag`,`a`.`folder_id` AS `folder_id`,`a`.`reserve1` AS `reserve1`,`a`.`reserve2` AS `reserve2`,`a`.`reserve3` AS `reserve3`,`a`.`create_user` AS `create_user`,`a`.`create_datetime` AS `create_datetime`,`a`.`update_user` AS `update_user`,`a`.`update_datetime` AS `update_datetime`,concat(`a`.`article_date_u`,`a`.`article_id`) AS `article_date`,`b`.`node_name` AS `category`,`b`.`color` AS `color`,`b`.`background_color` AS `background_color`,`b`.`icon_file` AS `icon_file` from (`%PREFIX%article3` `a` left join `%PREFIX%v_category3` `b` on((`a`.`category_id` = `b`.`node_id`))) where ((`a`.`del_flag` = _utf8'0') and (`a`.`publication` in (_utf8'1',_utf8'2')));

--
-- Definition of view `%PREFIX%v_article`
--

DROP TABLE IF EXISTS `%PREFIX%v_article`;
DROP VIEW IF EXISTS `%PREFIX%v_article`;
CREATE   VIEW `%PREFIX%v_article` AS select `a`.`article_id` AS `article_id`,`a`.`article_date_t` AS `article_date_t`,`a`.`article_date_u` AS `article_date_u`,`a`.`category_id` AS `category_id`,`a`.`tag` AS `tag`,`a`.`publication` AS `publication`,`a`.`title` AS `title`,`a`.`title_img_file` AS `title_img_file`,`a`.`description_flag` AS `description_flag`,`a`.`external_link` AS `external_link`,`a`.`external_window` AS `external_window`,`a`.`url` AS `url`,`a`.`description` AS `description`,`a`.`del_flag` AS `del_flag`,`a`.`folder_id` AS `folder_id`,`a`.`reserve1` AS `reserve1`,`a`.`reserve2` AS `reserve2`,`a`.`reserve3` AS `reserve3`,`a`.`create_user` AS `create_user`,`a`.`create_datetime` AS `create_datetime`,`a`.`update_user` AS `update_user`,`a`.`update_datetime` AS `update_datetime`,concat(`a`.`article_date_u`,`a`.`article_id`) AS `article_date`,`b`.`node_name` AS `category`,`b`.`color` AS `color`,`b`.`background_color` AS `background_color`,`b`.`icon_file` AS `icon_file` from (`%PREFIX%article` `a` left join `%PREFIX%v_category` `b` on((`a`.`category_id` = `b`.`node_id`))) where ((`a`.`del_flag` = _utf8'0') and (`a`.`publication` = _utf8'1'));

--
-- Definition of view `%PREFIX%v_article2`
--

DROP TABLE IF EXISTS `%PREFIX%v_article2`;
DROP VIEW IF EXISTS `%PREFIX%v_article2`;
CREATE   VIEW `%PREFIX%v_article2` AS select `a`.`article_id` AS `article_id`,`a`.`article_date_t` AS `article_date_t`,`a`.`article_date_u` AS `article_date_u`,`a`.`category_id` AS `category_id`,`a`.`tag` AS `tag`,`a`.`publication` AS `publication`,`a`.`title` AS `title`,`a`.`title_img_file` AS `title_img_file`,`a`.`description_flag` AS `description_flag`,`a`.`external_link` AS `external_link`,`a`.`external_window` AS `external_window`,`a`.`url` AS `url`,`a`.`description` AS `description`,`a`.`del_flag` AS `del_flag`,`a`.`folder_id` AS `folder_id`,`a`.`reserve1` AS `reserve1`,`a`.`reserve2` AS `reserve2`,`a`.`reserve3` AS `reserve3`,`a`.`create_user` AS `create_user`,`a`.`create_datetime` AS `create_datetime`,`a`.`update_user` AS `update_user`,`a`.`update_datetime` AS `update_datetime`,concat(`a`.`article_date_u`,`a`.`article_id`) AS `article_date`,`b`.`node_name` AS `category`,`b`.`color` AS `color`,`b`.`background_color` AS `background_color`,`b`.`icon_file` AS `icon_file` from (`%PREFIX%article2` `a` left join `%PREFIX%v_category2` `b` on((`a`.`category_id` = convert(`b`.`node_id` using utf8)))) where (`a`.`del_flag` = _utf8'0');

--
-- Definition of view `%PREFIX%v_article3`
--

DROP TABLE IF EXISTS `%PREFIX%v_article3`;
DROP VIEW IF EXISTS `%PREFIX%v_article3`;
CREATE   VIEW `%PREFIX%v_article3` AS select `a`.`article_id` AS `article_id`,`a`.`article_date_t` AS `article_date_t`,`a`.`article_date_u` AS `article_date_u`,`a`.`category_id` AS `category_id`,`a`.`tag` AS `tag`,`a`.`publication` AS `publication`,`a`.`title` AS `title`,`a`.`title_img_file` AS `title_img_file`,`a`.`description_flag` AS `description_flag`,`a`.`external_link` AS `external_link`,`a`.`external_window` AS `external_window`,`a`.`url` AS `url`,`a`.`description` AS `description`,`a`.`del_flag` AS `del_flag`,`a`.`folder_id` AS `folder_id`,`a`.`reserve1` AS `reserve1`,`a`.`reserve2` AS `reserve2`,`a`.`reserve3` AS `reserve3`,`a`.`create_user` AS `create_user`,`a`.`create_datetime` AS `create_datetime`,`a`.`update_user` AS `update_user`,`a`.`update_datetime` AS `update_datetime`,concat(`a`.`article_date_u`,`a`.`article_id`) AS `article_date`,`b`.`node_name` AS `category`,`b`.`color` AS `color`,`b`.`background_color` AS `background_color`,`b`.`icon_file` AS `icon_file` from (`%PREFIX%article3` `a` left join `%PREFIX%v_category3` `b` on((`a`.`category_id` = convert(`b`.`node_id` using utf8)))) where (`a`.`del_flag` = _utf8'0');

--
-- Definition of view `%PREFIX%v_c_contents`
--

DROP TABLE IF EXISTS `%PREFIX%v_c_contents`;
DROP VIEW IF EXISTS `%PREFIX%v_c_contents`;
CREATE   VIEW `%PREFIX%v_c_contents` AS select `a`.`version_id` AS `version_id`,`a`.`revision_id` AS `revision_id`,`a`.`contents_id` AS `contents_id`,`a`.`contents_date` AS `contents_date`,`a`.`template_id` AS `template_id`,`a`.`title` AS `title`,`a`.`breadcrumbs` AS `breadcrumbs`,`a`.`html1` AS `html1`,`a`.`html2` AS `html2`,`a`.`html3` AS `html3`,`a`.`html4` AS `html4`,`a`.`css` AS `css`,`a`.`php` AS `php`,`a`.`keywords` AS `keywords`,`a`.`description` AS `description`,`a`.`external_css` AS `external_css`,`a`.`external_js` AS `external_js`,`a`.`header_element` AS `header_element`,`a`.`del_flag` AS `del_flag`,`a`.`reserve1` AS `reserve1`,`a`.`reserve2` AS `reserve2`,`a`.`reserve3` AS `reserve3`,`a`.`create_user` AS `create_user`,`a`.`create_datetime` AS `create_datetime`,`a`.`update_user` AS `update_user`,`a`.`update_datetime` AS `update_datetime` from `%PREFIX%contents` `a` where (concat(`a`.`version_id`,`a`.`revision_id`) = (select max(concat(`b`.`version_id`,`b`.`revision_id`)) AS `max(concat(b.version_id, b.revision_id))` from ((`%PREFIX%contents` `b` join `%PREFIX%v_current_version` `c`) join `%PREFIX%version` `d`) where ((`a`.`contents_id` = `b`.`contents_id`) and (`b`.`version_id` = `d`.`version_id`) and (((`b`.`version_id` < `c`.`current_version_id`) and (`b`.`revision_id` < `d`.`private_revision_id`)) or ((`b`.`version_id` = `c`.`current_version_id`) and (`b`.`revision_id` <= `d`.`private_revision_id`)))) group by `b`.`contents_id`));

--
-- Definition of view `%PREFIX%v_c_contents_node`
--

DROP TABLE IF EXISTS `%PREFIX%v_c_contents_node`;
DROP VIEW IF EXISTS `%PREFIX%v_c_contents_node`;
CREATE   VIEW `%PREFIX%v_c_contents_node` AS select `a`.`version_id` AS `version_id`,`a`.`revision_id` AS `revision_id`,`a`.`node_id` AS `node_id`,`a`.`parent_node` AS `parent_node`,`a`.`node_type` AS `node_type`,`a`.`node_class` AS `node_class`,`a`.`node_name` AS `node_name`,`a`.`contents_id` AS `contents_id`,`a`.`disp_seq` AS `disp_seq`,`a`.`del_flag` AS `del_flag`,`a`.`create_user` AS `create_user`,`a`.`create_datetime` AS `create_datetime`,`a`.`update_user` AS `update_user`,`a`.`update_datetime` AS `update_datetime` from `%PREFIX%contents_node` `a` where (concat(`a`.`version_id`,`a`.`revision_id`) = (select max(concat(`b`.`version_id`,`b`.`revision_id`)) AS `max(concat(``b``.``version_id``,``b``.``revision_id``))` from ((`%PREFIX%contents_node` `b` join `%PREFIX%v_current_version` `c`) join `%PREFIX%version` `d`) where ((`a`.`node_id` = `b`.`node_id`) and (`b`.`version_id` = `d`.`version_id`) and (((`b`.`version_id` < convert(`c`.`current_version_id` using utf8)) and (`b`.`revision_id` < `d`.`private_revision_id`)) or ((`b`.`version_id` = convert(`c`.`current_version_id` using utf8)) and (`b`.`revision_id` <= `d`.`private_revision_id`)))) group by `b`.`node_id`));

--
-- Definition of view `%PREFIX%v_c_resource_node`
--

DROP TABLE IF EXISTS `%PREFIX%v_c_resource_node`;
DROP VIEW IF EXISTS `%PREFIX%v_c_resource_node`;
CREATE   VIEW `%PREFIX%v_c_resource_node` AS select `a`.`version_id` AS `version_id`,`a`.`revision_id` AS `revision_id`,`a`.`node_id` AS `node_id`,`a`.`parent_node` AS `parent_node`,`a`.`node_type` AS `node_type`,`a`.`node_class` AS `node_class`,`a`.`node_name` AS `node_name`,`a`.`file_size` AS `file_size`,`a`.`human_file_size` AS `human_file_size`,`a`.`image_size` AS `image_size`,`a`.`human_image_size` AS `human_image_size`,`a`.`contents_id` AS `contents_id`,`a`.`disp_seq` AS `disp_seq`,`a`.`del_flag` AS `del_flag`,`a`.`create_user` AS `create_user`,`a`.`create_datetime` AS `create_datetime`,`a`.`update_user` AS `update_user`,`a`.`update_datetime` AS `update_datetime` from `%PREFIX%resource_node` `a` where (concat(`a`.`version_id`,`a`.`revision_id`) = (select max(concat(`b`.`version_id`,`b`.`revision_id`)) AS `max(concat(b.version_id, b.revision_id))` from ((`%PREFIX%resource_node` `b` join `%PREFIX%v_current_version` `c`) join `%PREFIX%version` `d`) where ((`a`.`node_id` = `b`.`node_id`) and (`b`.`version_id` = `d`.`version_id`) and (((`b`.`version_id` < convert(`c`.`current_version_id` using utf8)) and (`b`.`revision_id` < `d`.`private_revision_id`)) or ((`b`.`version_id` = convert(`c`.`current_version_id` using utf8)) and (`b`.`revision_id` <= `d`.`private_revision_id`)))) group by `b`.`node_id`));

--
-- Definition of view `%PREFIX%v_c_template`
--

DROP TABLE IF EXISTS `%PREFIX%v_c_template`;
DROP VIEW IF EXISTS `%PREFIX%v_c_template`;
CREATE   VIEW `%PREFIX%v_c_template` AS select `a`.`version_id` AS `version_id`,`a`.`revision_id` AS `revision_id`,`a`.`contents_id` AS `contents_id`,`a`.`contents_date` AS `contents_date`,`a`.`template_id` AS `template_id`,`a`.`start_html` AS `start_html`,`a`.`end_html` AS `end_html`,`a`.`css` AS `css`,`a`.`php` AS `php`,`a`.`external_css` AS `external_css`,`a`.`external_js` AS `external_js`,`a`.`header_element` AS `header_element`,`a`.`del_flag` AS `del_flag`,`a`.`reserve1` AS `reserve1`,`a`.`reserve2` AS `reserve2`,`a`.`reserve3` AS `reserve3`,`a`.`create_user` AS `create_user`,`a`.`create_datetime` AS `create_datetime`,`a`.`update_user` AS `update_user`,`a`.`update_datetime` AS `update_datetime` from `%PREFIX%template` `a` where (concat(`a`.`version_id`,`a`.`revision_id`) = (select max(concat(`b`.`version_id`,`b`.`revision_id`)) AS `max(concat(``b``.``version_id``,``b``.``revision_id``))` from ((`%PREFIX%template` `b` join `%PREFIX%v_current_version` `c`) join `%PREFIX%version` `d`) where ((`a`.`contents_id` = `b`.`contents_id`) and (`b`.`version_id` = `d`.`version_id`) and (((`b`.`version_id` < convert(`c`.`current_version_id` using utf8)) and (`b`.`revision_id` < `d`.`private_revision_id`)) or ((`b`.`version_id` = convert(`c`.`current_version_id` using utf8)) and (`b`.`revision_id` <= `d`.`private_revision_id`)))) group by `b`.`contents_id`));

--
-- Definition of view `%PREFIX%v_c_template_node`
--

DROP TABLE IF EXISTS `%PREFIX%v_c_template_node`;
DROP VIEW IF EXISTS `%PREFIX%v_c_template_node`;
CREATE   VIEW `%PREFIX%v_c_template_node` AS select `a`.`version_id` AS `version_id`,`a`.`revision_id` AS `revision_id`,`a`.`node_id` AS `node_id`,`a`.`parent_node` AS `parent_node`,`a`.`node_type` AS `node_type`,`a`.`node_class` AS `node_class`,`a`.`node_name` AS `node_name`,`a`.`contents_id` AS `contents_id`,`a`.`disp_seq` AS `disp_seq`,`a`.`del_flag` AS `del_flag`,`a`.`create_user` AS `create_user`,`a`.`create_datetime` AS `create_datetime`,`a`.`update_user` AS `update_user`,`a`.`update_datetime` AS `update_datetime` from `%PREFIX%template_node` `a` where (concat(`a`.`version_id`,`a`.`revision_id`) = (select max(concat(`b`.`version_id`,`b`.`revision_id`)) AS `max(concat(``b``.``version_id``,``b``.``revision_id``))` from ((`%PREFIX%template_node` `b` join `%PREFIX%v_current_version` `c`) join `%PREFIX%version` `d`) where ((`a`.`node_id` = `b`.`node_id`) and (`b`.`version_id` = `d`.`version_id`) and (((`b`.`version_id` < convert(`c`.`current_version_id` using utf8)) and (`b`.`revision_id` < `d`.`private_revision_id`)) or ((`b`.`version_id` = convert(`c`.`current_version_id` using utf8)) and (`b`.`revision_id` <= `d`.`private_revision_id`)))) group by `b`.`node_id`));

--
-- Definition of view `%PREFIX%v_c_widget`
--

DROP TABLE IF EXISTS `%PREFIX%v_c_widget`;
DROP VIEW IF EXISTS `%PREFIX%v_c_widget`;
CREATE   VIEW `%PREFIX%v_c_widget` AS select `a`.`version_id` AS `version_id`,`a`.`revision_id` AS `revision_id`,`a`.`contents_id` AS `contents_id`,`a`.`contents_date` AS `contents_date`,`a`.`widget_id` AS `widget_id`,`a`.`html` AS `html`,`a`.`css` AS `css`,`a`.`php` AS `php`,`a`.`del_flag` AS `del_flag`,`a`.`reserve1` AS `reserve1`,`a`.`reserve2` AS `reserve2`,`a`.`reserve3` AS `reserve3`,`a`.`create_user` AS `create_user`,`a`.`create_datetime` AS `create_datetime`,`a`.`update_user` AS `update_user`,`a`.`update_datetime` AS `update_datetime` from `%PREFIX%widget` `a` where (concat(`a`.`version_id`,`a`.`revision_id`) = (select max(concat(`b`.`version_id`,`b`.`revision_id`)) AS `max(concat(``b``.``version_id``,``b``.``revision_id``))` from ((`%PREFIX%widget` `b` join `%PREFIX%v_current_version` `c`) join `%PREFIX%version` `d`) where ((`a`.`contents_id` = `b`.`contents_id`) and (`b`.`version_id` = `d`.`version_id`) and (((`b`.`version_id` < convert(`c`.`current_version_id` using utf8)) and (`b`.`revision_id` < `d`.`private_revision_id`)) or ((`b`.`version_id` = convert(`c`.`current_version_id` using utf8)) and (`b`.`revision_id` <= `d`.`private_revision_id`)))) group by `b`.`contents_id`));

--
-- Definition of view `%PREFIX%v_c_widget_node`
--

DROP TABLE IF EXISTS `%PREFIX%v_c_widget_node`;
DROP VIEW IF EXISTS `%PREFIX%v_c_widget_node`;
CREATE   VIEW `%PREFIX%v_c_widget_node` AS select `a`.`version_id` AS `version_id`,`a`.`revision_id` AS `revision_id`,`a`.`node_id` AS `node_id`,`a`.`parent_node` AS `parent_node`,`a`.`node_type` AS `node_type`,`a`.`node_class` AS `node_class`,`a`.`node_name` AS `node_name`,`a`.`contents_id` AS `contents_id`,`a`.`disp_seq` AS `disp_seq`,`a`.`del_flag` AS `del_flag`,`a`.`create_user` AS `create_user`,`a`.`create_datetime` AS `create_datetime`,`a`.`update_user` AS `update_user`,`a`.`update_datetime` AS `update_datetime` from `%PREFIX%widget_node` `a` where (concat(`a`.`version_id`,`a`.`revision_id`) = (select max(concat(`b`.`version_id`,`b`.`revision_id`)) AS `max(concat(``b``.``version_id``,``b``.``revision_id``))` from ((`%PREFIX%widget_node` `b` join `%PREFIX%v_current_version` `c`) join `%PREFIX%version` `d`) where ((`a`.`node_id` = `b`.`node_id`) and (`b`.`version_id` = `d`.`version_id`) and (((`b`.`version_id` < convert(`c`.`current_version_id` using utf8)) and (`b`.`revision_id` < `d`.`private_revision_id`)) or ((`b`.`version_id` = convert(`c`.`current_version_id` using utf8)) and (`b`.`revision_id` <= `d`.`private_revision_id`)))) group by `b`.`node_id`));

--
-- Definition of view `%PREFIX%v_category`
--

DROP TABLE IF EXISTS `%PREFIX%v_category`;
DROP VIEW IF EXISTS `%PREFIX%v_category`;
CREATE   VIEW `%PREFIX%v_category` AS select `%PREFIX%category`.`node_id` AS `node_id`,`%PREFIX%category`.`parent_node` AS `parent_node`,`%PREFIX%category`.`node_type` AS `node_type`,`%PREFIX%category`.`node_class` AS `node_class`,`%PREFIX%category`.`node_name` AS `node_name`,`%PREFIX%category`.`disp_seq` AS `disp_seq`,`%PREFIX%category`.`color` AS `color`,`%PREFIX%category`.`background_color` AS `background_color`,`%PREFIX%category`.`icon_file` AS `icon_file`,`%PREFIX%category`.`del_flag` AS `del_flag`,`%PREFIX%category`.`create_user` AS `create_user`,`%PREFIX%category`.`create_datetime` AS `create_datetime`,`%PREFIX%category`.`update_user` AS `update_user`,`%PREFIX%category`.`update_datetime` AS `update_datetime` from `%PREFIX%category` where (`%PREFIX%category`.`del_flag` = _utf8'0');

--
-- Definition of view `%PREFIX%v_category2`
--

DROP TABLE IF EXISTS `%PREFIX%v_category2`;
DROP VIEW IF EXISTS `%PREFIX%v_category2`;
CREATE   VIEW `%PREFIX%v_category2` AS select `%PREFIX%category2`.`node_id` AS `node_id`,`%PREFIX%category2`.`parent_node` AS `parent_node`,`%PREFIX%category2`.`node_type` AS `node_type`,`%PREFIX%category2`.`node_class` AS `node_class`,`%PREFIX%category2`.`node_name` AS `node_name`,`%PREFIX%category2`.`disp_seq` AS `disp_seq`,`%PREFIX%category2`.`color` AS `color`,`%PREFIX%category2`.`background_color` AS `background_color`,`%PREFIX%category2`.`icon_file` AS `icon_file`,`%PREFIX%category2`.`del_flag` AS `del_flag`,`%PREFIX%category2`.`create_user` AS `create_user`,`%PREFIX%category2`.`create_datetime` AS `create_datetime`,`%PREFIX%category2`.`update_user` AS `update_user`,`%PREFIX%category2`.`update_datetime` AS `update_datetime` from `%PREFIX%category2` where (`%PREFIX%category2`.`del_flag` = _utf8'0');

--
-- Definition of view `%PREFIX%v_category3`
--

DROP TABLE IF EXISTS `%PREFIX%v_category3`;
DROP VIEW IF EXISTS `%PREFIX%v_category3`;
CREATE   VIEW `%PREFIX%v_category3` AS select `%PREFIX%category3`.`node_id` AS `node_id`,`%PREFIX%category3`.`parent_node` AS `parent_node`,`%PREFIX%category3`.`node_type` AS `node_type`,`%PREFIX%category3`.`node_class` AS `node_class`,`%PREFIX%category3`.`node_name` AS `node_name`,`%PREFIX%category3`.`disp_seq` AS `disp_seq`,`%PREFIX%category3`.`color` AS `color`,`%PREFIX%category3`.`background_color` AS `background_color`,`%PREFIX%category3`.`icon_file` AS `icon_file`,`%PREFIX%category3`.`del_flag` AS `del_flag`,`%PREFIX%category3`.`create_user` AS `create_user`,`%PREFIX%category3`.`create_datetime` AS `create_datetime`,`%PREFIX%category3`.`update_user` AS `update_user`,`%PREFIX%category3`.`update_datetime` AS `update_datetime` from `%PREFIX%category3` where (`%PREFIX%category3`.`del_flag` = _utf8'0');

--
-- Definition of view `%PREFIX%v_compare_contents_node`
--

DROP TABLE IF EXISTS `%PREFIX%v_compare_contents_node`;
DROP VIEW IF EXISTS `%PREFIX%v_compare_contents_node`;
CREATE   VIEW `%PREFIX%v_compare_contents_node` AS select `a`.`version_id` AS `version_id`,`a`.`revision_id` AS `revision_id`,`a`.`node_id` AS `node_id`,`a`.`parent_node` AS `parent_node`,`a`.`node_type` AS `node_type`,`a`.`node_class` AS `node_class`,`a`.`node_name` AS `node_name`,`a`.`contents_id` AS `contents_id`,`a`.`disp_seq` AS `disp_seq`,`a`.`del_flag` AS `del_flag`,`a`.`create_user` AS `create_user`,`a`.`create_datetime` AS `create_datetime`,`a`.`update_user` AS `update_user`,`a`.`update_datetime` AS `update_datetime` from `%PREFIX%contents_node` `a` where (concat(`a`.`version_id`,`a`.`revision_id`) = (select max(concat(`b`.`version_id`,`b`.`revision_id`)) AS `max(concat(b.version_id, b.revision_id))` from ((`%PREFIX%contents_node` `b` join `%PREFIX%compare_version` `c`) join `%PREFIX%version` `d`) where ((`a`.`node_id` = `b`.`node_id`) and (`b`.`version_id` = `d`.`version_id`) and (((`b`.`version_id` < `c`.`compare_version_id`) and (`b`.`revision_id` < `d`.`private_revision_id`)) or ((`b`.`version_id` = `c`.`compare_version_id`) and (`b`.`revision_id` <= `d`.`private_revision_id`)))) group by `b`.`node_id`));

--
-- Definition of view `%PREFIX%v_compare_resource_node`
--

DROP TABLE IF EXISTS `%PREFIX%v_compare_resource_node`;
DROP VIEW IF EXISTS `%PREFIX%v_compare_resource_node`;
CREATE   VIEW `%PREFIX%v_compare_resource_node` AS select `a`.`version_id` AS `version_id`,`a`.`revision_id` AS `revision_id`,`a`.`node_id` AS `node_id`,`a`.`parent_node` AS `parent_node`,`a`.`node_type` AS `node_type`,`a`.`node_class` AS `node_class`,`a`.`node_name` AS `node_name`,`a`.`contents_id` AS `contents_id`,`a`.`disp_seq` AS `disp_seq`,`a`.`del_flag` AS `del_flag`,`a`.`create_user` AS `create_user`,`a`.`create_datetime` AS `create_datetime`,`a`.`update_user` AS `update_user`,`a`.`update_datetime` AS `update_datetime` from `%PREFIX%resource_node` `a` where (concat(`a`.`version_id`,`a`.`revision_id`) = (select max(concat(`b`.`version_id`,`b`.`revision_id`)) AS `max(concat(b.version_id, b.revision_id))` from ((`%PREFIX%resource_node` `b` join `%PREFIX%compare_version` `c`) join `%PREFIX%version` `d`) where ((`a`.`node_id` = `b`.`node_id`) and (`b`.`version_id` = `d`.`version_id`) and (((`b`.`version_id` < `c`.`compare_version_id`) and (`b`.`revision_id` < `d`.`private_revision_id`)) or ((`b`.`version_id` = `c`.`compare_version_id`) and (`b`.`revision_id` <= `d`.`private_revision_id`)))) group by `b`.`node_id`));

--
-- Definition of view `%PREFIX%v_compare_template_node`
--

DROP TABLE IF EXISTS `%PREFIX%v_compare_template_node`;
DROP VIEW IF EXISTS `%PREFIX%v_compare_template_node`;
CREATE   VIEW `%PREFIX%v_compare_template_node` AS select `a`.`version_id` AS `version_id`,`a`.`revision_id` AS `revision_id`,`a`.`node_id` AS `node_id`,`a`.`parent_node` AS `parent_node`,`a`.`node_type` AS `node_type`,`a`.`node_class` AS `node_class`,`a`.`node_name` AS `node_name`,`a`.`contents_id` AS `contents_id`,`a`.`disp_seq` AS `disp_seq`,`a`.`del_flag` AS `del_flag`,`a`.`create_user` AS `create_user`,`a`.`create_datetime` AS `create_datetime`,`a`.`update_user` AS `update_user`,`a`.`update_datetime` AS `update_datetime` from `%PREFIX%template_node` `a` where (concat(`a`.`version_id`,`a`.`revision_id`) = (select max(concat(`b`.`version_id`,`b`.`revision_id`)) AS `max(concat(``b``.``version_id``,``b``.``revision_id``))` from ((`%PREFIX%template_node` `b` join `%PREFIX%compare_version` `c`) join `%PREFIX%version` `d`) where ((`a`.`node_id` = `b`.`node_id`) and (`b`.`version_id` = `d`.`version_id`) and (((`b`.`version_id` < `c`.`compare_version_id`) and (`b`.`revision_id` < `d`.`private_revision_id`)) or ((`b`.`version_id` = `c`.`compare_version_id`) and (`b`.`revision_id` <= `d`.`private_revision_id`)))) group by `b`.`node_id`));

--
-- Definition of view `%PREFIX%v_compare_widget_node`
--

DROP TABLE IF EXISTS `%PREFIX%v_compare_widget_node`;
DROP VIEW IF EXISTS `%PREFIX%v_compare_widget_node`;
CREATE   VIEW `%PREFIX%v_compare_widget_node` AS select `a`.`version_id` AS `version_id`,`a`.`revision_id` AS `revision_id`,`a`.`node_id` AS `node_id`,`a`.`parent_node` AS `parent_node`,`a`.`node_type` AS `node_type`,`a`.`node_class` AS `node_class`,`a`.`node_name` AS `node_name`,`a`.`contents_id` AS `contents_id`,`a`.`disp_seq` AS `disp_seq`,`a`.`del_flag` AS `del_flag`,`a`.`create_user` AS `create_user`,`a`.`create_datetime` AS `create_datetime`,`a`.`update_user` AS `update_user`,`a`.`update_datetime` AS `update_datetime` from `%PREFIX%widget_node` `a` where (concat(`a`.`version_id`,`a`.`revision_id`) = (select max(concat(`b`.`version_id`,`b`.`revision_id`)) AS `max(concat(``b``.``version_id``,``b``.``revision_id``))` from ((`%PREFIX%widget_node` `b` join `%PREFIX%compare_version` `c`) join `%PREFIX%version` `d`) where ((`a`.`node_id` = `b`.`node_id`) and (`b`.`version_id` = `d`.`version_id`) and (((`b`.`version_id` < `c`.`compare_version_id`) and (`b`.`revision_id` < `d`.`private_revision_id`)) or ((`b`.`version_id` = `c`.`compare_version_id`) and (`b`.`revision_id` <= `d`.`private_revision_id`)))) group by `b`.`node_id`));

--
-- Definition of view `%PREFIX%v_current_version`
--

DROP TABLE IF EXISTS `%PREFIX%v_current_version`;
DROP VIEW IF EXISTS `%PREFIX%v_current_version`;
CREATE   VIEW `%PREFIX%v_current_version` AS select `b`.`version_id` AS `reserved_version_id`,`b`.`publication_datetime_u` AS `publication_datetime_u`,if(`c`.`version_id`,`c`.`version_id`,`d`.`version_id`) AS `current_version_id`,if(`c`.`version_id`,`c`.`version`,`d`.`version`) AS `current_version`,`a`.`working_version_id` AS `working_version_id`,`e`.`version` AS `working_version`,`e`.`private_revision_id` AS `revision_id` from ((((`%PREFIX%current_version` `a` left join `%PREFIX%version` `b` on(((`a`.`reserved_version_id` = `b`.`version_id`) and (`b`.`publication_datetime_u` > unix_timestamp())))) left join `%PREFIX%version` `c` on(((`a`.`reserved_version_id` = `c`.`version_id`) and (`c`.`publication_datetime_u` <= unix_timestamp())))) left join `%PREFIX%version` `d` on((`a`.`current_version_id` = `d`.`version_id`))) left join `%PREFIX%version` `e` on((`a`.`working_version_id` = `e`.`version_id`)));

--
-- Definition of view `%PREFIX%v_w_contents`
--

DROP TABLE IF EXISTS `%PREFIX%v_w_contents`;
DROP VIEW IF EXISTS `%PREFIX%v_w_contents`;
CREATE   VIEW `%PREFIX%v_w_contents` AS select `a`.`version_id` AS `version_id`,`a`.`revision_id` AS `revision_id`,`a`.`contents_id` AS `contents_id`,`a`.`contents_date` AS `contents_date`,`a`.`template_id` AS `template_id`,`a`.`title` AS `title`,`a`.`breadcrumbs` AS `breadcrumbs`,`a`.`html1` AS `html1`,`a`.`html2` AS `html2`,`a`.`html3` AS `html3`,`a`.`html4` AS `html4`,`a`.`css` AS `css`,`a`.`php` AS `php`,`a`.`keywords` AS `keywords`,`a`.`description` AS `description`,`a`.`external_css` AS `external_css`,`a`.`external_js` AS `external_js`,`a`.`header_element` AS `header_element`,`a`.`del_flag` AS `del_flag`,`a`.`reserve1` AS `reserve1`,`a`.`reserve2` AS `reserve2`,`a`.`reserve3` AS `reserve3`,`a`.`create_user` AS `create_user`,`a`.`create_datetime` AS `create_datetime`,`a`.`update_user` AS `update_user`,`a`.`update_datetime` AS `update_datetime` from `%PREFIX%contents` `a` where (concat(`a`.`version_id`,`a`.`revision_id`) = (select max(concat(`b`.`version_id`,`b`.`revision_id`)) AS `max(concat(b.version_id, b.revision_id))` from ((`%PREFIX%contents` `b` join `%PREFIX%v_current_version` `c`) join `%PREFIX%version` `d`) where ((`a`.`contents_id` = `b`.`contents_id`) and (`b`.`version_id` = `d`.`version_id`) and (((`b`.`version_id` < `c`.`working_version_id`) and (`b`.`revision_id` < `d`.`private_revision_id`)) or ((`b`.`version_id` = `c`.`working_version_id`) and (`b`.`revision_id` <= `d`.`private_revision_id`)))) group by `b`.`contents_id`));

--
-- Definition of view `%PREFIX%v_w_contents_node`
--

DROP TABLE IF EXISTS `%PREFIX%v_w_contents_node`;
DROP VIEW IF EXISTS `%PREFIX%v_w_contents_node`;
CREATE   VIEW `%PREFIX%v_w_contents_node` AS select `a`.`version_id` AS `version_id`,`a`.`revision_id` AS `revision_id`,`a`.`node_id` AS `node_id`,`a`.`parent_node` AS `parent_node`,`a`.`node_type` AS `node_type`,`a`.`node_class` AS `node_class`,`a`.`node_name` AS `node_name`,`a`.`contents_id` AS `contents_id`,`a`.`disp_seq` AS `disp_seq`,`a`.`del_flag` AS `del_flag`,`a`.`create_user` AS `create_user`,`a`.`create_datetime` AS `create_datetime`,`a`.`update_user` AS `update_user`,`a`.`update_datetime` AS `update_datetime` from `%PREFIX%contents_node` `a` where (concat(`a`.`version_id`,`a`.`revision_id`) = (select max(concat(`b`.`version_id`,`b`.`revision_id`)) AS `max(concat(``b``.``version_id``,``b``.``revision_id``))` from ((`%PREFIX%contents_node` `b` join `%PREFIX%v_current_version` `c`) join `%PREFIX%version` `d`) where ((`a`.`node_id` = `b`.`node_id`) and (`b`.`version_id` = `d`.`version_id`) and (((`b`.`version_id` < `c`.`working_version_id`) and (`b`.`revision_id` < `d`.`private_revision_id`)) or ((`b`.`version_id` = `c`.`working_version_id`) and (`b`.`revision_id` <= `d`.`private_revision_id`)))) group by `b`.`node_id`));

--
-- Definition of view `%PREFIX%v_w_resource_node`
--

DROP TABLE IF EXISTS `%PREFIX%v_w_resource_node`;
DROP VIEW IF EXISTS `%PREFIX%v_w_resource_node`;
CREATE   VIEW `%PREFIX%v_w_resource_node` AS select `a`.`version_id` AS `version_id`,`a`.`revision_id` AS `revision_id`,`a`.`node_id` AS `node_id`,`a`.`parent_node` AS `parent_node`,`a`.`node_type` AS `node_type`,`a`.`node_class` AS `node_class`,`a`.`node_name` AS `node_name`,`a`.`file_size` AS `file_size`,`a`.`human_file_size` AS `human_file_size`,`a`.`image_size` AS `image_size`,`a`.`human_image_size` AS `human_image_size`,`a`.`contents_id` AS `contents_id`,`a`.`disp_seq` AS `disp_seq`,`a`.`del_flag` AS `del_flag`,`a`.`create_user` AS `create_user`,`a`.`create_datetime` AS `create_datetime`,`a`.`update_user` AS `update_user`,`a`.`update_datetime` AS `update_datetime` from `%PREFIX%resource_node` `a` where (concat(`a`.`version_id`,`a`.`revision_id`) = (select max(concat(`b`.`version_id`,`b`.`revision_id`)) AS `max(concat(b.version_id, b.revision_id))` from ((`%PREFIX%resource_node` `b` join `%PREFIX%v_current_version` `c`) join `%PREFIX%version` `d`) where ((`a`.`node_id` = `b`.`node_id`) and (`b`.`version_id` = `d`.`version_id`) and (((`b`.`version_id` < `c`.`working_version_id`) and (`b`.`revision_id` < `d`.`private_revision_id`)) or ((`b`.`version_id` = `c`.`working_version_id`) and (`b`.`revision_id` <= `d`.`private_revision_id`)))) group by `b`.`node_id`));

--
-- Definition of view `%PREFIX%v_w_template`
--

DROP TABLE IF EXISTS `%PREFIX%v_w_template`;
DROP VIEW IF EXISTS `%PREFIX%v_w_template`;
CREATE   VIEW `%PREFIX%v_w_template` AS select `a`.`version_id` AS `version_id`,`a`.`revision_id` AS `revision_id`,`a`.`contents_id` AS `contents_id`,`a`.`contents_date` AS `contents_date`,`a`.`template_id` AS `template_id`,`a`.`start_html` AS `start_html`,`a`.`end_html` AS `end_html`,`a`.`css` AS `css`,`a`.`php` AS `php`,`a`.`external_css` AS `external_css`,`a`.`external_js` AS `external_js`,`a`.`header_element` AS `header_element`,`a`.`del_flag` AS `del_flag`,`a`.`reserve1` AS `reserve1`,`a`.`reserve2` AS `reserve2`,`a`.`reserve3` AS `reserve3`,`a`.`create_user` AS `create_user`,`a`.`create_datetime` AS `create_datetime`,`a`.`update_user` AS `update_user`,`a`.`update_datetime` AS `update_datetime` from `%PREFIX%template` `a` where (concat(`a`.`version_id`,`a`.`revision_id`) = (select max(concat(`b`.`version_id`,`b`.`revision_id`)) AS `max(concat(``b``.``version_id``,``b``.``revision_id``))` from ((`%PREFIX%template` `b` join `%PREFIX%v_current_version` `c`) join `%PREFIX%version` `d`) where ((`a`.`contents_id` = `b`.`contents_id`) and (`b`.`version_id` = `d`.`version_id`) and (((`b`.`version_id` < `c`.`working_version_id`) and (`b`.`revision_id` < `d`.`private_revision_id`)) or ((`b`.`version_id` = `c`.`working_version_id`) and (`b`.`revision_id` <= `d`.`private_revision_id`)))) group by `b`.`contents_id`));

--
-- Definition of view `%PREFIX%v_w_template_node`
--

DROP TABLE IF EXISTS `%PREFIX%v_w_template_node`;
DROP VIEW IF EXISTS `%PREFIX%v_w_template_node`;
CREATE   VIEW `%PREFIX%v_w_template_node` AS select `a`.`version_id` AS `version_id`,`a`.`revision_id` AS `revision_id`,`a`.`node_id` AS `node_id`,`a`.`parent_node` AS `parent_node`,`a`.`node_type` AS `node_type`,`a`.`node_class` AS `node_class`,`a`.`node_name` AS `node_name`,`a`.`contents_id` AS `contents_id`,`a`.`disp_seq` AS `disp_seq`,`a`.`del_flag` AS `del_flag`,`a`.`create_user` AS `create_user`,`a`.`create_datetime` AS `create_datetime`,`a`.`update_user` AS `update_user`,`a`.`update_datetime` AS `update_datetime` from `%PREFIX%template_node` `a` where (concat(`a`.`version_id`,`a`.`revision_id`) = (select max(concat(`b`.`version_id`,`b`.`revision_id`)) AS `max(concat(``b``.``version_id``,``b``.``revision_id``))` from ((`%PREFIX%template_node` `b` join `%PREFIX%v_current_version` `c`) join `%PREFIX%version` `d`) where ((`a`.`node_id` = `b`.`node_id`) and (`b`.`version_id` = `d`.`version_id`) and (((`b`.`version_id` < `c`.`working_version_id`) and (`b`.`revision_id` < `d`.`private_revision_id`)) or ((`b`.`version_id` = `c`.`working_version_id`) and (`b`.`revision_id` <= `d`.`private_revision_id`)))) group by `b`.`node_id`));

--
-- Definition of view `%PREFIX%v_w_widget`
--

DROP TABLE IF EXISTS `%PREFIX%v_w_widget`;
DROP VIEW IF EXISTS `%PREFIX%v_w_widget`;
CREATE   VIEW `%PREFIX%v_w_widget` AS select `a`.`version_id` AS `version_id`,`a`.`revision_id` AS `revision_id`,`a`.`contents_id` AS `contents_id`,`a`.`contents_date` AS `contents_date`,`a`.`widget_id` AS `widget_id`,`a`.`html` AS `html`,`a`.`css` AS `css`,`a`.`php` AS `php`,`a`.`del_flag` AS `del_flag`,`a`.`reserve1` AS `reserve1`,`a`.`reserve2` AS `reserve2`,`a`.`reserve3` AS `reserve3`,`a`.`create_user` AS `create_user`,`a`.`create_datetime` AS `create_datetime`,`a`.`update_user` AS `update_user`,`a`.`update_datetime` AS `update_datetime` from `%PREFIX%widget` `a` where (concat(`a`.`version_id`,`a`.`revision_id`) = (select max(concat(`b`.`version_id`,`b`.`revision_id`)) AS `max(concat(``b``.``version_id``,``b``.``revision_id``))` from ((`%PREFIX%widget` `b` join `%PREFIX%v_current_version` `c`) join `%PREFIX%version` `d`) where ((`a`.`contents_id` = `b`.`contents_id`) and (`b`.`version_id` = `d`.`version_id`) and (((`b`.`version_id` < `c`.`working_version_id`) and (`b`.`revision_id` < `d`.`private_revision_id`)) or ((`b`.`version_id` = `c`.`working_version_id`) and (`b`.`revision_id` <= `d`.`private_revision_id`)))) group by `b`.`contents_id`));

--
-- Definition of view `%PREFIX%v_w_widget_node`
--

DROP TABLE IF EXISTS `%PREFIX%v_w_widget_node`;
DROP VIEW IF EXISTS `%PREFIX%v_w_widget_node`;
CREATE   VIEW `%PREFIX%v_w_widget_node` AS select `a`.`version_id` AS `version_id`,`a`.`revision_id` AS `revision_id`,`a`.`node_id` AS `node_id`,`a`.`parent_node` AS `parent_node`,`a`.`node_type` AS `node_type`,`a`.`node_class` AS `node_class`,`a`.`node_name` AS `node_name`,`a`.`contents_id` AS `contents_id`,`a`.`disp_seq` AS `disp_seq`,`a`.`del_flag` AS `del_flag`,`a`.`create_user` AS `create_user`,`a`.`create_datetime` AS `create_datetime`,`a`.`update_user` AS `update_user`,`a`.`update_datetime` AS `update_datetime` from `%PREFIX%widget_node` `a` where (concat(`a`.`version_id`,`a`.`revision_id`) = (select max(concat(`b`.`version_id`,`b`.`revision_id`)) AS `max(concat(``b``.``version_id``,``b``.``revision_id``))` from ((`%PREFIX%widget_node` `b` join `%PREFIX%v_current_version` `c`) join `%PREFIX%version` `d`) where ((`a`.`node_id` = `b`.`node_id`) and (`b`.`version_id` = `d`.`version_id`) and (((`b`.`version_id` < `c`.`working_version_id`) and (`b`.`revision_id` < `d`.`private_revision_id`)) or ((`b`.`version_id` = `c`.`working_version_id`) and (`b`.`revision_id` <= `d`.`private_revision_id`)))) group by `b`.`node_id`));

