-- B-studio dump
--
-- ------------------------------------------------------
-- Server version	5.0.77-community-nt

--
-- Temporary table structure for view `%PREFIX%v_admin_article`
--
DROP TABLE IF EXISTS `%PREFIX%v_admin_article`;
DROP VIEW IF EXISTS `%PREFIX%v_admin_article`;
CREATE TABLE `%PREFIX%v_admin_article` (
  `article_id` char(10),
  `article_date_t` text,
  `article_date_u` text,
  `category_id` char(10),
  `keywords` text,
  `description` text,
  `publication` char(1),
  `title` text,
  `title_img_file` text,
  `description_flag` char(1),
  `external_link` char(1),
  `external_window` char(1),
  `url` text,
  `contents` text,
  `del_flag` char(1),
  `folder_id` text,
  `reserve1` text,
  `reserve2` text,
  `reserve3` text,
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text,
  `article_date` longtext,
  `category` text,
  `color` text,
  `background_color` text,
  `icon_file` text
);

--
-- Temporary table structure for view `%PREFIX%v_admin_article2`
--
DROP TABLE IF EXISTS `%PREFIX%v_admin_article2`;
DROP VIEW IF EXISTS `%PREFIX%v_admin_article2`;
CREATE TABLE `%PREFIX%v_admin_article2` (
  `article_id` char(10),
  `article_date_t` text,
  `article_date_u` text,
  `category_id` char(10),
  `keywords` text,
  `description` text,
  `publication` char(1),
  `title` text,
  `title_img_file` text,
  `description_flag` char(1),
  `external_link` char(1),
  `external_window` char(1),
  `url` text,
  `contents` text,
  `del_flag` char(1),
  `folder_id` text,
  `reserve1` text,
  `reserve2` text,
  `reserve3` text,
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text,
  `article_date` longtext,
  `category` text,
  `color` text,
  `background_color` text,
  `icon_file` text
);

--
-- Temporary table structure for view `%PREFIX%v_admin_article3`
--
DROP TABLE IF EXISTS `%PREFIX%v_admin_article3`;
DROP VIEW IF EXISTS `%PREFIX%v_admin_article3`;
CREATE TABLE `%PREFIX%v_admin_article3` (
  `article_id` char(10),
  `article_date_t` text,
  `article_date_u` text,
  `category_id` char(10),
  `keywords` text,
  `description` text,
  `publication` char(1),
  `title` text,
  `title_img_file` text,
  `description_flag` char(1),
  `external_link` char(1),
  `external_window` char(1),
  `url` text,
  `contents` text,
  `del_flag` char(1),
  `folder_id` text,
  `reserve1` text,
  `reserve2` text,
  `reserve3` text,
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text,
  `article_date` longtext,
  `category` text,
  `color` text,
  `background_color` text,
  `icon_file` text
);

--
-- Temporary table structure for view `%PREFIX%v_article`
--
DROP TABLE IF EXISTS `%PREFIX%v_article`;
DROP VIEW IF EXISTS `%PREFIX%v_article`;
CREATE TABLE `%PREFIX%v_article` (
  `article_id` char(10),
  `article_date_t` text,
  `article_date_u` text,
  `category_id` char(10),
  `keywords` text,
  `description` text,
  `publication` char(1),
  `title` text,
  `title_img_file` text,
  `description_flag` char(1),
  `external_link` char(1),
  `external_window` char(1),
  `url` text,
  `contents` text,
  `del_flag` char(1),
  `folder_id` text,
  `reserve1` text,
  `reserve2` text,
  `reserve3` text,
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text,
  `article_date` longtext,
  `category` text,
  `color` text,
  `background_color` text,
  `icon_file` text
);

--
-- Temporary table structure for view `%PREFIX%v_article2`
--
DROP TABLE IF EXISTS `%PREFIX%v_article2`;
DROP VIEW IF EXISTS `%PREFIX%v_article2`;
CREATE TABLE `%PREFIX%v_article2` (
  `article_id` char(10),
  `article_date_t` text,
  `article_date_u` text,
  `category_id` char(10),
  `keywords` text,
  `description` text,
  `publication` char(1),
  `title` text,
  `title_img_file` text,
  `description_flag` char(1),
  `external_link` char(1),
  `external_window` char(1),
  `url` text,
  `contents` text,
  `del_flag` char(1),
  `folder_id` text,
  `reserve1` text,
  `reserve2` text,
  `reserve3` text,
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text,
  `article_date` longtext,
  `category` text,
  `color` text,
  `background_color` text,
  `icon_file` text
);

--
-- Temporary table structure for view `%PREFIX%v_article3`
--
DROP TABLE IF EXISTS `%PREFIX%v_article3`;
DROP VIEW IF EXISTS `%PREFIX%v_article3`;
CREATE TABLE `%PREFIX%v_article3` (
  `article_id` char(10),
  `article_date_t` text,
  `article_date_u` text,
  `category_id` char(10),
  `keywords` text,
  `description` text,
  `publication` char(1),
  `title` text,
  `title_img_file` text,
  `description_flag` char(1),
  `external_link` char(1),
  `external_window` char(1),
  `url` text,
  `contents` text,
  `del_flag` char(1),
  `folder_id` text,
  `reserve1` text,
  `reserve2` text,
  `reserve3` text,
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text,
  `article_date` longtext,
  `category` text,
  `color` text,
  `background_color` text,
  `icon_file` text
);

--
-- Temporary table structure for view `%PREFIX%v_c_contents`
--
DROP TABLE IF EXISTS `%PREFIX%v_c_contents`;
DROP VIEW IF EXISTS `%PREFIX%v_c_contents`;
CREATE TABLE `%PREFIX%v_c_contents` (
  `version_id` char(5),
  `revision_id` char(2),
  `contents_id` char(10),
  `contents_date` char(10),
  `template_id` char(10),
  `title` text,
  `breadcrumbs` text,
  `html1` mediumtext,
  `html2` text,
  `html3` text,
  `html4` text,
  `css` mediumtext,
  `php` mediumtext,
  `keywords` text,
  `description` text,
  `external_css` text,
  `external_js` text,
  `header_element` text,
  `del_flag` char(1),
  `reserve1` text,
  `reserve2` text,
  `reserve3` text,
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text
);

--
-- Temporary table structure for view `%PREFIX%v_c_contents_node`
--
DROP TABLE IF EXISTS `%PREFIX%v_c_contents_node`;
DROP VIEW IF EXISTS `%PREFIX%v_c_contents_node`;
CREATE TABLE `%PREFIX%v_c_contents_node` (
  `version_id` char(5),
  `revision_id` char(2),
  `node_id` char(10),
  `parent_node` char(10),
  `node_type` char(10),
  `node_class` char(10),
  `node_name` text,
  `contents_id` char(10),
  `disp_seq` int(11),
  `del_flag` char(1),
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text
);

--
-- Temporary table structure for view `%PREFIX%v_c_resource_node`
--
DROP TABLE IF EXISTS `%PREFIX%v_c_resource_node`;
DROP VIEW IF EXISTS `%PREFIX%v_c_resource_node`;
CREATE TABLE `%PREFIX%v_c_resource_node` (
  `version_id` char(5),
  `revision_id` char(2),
  `node_id` char(10),
  `parent_node` char(10),
  `node_type` char(10),
  `node_class` char(10),
  `node_name` text,
  `file_size` int(11),
  `human_file_size` text,
  `image_size` int(11),
  `human_image_size` text,
  `contents_id` char(19),
  `disp_seq` int(11),
  `del_flag` char(1),
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text
);

--
-- Temporary table structure for view `%PREFIX%v_c_template`
--
DROP TABLE IF EXISTS `%PREFIX%v_c_template`;
DROP VIEW IF EXISTS `%PREFIX%v_c_template`;
CREATE TABLE `%PREFIX%v_c_template` (
  `version_id` char(5),
  `revision_id` char(2),
  `contents_id` char(10),
  `contents_date` char(10),
  `template_id` char(10),
  `start_html` mediumtext,
  `end_html` mediumtext,
  `css` mediumtext,
  `php` mediumtext,
  `external_css` text,
  `external_js` text,
  `header_element` text,
  `del_flag` char(1),
  `reserve1` text,
  `reserve2` text,
  `reserve3` text,
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text
);

--
-- Temporary table structure for view `%PREFIX%v_c_template_node`
--
DROP TABLE IF EXISTS `%PREFIX%v_c_template_node`;
DROP VIEW IF EXISTS `%PREFIX%v_c_template_node`;
CREATE TABLE `%PREFIX%v_c_template_node` (
  `version_id` char(5),
  `revision_id` char(2),
  `node_id` char(10),
  `parent_node` char(10),
  `node_type` char(10),
  `node_class` char(10),
  `node_name` text,
  `contents_id` char(10),
  `disp_seq` int(11),
  `del_flag` char(1),
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text
);

--
-- Temporary table structure for view `%PREFIX%v_c_widget`
--
DROP TABLE IF EXISTS `%PREFIX%v_c_widget`;
DROP VIEW IF EXISTS `%PREFIX%v_c_widget`;
CREATE TABLE `%PREFIX%v_c_widget` (
  `version_id` char(5),
  `revision_id` char(2),
  `contents_id` char(10),
  `contents_date` char(10),
  `widget_id` char(10),
  `html` text,
  `css` text,
  `php` text,
  `del_flag` char(1),
  `reserve1` text,
  `reserve2` text,
  `reserve3` text,
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text
);

--
-- Temporary table structure for view `%PREFIX%v_c_widget_node`
--
DROP TABLE IF EXISTS `%PREFIX%v_c_widget_node`;
DROP VIEW IF EXISTS `%PREFIX%v_c_widget_node`;
CREATE TABLE `%PREFIX%v_c_widget_node` (
  `version_id` char(5),
  `revision_id` char(2),
  `node_id` char(10),
  `parent_node` char(10),
  `node_type` char(10),
  `node_class` char(10),
  `node_name` text,
  `contents_id` char(10),
  `disp_seq` int(11),
  `del_flag` char(1),
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text
);

--
-- Temporary table structure for view `%PREFIX%v_category`
--
DROP TABLE IF EXISTS `%PREFIX%v_category`;
DROP VIEW IF EXISTS `%PREFIX%v_category`;
CREATE TABLE `%PREFIX%v_category` (
  `node_id` char(10),
  `parent_node` char(10),
  `node_type` char(10),
  `node_class` char(10),
  `node_name` text,
  `disp_seq` int(11),
  `color` text,
  `background_color` text,
  `icon_file` text,
  `del_flag` char(1),
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text
);

--
-- Temporary table structure for view `%PREFIX%v_category2`
--
DROP TABLE IF EXISTS `%PREFIX%v_category2`;
DROP VIEW IF EXISTS `%PREFIX%v_category2`;
CREATE TABLE `%PREFIX%v_category2` (
  `node_id` char(10),
  `parent_node` char(10),
  `node_type` char(10),
  `node_class` char(10),
  `node_name` text,
  `disp_seq` int(11),
  `color` text,
  `background_color` text,
  `icon_file` text,
  `del_flag` char(1),
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text
);

--
-- Temporary table structure for view `%PREFIX%v_category3`
--
DROP TABLE IF EXISTS `%PREFIX%v_category3`;
DROP VIEW IF EXISTS `%PREFIX%v_category3`;
CREATE TABLE `%PREFIX%v_category3` (
  `node_id` char(10),
  `parent_node` char(10),
  `node_type` char(10),
  `node_class` char(10),
  `node_name` text,
  `disp_seq` int(11),
  `color` text,
  `background_color` text,
  `icon_file` text,
  `del_flag` char(1),
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text
);

--
-- Temporary table structure for view `%PREFIX%v_compare_contents_node`
--
DROP TABLE IF EXISTS `%PREFIX%v_compare_contents_node`;
DROP VIEW IF EXISTS `%PREFIX%v_compare_contents_node`;
CREATE TABLE `%PREFIX%v_compare_contents_node` (
  `version_id` char(5),
  `revision_id` char(2),
  `node_id` char(10),
  `parent_node` char(10),
  `node_type` char(10),
  `node_class` char(10),
  `node_name` text,
  `contents_id` char(10),
  `disp_seq` int(11),
  `del_flag` char(1),
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text
);

--
-- Temporary table structure for view `%PREFIX%v_compare_resource_node`
--
DROP TABLE IF EXISTS `%PREFIX%v_compare_resource_node`;
DROP VIEW IF EXISTS `%PREFIX%v_compare_resource_node`;
CREATE TABLE `%PREFIX%v_compare_resource_node` (
  `version_id` char(5),
  `revision_id` char(2),
  `node_id` char(10),
  `parent_node` char(10),
  `node_type` char(10),
  `node_class` char(10),
  `node_name` text,
  `contents_id` char(19),
  `disp_seq` int(11),
  `del_flag` char(1),
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text
);

--
-- Temporary table structure for view `%PREFIX%v_compare_template_node`
--
DROP TABLE IF EXISTS `%PREFIX%v_compare_template_node`;
DROP VIEW IF EXISTS `%PREFIX%v_compare_template_node`;
CREATE TABLE `%PREFIX%v_compare_template_node` (
  `version_id` char(5),
  `revision_id` char(2),
  `node_id` char(10),
  `parent_node` char(10),
  `node_type` char(10),
  `node_class` char(10),
  `node_name` text,
  `contents_id` char(10),
  `disp_seq` int(11),
  `del_flag` char(1),
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text
);

--
-- Temporary table structure for view `%PREFIX%v_compare_widget_node`
--
DROP TABLE IF EXISTS `%PREFIX%v_compare_widget_node`;
DROP VIEW IF EXISTS `%PREFIX%v_compare_widget_node`;
CREATE TABLE `%PREFIX%v_compare_widget_node` (
  `version_id` char(5),
  `revision_id` char(2),
  `node_id` char(10),
  `parent_node` char(10),
  `node_type` char(10),
  `node_class` char(10),
  `node_name` text,
  `contents_id` char(10),
  `disp_seq` int(11),
  `del_flag` char(1),
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text
);

--
-- Temporary table structure for view `%PREFIX%v_current_version`
--
DROP TABLE IF EXISTS `%PREFIX%v_current_version`;
DROP VIEW IF EXISTS `%PREFIX%v_current_version`;
CREATE TABLE `%PREFIX%v_current_version` (
  `reserved_version_id` char(5),
  `publication_datetime_u` text,
  `current_version_id` varchar(5),
  `current_version` longtext,
  `working_version_id` char(5),
  `working_version` text,
  `revision_id` char(2)
);

--
-- Temporary table structure for view `%PREFIX%v_preview_article`
--
DROP TABLE IF EXISTS `%PREFIX%v_preview_article`;
DROP VIEW IF EXISTS `%PREFIX%v_preview_article`;
CREATE TABLE `%PREFIX%v_preview_article` (
  `article_id` char(10),
  `article_date_t` text,
  `article_date_u` text,
  `category_id` char(10),
  `keywords` text,
  `description` text,
  `publication` char(1),
  `title` text,
  `title_img_file` text,
  `description_flag` char(1),
  `external_link` char(1),
  `external_window` char(1),
  `url` text,
  `contents` text,
  `del_flag` char(1),
  `folder_id` text,
  `reserve1` text,
  `reserve2` text,
  `reserve3` text,
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text,
  `article_date` longtext,
  `category` text,
  `color` text,
  `background_color` text,
  `icon_file` text
);

--
-- Temporary table structure for view `%PREFIX%v_preview_article2`
--
DROP TABLE IF EXISTS `%PREFIX%v_preview_article2`;
DROP VIEW IF EXISTS `%PREFIX%v_preview_article2`;
CREATE TABLE `%PREFIX%v_preview_article2` (
  `article_id` char(10),
  `article_date_t` text,
  `article_date_u` text,
  `category_id` char(10),
  `keywords` text,
  `description` text,
  `publication` char(1),
  `title` text,
  `title_img_file` text,
  `description_flag` char(1),
  `external_link` char(1),
  `external_window` char(1),
  `url` text,
  `contents` text,
  `del_flag` char(1),
  `folder_id` text,
  `reserve1` text,
  `reserve2` text,
  `reserve3` text,
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text,
  `article_date` longtext,
  `category` text,
  `color` text,
  `background_color` text,
  `icon_file` text
);

--
-- Temporary table structure for view `%PREFIX%v_preview_article3`
--
DROP TABLE IF EXISTS `%PREFIX%v_preview_article3`;
DROP VIEW IF EXISTS `%PREFIX%v_preview_article3`;
CREATE TABLE `%PREFIX%v_preview_article3` (
  `article_id` char(10),
  `article_date_t` text,
  `article_date_u` text,
  `category_id` char(10),
  `keywords` text,
  `description` text,
  `publication` char(1),
  `title` text,
  `title_img_file` text,
  `description_flag` char(1),
  `external_link` char(1),
  `external_window` char(1),
  `url` text,
  `contents` text,
  `del_flag` char(1),
  `folder_id` text,
  `reserve1` text,
  `reserve2` text,
  `reserve3` text,
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text,
  `article_date` longtext,
  `category` text,
  `color` text,
  `background_color` text,
  `icon_file` text
);

--
-- Temporary table structure for view `%PREFIX%v_w_contents`
--
DROP TABLE IF EXISTS `%PREFIX%v_w_contents`;
DROP VIEW IF EXISTS `%PREFIX%v_w_contents`;
CREATE TABLE `%PREFIX%v_w_contents` (
  `version_id` char(5),
  `revision_id` char(2),
  `contents_id` char(10),
  `contents_date` char(10),
  `template_id` char(10),
  `title` text,
  `breadcrumbs` text,
  `html1` mediumtext,
  `html2` text,
  `html3` text,
  `html4` text,
  `css` mediumtext,
  `php` mediumtext,
  `keywords` text,
  `description` text,
  `external_css` text,
  `external_js` text,
  `header_element` text,
  `del_flag` char(1),
  `reserve1` text,
  `reserve2` text,
  `reserve3` text,
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text
);

--
-- Temporary table structure for view `%PREFIX%v_w_contents_node`
--
DROP TABLE IF EXISTS `%PREFIX%v_w_contents_node`;
DROP VIEW IF EXISTS `%PREFIX%v_w_contents_node`;
CREATE TABLE `%PREFIX%v_w_contents_node` (
  `version_id` char(5),
  `revision_id` char(2),
  `node_id` char(10),
  `parent_node` char(10),
  `node_type` char(10),
  `node_class` char(10),
  `node_name` text,
  `contents_id` char(10),
  `disp_seq` int(11),
  `del_flag` char(1),
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text
);

--
-- Temporary table structure for view `%PREFIX%v_w_resource_node`
--
DROP TABLE IF EXISTS `%PREFIX%v_w_resource_node`;
DROP VIEW IF EXISTS `%PREFIX%v_w_resource_node`;
CREATE TABLE `%PREFIX%v_w_resource_node` (
  `version_id` char(5),
  `revision_id` char(2),
  `node_id` char(10),
  `parent_node` char(10),
  `node_type` char(10),
  `node_class` char(10),
  `node_name` text,
  `file_size` int(11),
  `human_file_size` text,
  `image_size` int(11),
  `human_image_size` text,
  `contents_id` char(19),
  `disp_seq` int(11),
  `del_flag` char(1),
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text
);

--
-- Temporary table structure for view `%PREFIX%v_w_template`
--
DROP TABLE IF EXISTS `%PREFIX%v_w_template`;
DROP VIEW IF EXISTS `%PREFIX%v_w_template`;
CREATE TABLE `%PREFIX%v_w_template` (
  `version_id` char(5),
  `revision_id` char(2),
  `contents_id` char(10),
  `contents_date` char(10),
  `template_id` char(10),
  `start_html` mediumtext,
  `end_html` mediumtext,
  `css` mediumtext,
  `php` mediumtext,
  `external_css` text,
  `external_js` text,
  `header_element` text,
  `del_flag` char(1),
  `reserve1` text,
  `reserve2` text,
  `reserve3` text,
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text
);

--
-- Temporary table structure for view `%PREFIX%v_w_template_node`
--
DROP TABLE IF EXISTS `%PREFIX%v_w_template_node`;
DROP VIEW IF EXISTS `%PREFIX%v_w_template_node`;
CREATE TABLE `%PREFIX%v_w_template_node` (
  `version_id` char(5),
  `revision_id` char(2),
  `node_id` char(10),
  `parent_node` char(10),
  `node_type` char(10),
  `node_class` char(10),
  `node_name` text,
  `contents_id` char(10),
  `disp_seq` int(11),
  `del_flag` char(1),
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text
);

--
-- Temporary table structure for view `%PREFIX%v_w_widget`
--
DROP TABLE IF EXISTS `%PREFIX%v_w_widget`;
DROP VIEW IF EXISTS `%PREFIX%v_w_widget`;
CREATE TABLE `%PREFIX%v_w_widget` (
  `version_id` char(5),
  `revision_id` char(2),
  `contents_id` char(10),
  `contents_date` char(10),
  `widget_id` char(10),
  `html` text,
  `css` text,
  `php` text,
  `del_flag` char(1),
  `reserve1` text,
  `reserve2` text,
  `reserve3` text,
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text
);

--
-- Temporary table structure for view `%PREFIX%v_w_widget_node`
--
DROP TABLE IF EXISTS `%PREFIX%v_w_widget_node`;
DROP VIEW IF EXISTS `%PREFIX%v_w_widget_node`;
CREATE TABLE `%PREFIX%v_w_widget_node` (
  `version_id` char(5),
  `revision_id` char(2),
  `node_id` char(10),
  `parent_node` char(10),
  `node_type` char(10),
  `node_class` char(10),
  `node_name` text,
  `contents_id` char(10),
  `disp_seq` int(11),
  `del_flag` char(1),
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text
);

--
-- Definition of table `%PREFIX%article`
--

DROP TABLE IF EXISTS `%PREFIX%article`;
CREATE TABLE `%PREFIX%article` (
  `article_id` char(10) NOT NULL default '',
  `article_date_t` text,
  `article_date_u` text,
  `category_id` char(10) default NULL,
  `keywords` text,
  `description` text,
  `publication` char(1) default NULL,
  `title` text,
  `title_img_file` text,
  `description_flag` char(1) default NULL,
  `external_link` char(1) default NULL,
  `external_window` char(1) default NULL,
  `url` text,
  `contents` text,
  `del_flag` char(1) default NULL,
  `folder_id` text,
  `reserve1` text,
  `reserve2` text,
  `reserve3` text,
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text,
  PRIMARY KEY  (`article_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `%PREFIX%article`
--

/*!40000 ALTER TABLE `%PREFIX%article` DISABLE KEYS */;
INSERT INTO `%PREFIX%article` (`article_id`,`article_date_t`,`article_date_u`,`category_id`,`keywords`,`description`,`publication`,`title`,`title_img_file`,`description_flag`,`external_link`,`external_window`,`url`,`contents`,`del_flag`,`folder_id`,`reserve1`,`reserve2`,`reserve3`,`create_user`,`create_datetime`,`update_user`,`update_datetime`) VALUES 
 ('0000000001','2014/02/23','1393081200','0000000001','',NULL,'1','This is 1st NEWS','','1','','','','','0','','','','','admin','1393122822','admin','1393126124'),
 ('0000000002','2014/02/11','1392044400','0000000002','',NULL,'1','This is 1st TOPICS','','1','','','','','0','','','','','admin','1393125934','admin','1393126086'),
 ('0000000003','2014/03/12','1394550000','0000000002','',NULL,'1','This is 2nd NEWS','','1','','','','','0','','','','','admin','1393130010','admin','1413969365'),
 ('0000000004','2014/02/20','1392822000','0000000001','',NULL,'1','Tshi is 2nd TOPICS','','1','','','','','0','','','','','admin','1393130036','admin','1413969373'),
 ('0000000005','2014/04/01','1396278000','0000000003','',NULL,'1','This is 3rd NEWS','','1','','','','<p>\r\n	<img alt=\"dummy-image\" src=\"files/images/dummy_gray_300x200.png\" style=\"width: 300px; height: 200px; float: right; margin-left: 40px; margin-bottom: 30px\" />The European languages are members of the same family. Their separate existence is a myth. For science, music, sport, etc, Europe uses the same vocabulary. The languages only differ in their grammar, their pronunciation and their most common words.\r\n</p>\r\n\r\n<p>\r\n	Everyone realizes why a new common language would be desirable: one could refuse to pay expensive translators. To achieve this, it would be necessary to have uniform grammar, pronunciation and more common words.\r\n</p>\r\n\r\n<p>\r\n	If several languages coalesce, the grammar of the resulting language is more simple and regular than that of the individual languages. The new common language will be more simple and regular than the existing European languages.\r\n</p>\r\n\r\n<p>\r\n	It will be as simple as Occidental; in fact, it will be Occidental. To an English person, it will seem like simplified English, as a skeptical Cambridge friend of mine told me what Occidental is. The European languages are members of the same family.\r\n</p>\r\n\r\n<p>\r\n	Their separate existence is a myth. For science, music, sport, etc, Europe uses the same vocabulary. The languages only differ in their grammar, their pronunciation and their most common words.\r\n</p>\r\n\r\n<p>\r\n	Everyone realizes why a new common language would be desirable: one could refuse to pay expensive translators. To achieve this, it would be necessary to have uniform grammar, pronunciation and more common words.\r\n</p>\r\n\r\n<p>\r\n	If several languages coalesce, the grammar of the resulting language is more simple and regular than that of the individual languages. The new common language will be more simple and regular than the existing European languages.\r\n</p>\r\n\r\n<p>\r\n	It will be as simple as Occidental; in fact, it will be Occidental. To an English person, it will seem like simplified English, as a skeptical Cambridge friend of mine told me what Occidental is. The European languages are members of the same family.\r\n</p>\r\n\r\n<p>\r\n	Their separate existence is a myth. For science, music, sport, etc, Europe uses the same vocabulary. The languages only differ in their grammar, their pronunciation and their most common words.\r\n</p>\r\n','0','','','','','admin','1393130246','admin','1413967301'),
 ('0000000006','2014/05/21','1400598000','0000000001','','','2','This is 4th NEWS','','1','','','','<div class=\"textbox-img-left\">\r\n	<img alt=\"dummy-image\" src=\"files/images/dummy_gray_300x200.png\" /> The European languages are members of the same family. Their separate existence is a myth. For science, music, sport, etc, Europe uses the same vocabulary. The languages only differ in their grammar, their pronunciation and their most common words.<br />\r\n	The European languages are members of the same family. Their separate existence is a myth. For science, music, sport, etc, Europe uses the same vocabulary. The languages only differ in their grammar, their pronunciation and their most common words.<br />\r\n	The European languages are members of the same family. Their separate existence is a myth. For science, music, sport, etc, Europe uses the same vocabulary. The languages only differ in their grammar, their pronunciation and their most common words.\r\n</div>\r\n','0','','','','','admin','1400656390','admin','1440736467');
/*!40000 ALTER TABLE `%PREFIX%article` ENABLE KEYS */;


--
-- Definition of table `%PREFIX%article2`
--

DROP TABLE IF EXISTS `%PREFIX%article2`;
CREATE TABLE `%PREFIX%article2` (
  `article_id` char(10) NOT NULL default '',
  `article_date_t` text,
  `article_date_u` text,
  `category_id` char(10) default NULL,
  `keywords` text,
  `description` text,
  `publication` char(1) default NULL,
  `title` text,
  `title_img_file` text,
  `description_flag` char(1) default NULL,
  `external_link` char(1) default NULL,
  `external_window` char(1) default NULL,
  `url` text,
  `contents` text,
  `del_flag` char(1) default NULL,
  `folder_id` text,
  `reserve1` text,
  `reserve2` text,
  `reserve3` text,
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text,
  PRIMARY KEY  (`article_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `%PREFIX%article2`
--

/*!40000 ALTER TABLE `%PREFIX%article2` DISABLE KEYS */;
/*!40000 ALTER TABLE `%PREFIX%article2` ENABLE KEYS */;


--
-- Definition of table `%PREFIX%article3`
--

DROP TABLE IF EXISTS `%PREFIX%article3`;
CREATE TABLE `%PREFIX%article3` (
  `article_id` char(10) NOT NULL default '',
  `article_date_t` text,
  `article_date_u` text,
  `category_id` char(10) default NULL,
  `keywords` text,
  `description` text,
  `publication` char(1) default NULL,
  `title` text,
  `title_img_file` text,
  `description_flag` char(1) default NULL,
  `external_link` char(1) default NULL,
  `external_window` char(1) default NULL,
  `url` text,
  `contents` text,
  `del_flag` char(1) default NULL,
  `folder_id` text,
  `reserve1` text,
  `reserve2` text,
  `reserve3` text,
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text,
  PRIMARY KEY  (`article_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `%PREFIX%article3`
--

/*!40000 ALTER TABLE `%PREFIX%article3` DISABLE KEYS */;
/*!40000 ALTER TABLE `%PREFIX%article3` ENABLE KEYS */;


--
-- Definition of table `%PREFIX%category`
--

DROP TABLE IF EXISTS `%PREFIX%category`;
CREATE TABLE `%PREFIX%category` (
  `node_id` char(10) NOT NULL default '',
  `parent_node` char(10) default NULL,
  `node_type` char(10) default NULL,
  `node_class` char(10) default NULL,
  `node_name` text,
  `disp_seq` int(11) default NULL,
  `color` text,
  `background_color` text,
  `icon_file` text,
  `del_flag` char(1) default NULL,
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text,
  PRIMARY KEY  (`node_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `%PREFIX%category`
--

/*!40000 ALTER TABLE `%PREFIX%category` DISABLE KEYS */;
INSERT INTO `%PREFIX%category` (`node_id`,`parent_node`,`node_type`,`node_class`,`node_name`,`disp_seq`,`color`,`background_color`,`icon_file`,`del_flag`,`create_user`,`create_datetime`,`update_user`,`update_datetime`) VALUES 
 ('0000000001','root','category','category','event','0','#fff','#999','','0','admin','1393122783','admin','1416550937'),
 ('0000000002','root','category','category','topics','1','#fff','#999','','0','admin','1393125897','admin','1413969419'),
 ('0000000003','root','category','category','release','2','#fff','#999','','0','admin','1413967239','admin','1413969429'),
 ('0000000004','root','category','category','test','3',NULL,'#00ff00','','1','admin','1413967329','admin','1413967344');
/*!40000 ALTER TABLE `%PREFIX%category` ENABLE KEYS */;


--
-- Definition of table `%PREFIX%category2`
--

DROP TABLE IF EXISTS `%PREFIX%category2`;
CREATE TABLE `%PREFIX%category2` (
  `node_id` char(10) NOT NULL default '',
  `parent_node` char(10) default NULL,
  `node_type` char(10) default NULL,
  `node_class` char(10) default NULL,
  `node_name` text,
  `disp_seq` int(11) default NULL,
  `color` text,
  `background_color` text,
  `icon_file` text,
  `del_flag` char(1) default NULL,
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text,
  PRIMARY KEY  (`node_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `%PREFIX%category2`
--

/*!40000 ALTER TABLE `%PREFIX%category2` DISABLE KEYS */;
/*!40000 ALTER TABLE `%PREFIX%category2` ENABLE KEYS */;


--
-- Definition of table `%PREFIX%category3`
--

DROP TABLE IF EXISTS `%PREFIX%category3`;
CREATE TABLE `%PREFIX%category3` (
  `node_id` char(10) NOT NULL default '',
  `parent_node` char(10) default NULL,
  `node_type` char(10) default NULL,
  `node_class` char(10) default NULL,
  `node_name` text,
  `disp_seq` int(11) default NULL,
  `color` text,
  `background_color` text,
  `icon_file` text,
  `del_flag` char(1) default NULL,
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text,
  PRIMARY KEY  (`node_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `%PREFIX%category3`
--

/*!40000 ALTER TABLE `%PREFIX%category3` DISABLE KEYS */;
/*!40000 ALTER TABLE `%PREFIX%category3` ENABLE KEYS */;


--
-- Definition of table `%PREFIX%compare_version`
--

DROP TABLE IF EXISTS `%PREFIX%compare_version`;
CREATE TABLE `%PREFIX%compare_version` (
  `compare_version_id` char(5) NOT NULL default '',
  PRIMARY KEY  (`compare_version_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `%PREFIX%compare_version`
--

/*!40000 ALTER TABLE `%PREFIX%compare_version` DISABLE KEYS */;
INSERT INTO `%PREFIX%compare_version` (`compare_version_id`) VALUES 
 ('00008');
/*!40000 ALTER TABLE `%PREFIX%compare_version` ENABLE KEYS */;


--
-- Definition of table `%PREFIX%contents`
--

DROP TABLE IF EXISTS `%PREFIX%contents`;
CREATE TABLE `%PREFIX%contents` (
  `version_id` char(5) NOT NULL default '',
  `revision_id` char(2) NOT NULL default '',
  `contents_id` char(10) NOT NULL default '',
  `contents_date` char(10) default NULL,
  `template_id` char(10) default NULL,
  `title` text,
  `breadcrumbs` text,
  `html1` mediumtext,
  `html2` text,
  `html3` text,
  `html4` text,
  `css` mediumtext,
  `php` mediumtext,
  `keywords` text,
  `description` text,
  `external_css` text,
  `external_js` text,
  `header_element` text,
  `del_flag` char(1) default NULL,
  `reserve1` text,
  `reserve2` text,
  `reserve3` text,
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text,
  PRIMARY KEY  (`version_id`,`revision_id`,`contents_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `%PREFIX%contents`
--

/*!40000 ALTER TABLE `%PREFIX%contents` DISABLE KEYS */;
INSERT INTO `%PREFIX%contents` (`version_id`,`revision_id`,`contents_id`,`contents_date`,`template_id`,`title`,`breadcrumbs`,`html1`,`html2`,`html3`,`html4`,`css`,`php`,`keywords`,`description`,`external_css`,`external_js`,`header_element`,`del_flag`,`reserve1`,`reserve2`,`reserve3`,`create_user`,`create_datetime`,`update_user`,`update_datetime`) VALUES 
 ('00001','00','0000000001','','0000000001','site title','','<div class=\"main-image\">\r\n	<img alt=\"main-image\" src=\"images/main-image.png\" />\r\n</div>\r\n\r\n<div class=\"main-contents\">\r\n	<div id=\"title\">\r\n		<h1>TITLE</h1>\r\n\r\n		<p>\r\n			one morning, when Gregor Samsa woke from troubled dreams, he found himself transformed in his bed into a horrible vermin. He lay on his armour-like back, and if he lifted his head a little he could see his brown belly, slightly domed and divided by arches into stiff sections. The bedding was hardly able to cover it and ......\r\n		</p>\r\n	</div>\r\n\r\n	<div class=\"clearfix\" id=\"headline\">\r\n		<div id=\"news\">\r\n			<h2>NEWS &amp; TOPICS</h2>\r\n			<?php widget(\'0000000002\'); // news_top ?>\r\n		</div>\r\n\r\n		<div id=\"special-feature\">\r\n			<h2>SPECIAL FEATURES</h2>\r\n\r\n			<div class=\"special-feature\">\r\n				<div class=\"header\">\r\n					TITLE\r\n				</div>\r\n\r\n				<div class=\"image\">\r\n					<img alt=\"dummy\" src=\"images/dummy_gray_300x200.png\" />\r\n				</div>\r\n\r\n				<div class=\"message\">\r\n					Doing business like this takes much more effort than doing your own ...\r\n				</div>\r\n			</div>\r\n		</div>\r\n	</div>\r\n\r\n	<div id=\"features\">\r\n		<h2>FEATURES</h2>\r\n\r\n		<div class=\"features\">\r\n			<ul class=\"clearfix\">\r\n				<li>\r\n					<a href=\"features\">\r\n						<div class=\"header\">\r\n							<h3>TITLE</h3>\r\n						</div>\r\n\r\n						<div class=\"image\">\r\n							<img alt=\"dummy\" src=\"images/dummy_gray_300x200.png\" />\r\n						</div>\r\n\r\n						<div class=\"message\">\r\n							&quot;What&#39;s happened to me?&quot; he thought.\r\n						</div>\r\n						</a>\r\n				</li>\r\n				<li>\r\n					<a href=\"features\">\r\n						<div class=\"header\">\r\n							<h3>TITLE</h3>\r\n						</div>\r\n\r\n						<div class=\"image\">\r\n							<img alt=\"dummy\" src=\"images/dummy_gray_300x200.png\" />\r\n						</div>\r\n\r\n						<div class=\"message\">\r\n							It wasn&#39;t a dream. His room, a proper human room although a little too small, lay peacefully between its four familiar walls.\r\n						</div>\r\n						</a>\r\n				</li>\r\n				<li>\r\n					<a href=\"features\">\r\n						<div class=\"header\">\r\n							<h3>TITLE</h3>\r\n						</div>\r\n\r\n						<div class=\"image\">\r\n							<img alt=\"dummy\" src=\"images/dummy_gray_300x200.png\" />\r\n						</div>\r\n\r\n						<div class=\"message\">\r\n							A collection of textile samples lay spread out on the table - Samsa was a travelling salesman - and above it there hung ...\r\n						</div>\r\n						</a>\r\n				</li>\r\n				<li>\r\n					<a href=\"features\">\r\n						<div class=\"header\">\r\n							<h3>TITLE</h3>\r\n						</div>\r\n\r\n						<div class=\"image\">\r\n							<img alt=\"dummy\" src=\"images/dummy_gray_300x200.png\" />\r\n						</div>\r\n\r\n						<div class=\"message\">\r\n							It showed a lady fitted out with a fur hat and fur boa who sat upright, raising a heavy fur muff that covered the whole of her lower arm ...\r\n						</div>\r\n						</a>\r\n				</li>\r\n			</ul>\r\n\r\n			<ul class=\"clearfix\">\r\n				<li>\r\n					<a href=\"features\">\r\n						<div class=\"header\">\r\n							<h3>TITLE</h3>\r\n						</div>\r\n\r\n						<div class=\"image\">\r\n							<img alt=\"dummy\" src=\"images/dummy_gray_300x200.png\" />\r\n						</div>\r\n\r\n						<div class=\"message\">\r\n							Drops of rain could be heard hitting the pane, which made him feel quite sad.\r\n						</div>\r\n						</a>\r\n				</li>\r\n				<li>\r\n					<a href=\"features\">\r\n						<div class=\"header\">\r\n							<h3>TITLE</h3>\r\n						</div>\r\n\r\n						<div class=\"image\">\r\n							<img alt=\"dummy\" src=\"images/dummy_gray_300x200.png\" />\r\n						</div>\r\n\r\n						<div class=\"message\">\r\n							&quot;How about if I sleep a little bit longer and forget all this nonsense&quot;, he thought, but that was something he was unable to do because...\r\n						</div>\r\n						</a>\r\n				</li>\r\n				<li>\r\n					<a href=\"features\">\r\n						<div class=\"header\">\r\n							<h3>TITLE</h3>\r\n						</div>\r\n\r\n						<div class=\"image\">\r\n							<img alt=\"dummy\" src=\"images/dummy_gray_300x200.png\" />\r\n						</div>\r\n\r\n						<div class=\"message\">\r\n							However hard he threw himself onto his right, he always rolled back to where he was.\r\n						</div>\r\n						</a>\r\n				</li>\r\n				<li>\r\n					<a href=\"features\">\r\n						<div class=\"header\">\r\n							<h3>TITLE</h3>\r\n						</div>\r\n\r\n						<div class=\"image\">\r\n							<img alt=\"dummy\" src=\"images/dummy_gray_300x200.png\" />\r\n						</div>\r\n\r\n						<div class=\"message\">\r\n							He must have tried it a hundred times, shut his eyes so that he wouldn&#39;t have to look at the floundering legs, and only stopped when ...\r\n						</div>\r\n						</a>\r\n				</li>\r\n			</ul>\r\n		</div>\r\n	</div>\r\n</div>\r\n','','','','.main-image {\r\n	padding: 30px 0;\r\n	text-align: center;\r\n	border-bottom: 1px solid #999;\r\n}\r\n.main-contents {\r\n	padding-bottom: 60px;\r\n}\r\n.main-contents p {\r\n	padding: 4px 20px;\r\n}\r\n#title {\r\n	padding: 0 10px;\r\n}\r\n#headline {\r\n	margin-bottom: 40px;\r\n	padding: 0 10px 40px 10px;\r\n	border-bottom: 1px solid #999;\r\n}\r\n#news {\r\n	width: 570px;\r\n	float: left;\r\n}\r\n#special-feature {\r\n	width: 370px;\r\n	float: right;\r\n}\r\n.special-feature {\r\n	border: 1px solid #999;\r\n}\r\n#features {\r\n	padding: 0 10px;\r\n}\r\n.features ul {\r\n	margin: 0;\r\n	padding: 20px 0;\r\n	list-style: none;\r\n	height: 375px;\r\n}\r\n.features ul li {\r\n	float: left;\r\n	margin-left: 17px;\r\n	border: 1px solid #999;\r\n	width: 230px;\r\n	height: 100%;\r\n}\r\n.features ul li:first-child {\r\n	margin-left: 0;\r\n}\r\n.features ul li a:link,\r\n.features ul li a:visited {\r\n	display: block;\r\n	height: 100%;\r\n}\r\n\r\n.special-feature .header,\r\n.features .header {\r\n	padding: 8px 12px;\r\n	border-bottom: 1px solid #999;\r\n}\r\n.special-feature .image,\r\n.features .image {\r\n	text-align: center;\r\n	padding: 12px 0 12px 0;\r\n}\r\n.special-feature .image img {\r\n	width: 60%;\r\n}\r\n.features .image img {\r\n	width: 90%;\r\n}\r\n.special-feature .message,\r\n.features .message {\r\n	border-top: 1px solid #999;\r\n	padding: 4px 12px;\r\n}\r\n','<?php\r\n	global $global_navi;\r\n	$global_navi = \'home\';\r\n?>','','','','','','0','','','','admin','1392242739','admin','1421631036'),
 ('00001','00','0000000002','','0000000001','NEWS &amp; TOPICS ｜ B-studio','','<div class=\"main-contents\">\r\n	<div id=\"news\">\r\n		<h1>NEWS &amp; TOPICS</h1>\r\n		<?php widget(\'0000000003\'); // news_list ?>\r\n	</div>\r\n</div>','','','','.main-image {\r\n	padding: 30px 0;\r\n	border-bottom: 1px solid #999;\r\n}\r\n.main-image .image {\r\n	float: left;\r\n	width: 400px;\r\n	text-align: center;\r\n	border: 1px solid #999;\r\n	padding: 20px 0 12px 0;\r\n}\r\n.main-image .image img {\r\n	width: 70%;\r\n}\r\n.main-image .text {\r\n	float: right;\r\n	width: 550px;\r\n}\r\n.main-image .text p {\r\n	margin: 0;\r\n	padding: 0 10px;\r\n}\r\n.main-contents {\r\n	padding-bottom: 60px;\r\n}\r\n.main-contents p {\r\n	padding: 4px 20px;\r\n}\r\n#news {\r\n	padding: 0 10px;\r\n}\r\n#news ul {\r\n	margin: 0;\r\n	padding: 20px;\r\n	list-style: none;\r\n}\r\n#news ul li {\r\n	margin: 20px 0;\r\n}\r\n#features ul li .image {\r\n	float: left;\r\n	width: 250px;\r\n	text-align: center;\r\n	border-right: 1px solid #999;\r\n	padding: 20px 0 12px 0;\r\n}\r\n#features ul li .image img {\r\n	width: 70%;\r\n}\r\n#features ul li .text {\r\n	float: right;\r\n	width: 720px;\r\n}\r\n','<?php\r\n	global $global_navi;\r\n	$global_navi = \'features\';\r\n?>','','','','','','0','','','','admin','1392433671','admin','1393224117'),
 ('00001','00','0000000003','','0000000001','B-studio','','<h1>CATEGORY2</h1>\r\n\r\n<div class=\"contents\">\r\n</div>','','','','.catch {\r\n	margin: 0;\r\n	padding: 5px 0 30px 35px;\r\n}\r\n.contents {\r\n	padding: 0 10px;\r\n}\r\n.feature {\r\n	padding-bottom:70px;\r\n	width: 100%;\r\n}\r\n.feature ul {\r\n	margin : 0 auto;\r\n	width: 1000px;\r\n}\r\n.feature ul li {\r\n	float: left;\r\n	width: 230px;\r\n	padding: 0 10px;\r\n}\r\n.aligncenter {\r\n	text-align: center;\r\n}\r\n.aligncenter h3,\r\n.aligncenter p {\r\n	margin-left: 0;\r\n}\r\np.icon {\r\nmargin: 0 auto;\r\nwidth: 44px;\r\nheight: 44px;\r\nbackground-color: #dddddd;\r\nborder: solid 6px #fff;\r\nborder-radius: 60px;\r\n}\r\np.icon img.tree-icon {\r\n	vertical-align: -38px;\r\n}\r\np.icon img.html-icon {\r\n	vertical-align: -34px;\r\n	margin-left: 2px;\r\n}\r\np.icon img.visual-icon {\r\n	vertical-align: -38px;\r\n}\r\np.icon img.version-icon {\r\n	vertical-align: -39px;\r\n}\r\n','<?php\r\n	global $global_navi;\r\n	$global_navi = \'features\';\r\n?>','','','','','','0','','','','admin','1392435642','admin','1421630415'),
 ('00001','00','0000000004','','0000000001','B-studio','','<div class=\"main-image\">\r\n	<img alt=\"main-image\" src=\"images/main-image.png\" />\r\n</div>\r\n<?php widget(\'0000000005\'); // breadcrumbs ?>\r\n<div class=\"main-contents\">\r\n	<div class=\"clearfix\" id=\"features\">\r\n		<h1>CATEGORY1</h1>\r\n\r\n		<p>\r\n			A wonderful serenity has taken possession of my entire soul, like these sweet mornings of spring which I enjoy with my whole heart.\r\n		</p>\r\n\r\n		<div class=\"left clearfix\">\r\n			<ul>\r\n				<li class=\"clearfix\">\r\n					<a href=\"category1/item/\">\r\n						<div class=\"image\">\r\n							<img alt=\"image\" src=\"images/dummy_gray_300x200.png\" />\r\n						</div>\r\n	\r\n						<div class=\"text\">\r\n							<p>\r\n								A wonderful serenity has taken possession of my entire soul, like these sweet mornings of spring which I enjoy with my whole heart.\r\n							</p>\r\n						</div>\r\n					</a>\r\n				</li>\r\n				<li class=\"clearfix\">\r\n					<a href=\"category1/item/\">\r\n						<div class=\"image\">\r\n							<img alt=\"image\" src=\"images/dummy_gray_300x200.png\" />\r\n						</div>\r\n	\r\n						<div class=\"text\">\r\n							<p>\r\n								I am alone, and feel the charm of existence in this spot, which was created for the bliss of souls like mine. I am so happy, my dear fr\r\n							</p>\r\n						</div>\r\n					</a>\r\n				</li>\r\n				<li class=\"clearfix\">\r\n					<a href=\"category1/item/\">\r\n						<div class=\"image\">\r\n							<img alt=\"image\" src=\"images/dummy_gray_300x200.png\" />\r\n						</div>\r\n	\r\n						<div class=\"text\">\r\n							<p>\r\n								I should be incapable of drawing a single stroke at the present moment; and yet I feel that I never was a greater artist than now.\r\n							</p>\r\n						</div>\r\n					</a>\r\n				</li>\r\n				<li class=\"clearfix\">\r\n					<a href=\"category1/item/\">\r\n						<div class=\"image\">\r\n							<img alt=\"image\" src=\"images/dummy_gray_300x200.png\" />\r\n						</div>\r\n	\r\n						<div class=\"text\">\r\n							<p>\r\n								When, while the lovely valley teems with vapour around me, and the meridian sun strikes the upper surface of the impenetrable foliage of my trees, and but a few ...\r\n							</p>\r\n						</div>\r\n					</a>\r\n				</li>\r\n				<li class=\"clearfix\">\r\n					<a href=\"category1/item/\">\r\n						<div class=\"image\">\r\n							<img alt=\"image\" src=\"images/dummy_gray_300x200.png\" />\r\n						</div>\r\n	\r\n						<div class=\"text\">\r\n							<p>\r\n								When, while the lovely valley teems with vapour around me, and the meridian sun strikes the upper surface of the impenetrable foliage of my trees, and but a few ...\r\n							</p>\r\n						</div>\r\n					</a>\r\n				</li>\r\n				<li class=\"clearfix\">\r\n					<a href=\"category1/item/\">\r\n						<div class=\"image\">\r\n							<img alt=\"image\" src=\"images/dummy_gray_300x200.png\" />\r\n						</div>\r\n	\r\n						<div class=\"text\">\r\n							<p>\r\n								When, while the lovely valley teems with vapour around me, and the meridian sun strikes the upper surface of the impenetrable foliage of my trees, and but a few ...\r\n							</p>\r\n						</div>\r\n					</a>\r\n				</li>\r\n			</ul>\r\n		</div>\r\n\r\n		<div class=\"right\">\r\n			<ul>\r\n				<li class=\"clearfix\">\r\n					<div class=\"image\">\r\n						<img alt=\"image\" src=\"images/dummy_gray_300x200.png\" />\r\n					</div>\r\n\r\n					<div class=\"text\">\r\n						<p>\r\n							A wonderful serenity has taken possession of my entire soul, like\r\n						</p>\r\n					</div>\r\n				</li>\r\n				<li class=\"clearfix\">\r\n					<div class=\"image\">\r\n						<img alt=\"image\" src=\"images/dummy_gray_300x200.png\" />\r\n					</div>\r\n\r\n					<div class=\"text\">\r\n						<p>\r\n							I am alone, and feel the charm of existence in this spot,\r\n						</p>\r\n					</div>\r\n				</li>\r\n				<li class=\"clearfix\">\r\n					<div class=\"image\">\r\n						<img alt=\"image\" src=\"images/dummy_gray_300x200.png\" />\r\n					</div>\r\n\r\n					<div class=\"text\">\r\n						<p>\r\n							I am alone, and feel the charm of existence in this spot,\r\n						</p>\r\n					</div>\r\n				</li>\r\n				<li class=\"clearfix\">\r\n					<div class=\"image\">\r\n						<img alt=\"image\" src=\"images/dummy_gray_300x200.png\" />\r\n					</div>\r\n\r\n					<div class=\"text\">\r\n						<p>\r\n							I am alone, and feel the charm of existence in this spot,\r\n						</p>\r\n					</div>\r\n				</li>\r\n				<li class=\"clearfix\">\r\n					<div class=\"image\">\r\n						<img alt=\"image\" src=\"images/dummy_gray_300x200.png\" />\r\n					</div>\r\n\r\n					<div class=\"text\">\r\n						<p>\r\n							I am alone, and feel the charm of existence in this spot,\r\n						</p>\r\n					</div>\r\n				</li>\r\n			</ul>\r\n		</div>\r\n	</div>\r\n</div>\r\n','','','','.main-image {\r\n	padding: 30px 0;\r\n	text-align: center;\r\n	border-bottom: 1px solid #999;\r\n}\r\n.main-image .image {\r\n	float: left;\r\n	width: 400px;\r\n	text-align: center;\r\n	border: 1px solid #999;\r\n	padding: 20px 0 12px 0;\r\n}\r\n.main-image .image img {\r\n	width: 70%;\r\n}\r\n.main-image .text {\r\n	float: right;\r\n	width: 550px;\r\n}\r\n.main-image .text p {\r\n	margin: 0;\r\n	padding: 0 10px;\r\n}\r\n.main-contents {\r\n	padding-bottom: 60px;\r\n}\r\n.main-contents p {\r\n	padding: 4px 20px;\r\n}\r\n#features {\r\n	padding: 0 10px;\r\n}\r\n.left ul {\r\n	margin: 0;\r\n	padding: 20px 0;\r\n	list-style: none;\r\n}\r\n.left ul li {\r\n	border: 1px solid #999;\r\n	margin: 20px 0;\r\n}\r\n.left ul li .image {\r\n	float: left;\r\n	width: 250px;\r\n	text-align: center;\r\n	border-right: 1px solid #999;\r\n	padding: 15px 0 14px 0;\r\n}\r\n.left ul li .image img {\r\n	width: 70%;\r\n}\r\n.left ul li .text {\r\n	float: right;\r\n	width: 420px;\r\n}\r\n.left {\r\n	width: 700px;\r\n	float: left;\r\n}\r\n.right ul {\r\n	margin: 0;\r\n	padding: 20px 0;\r\n	list-style: none;\r\n}\r\n.right ul li {\r\n	border: 1px solid #999;\r\n	margin: 12px 0;\r\n}\r\n.right ul li:first-child {\r\n	margin: 20px 0 0 0;\r\n}\r\n.right ul li .image {\r\n	float: left;\r\n	width: 90px;\r\n	text-align: center;\r\n	border-right: 1px solid #999;\r\n	padding: 15px 0 12px 0;\r\n}\r\n.right ul li .image img {\r\n	width: 80%;\r\n}\r\n.right ul li .text {\r\n	float: right;\r\n	width: 157px;\r\n	font-size: 10px;\r\n}\r\n.right ul li .text p {\r\n	padding: 4px 8px;\r\n}\r\n.right {\r\n	width: 250px;\r\n	float: right;\r\n}','<?php\r\n	global $global_navi;\r\n	$global_navi = \'category1\';\r\n?>','','','','','','0','','','','admin','1392453810','admin','1421630389'),
 ('00001','00','0000000005','','0000000001','Function | B-studio','','<div class=\"main-image clearfix\">\r\n	<div class=\"image\">\r\n		<img alt=\"image\" src=\"images/dummy_gray_300x200.png\" />\r\n	</div>\r\n\r\n	<div class=\"text\">\r\n		<p>\r\n			One morning, when Gregor Samsa woke from troubled dreams, he found himself transformed in his bed into a horrible vermin. He lay on his armour-like back, and if he lifted his head a little he could see his brown belly, slightly domed and divided by arches into stiff sections. The bedding was hardly able to cover it and ......\r\n		</p>\r\n	</div>\r\n</div>\r\n\r\n<div class=\"main-contents\">\r\n	<div id=\"features\">\r\n		<h1>FEATURES</h1>\r\n\r\n		<p>\r\n			A wonderful serenity has taken possession of my entire soul, like these sweet mornings of spring which I enjoy with my whole heart.\r\n		</p>\r\n\r\n		<ul>\r\n			<li class=\"clearfix\">\r\n				<div class=\"image\">\r\n					<img alt=\"image\" src=\"images/dummy_gray_300x200.png\" />\r\n				</div>\r\n\r\n				<div class=\"text\">\r\n					<p>\r\n						A wonderful serenity has taken possession of my entire soul, like these sweet mornings of spring which I enjoy with my whole heart.\r\n					</p>\r\n				</div>\r\n			</li>\r\n			<li class=\"clearfix\">\r\n				<div class=\"image\">\r\n					<img alt=\"image\" src=\"images/dummy_gray_300x200.png\" />\r\n				</div>\r\n\r\n				<div class=\"text\">\r\n					<p>\r\n						I am alone, and feel the charm of existence in this spot, which was created for the bliss of souls like mine. I am so happy, my dear friend, so absorbed in the exquisite sense of mere tranquil existence, that I neglect my talents.\r\n					</p>\r\n				</div>\r\n			</li>\r\n			<li class=\"clearfix\">\r\n				<div class=\"image\">\r\n					<img alt=\"image\" src=\"images/dummy_gray_300x200.png\" />\r\n				</div>\r\n\r\n				<div class=\"text\">\r\n					<p>\r\n						I should be incapable of drawing a single stroke at the present moment; and yet I feel that I never was a greater artist than now.\r\n					</p>\r\n				</div>\r\n			</li>\r\n			<li class=\"clearfix\">\r\n				<div class=\"image\">\r\n					<img alt=\"image\" src=\"images/dummy_gray_300x200.png\" />\r\n				</div>\r\n\r\n				<div class=\"text\">\r\n					<p>\r\n						When, while the lovely valley teems with vapour around me, and the meridian sun strikes the upper surface of the impenetrable foliage of my trees, and but a few stray gleams steal into the inner sanctuary, I throw myself down among the tall grass by the trickling stream; and, as I lie close to the ...\r\n					</p>\r\n				</div>\r\n			</li>\r\n			<li class=\"clearfix\">\r\n				<div class=\"image\">\r\n					<img alt=\"image\" src=\"images/dummy_gray_300x200.png\" />\r\n				</div>\r\n\r\n				<div class=\"text\">\r\n					<p>\r\n						But I must explain to you how all this mistaken idea of denouncing pleasure and praising pain was born and I will give you a complete account of the system, and expound the actual teachings of the great explorer of the truth, the master-builder of human happiness.\r\n					</p>\r\n				</div>\r\n			</li>\r\n			<li class=\"clearfix\">\r\n				<div class=\"image\">\r\n					<img alt=\"image\" src=\"images/dummy_gray_300x200.png\" />\r\n				</div>\r\n\r\n				<div class=\"text\">\r\n					<p>\r\n						No one rejects, dislikes, or avoids pleasure itself, because it is pleasure, but because those who do not know how to pursue pleasure rationally encounter consequences that are extremely painful.\r\n					</p>\r\n				</div>\r\n			</li>\r\n			<li class=\"clearfix\">\r\n				<div class=\"image\">\r\n					<img alt=\"image\" src=\"images/dummy_gray_300x200.png\" />\r\n				</div>\r\n\r\n				<div class=\"text\">\r\n					<p>\r\n						Nor again is there anyone who loves or pursues or desires to obtain pain of itself, because it is pain, but because occasionally circumstances occur in which toil and pain can procure him some great pleasure.\r\n					</p>\r\n				</div>\r\n			</li>\r\n			<li class=\"clearfix\">\r\n				<div class=\"image\">\r\n					<img alt=\"image\" src=\"images/dummy_gray_300x200.png\" />\r\n				</div>\r\n\r\n				<div class=\"text\">\r\n					<p>\r\n						To take a trivial example, which of us ever undertakes laborious physical exercise, except to obtain some advantage from it?\r\n					</p>\r\n				</div>\r\n			</li>\r\n		</ul>\r\n	</div>\r\n</div>\r\n','','','','.main-image {\r\n	padding: 30px 0;\r\n	border-bottom: 1px solid #999;\r\n}\r\n.main-image .image {\r\n	float: left;\r\n	width: 400px;\r\n	text-align: center;\r\n	border: 1px solid #999;\r\n	padding: 20px 0 12px 0;\r\n}\r\n.main-image .image img {\r\n	width: 70%;\r\n}\r\n.main-image .text {\r\n	float: right;\r\n	width: 550px;\r\n}\r\n.main-image .text p {\r\n	margin: 0;\r\n	padding: 0 10px;\r\n}\r\n.main-contents {\r\n	padding-bottom: 60px;\r\n}\r\n.main-contents p {\r\n	padding: 4px 20px;\r\n}\r\n#features {\r\n	padding: 0 10px;\r\n}\r\n#features ul {\r\n	margin: 0;\r\n	padding: 20px 0;\r\n	list-style: none;\r\n}\r\n#features ul li {\r\n	border: 1px solid #999;\r\n	margin: 20px 0;\r\n}\r\n#features ul li .image {\r\n	float: left;\r\n	width: 250px;\r\n	text-align: center;\r\n	border-right: 1px solid #999;\r\n	padding: 20px 0 12px 0;\r\n}\r\n#features ul li .image img {\r\n	width: 70%;\r\n}\r\n#features ul li .text {\r\n	float: right;\r\n	width: 720px;\r\n}\r\n','<?php\r\n	global $global_navi;\r\n	$global_navi = \'function\';\r\n?>','','','','','','0','','','','admin','1392510099','admin','1421630447'),
 ('00001','00','0000000006','','0000000002','HTMLテンプレート | function | B-studio','','<h1>CATEGORY3</h1>\r\n','','','','','<?php\r\n	global $global_navi;\r\n	$global_navi = \'function\';\r\n?>','','','','','','0','','','','admin','1392510214','admin','1421630423'),
 ('00001','00','0000000007','','0000000001','CATEGORY4 | B-studio','','<h1>CATEGORY4</h1>\r\n','','','','','<?php\r\n	global $global_navi;\r\n	$global_navi = \'function\';\r\n?>','','','','','','0','','','','admin','1392518007','admin','1421630429'),
 ('00001','00','0000000008','','0000000002','ビジュアルエディター | Function | B-studio','','<h1>Function</h1>\r\n\r\n<div class=\"contents\">\r\n	<h2>ビジュアルエディター</h2>\r\n	<div class=\"contents-box clearfix\">\r\n		<div>\r\n			<p>HTMLエディタで作成したページ、続きをビジュアルエディタで編集することができます。 インラインエディタですので、ページ全体 すべてが表示された状態で編集することができます。\r\n			</p>\r\n		</div>\r\n	</div>\r\n	<div class=\"contents-box clearfix\">\r\n		<div>\r\n			<p class=\"center\"><img src=\"images/function/visual_editor_function.png\" alt=\"HTML editor\" /></p>\r\n			<p>テキストの編集や画像の差し替えなどはビジュアルエディタを使って簡単に行うことができますが、レイアウトにかかわる修正はHTMLエディタを使用することをお勧めします。</p>\r\n			<p><span class=\"caution\">※</span>ビジュアルエディタ内では、javascriptは機能しません</p>\r\n		</div>\r\n	</div>\r\n</div>','','','','','<?php\r\n	global $global_navi;\r\n	$global_navi = \'function\';\r\n?>','CMS','自由度を最優先したCMS、直感的なインターフェースによりWEBサイトを管理します。','','','','0','','','','admin','1392539461','admin','1392588283'),
 ('00001','00','0000000009','','','','','<p>string:<?php echo $string; ?></p>\r\n<p>new string:<?php echo $new_string; ?></p>\r\n','','','','','<?php\r\n	$string = \'\r\nCREATE ALGORITHM=UNDEFINED DEFINER=`aa131buw6haaaa`@`localhaaaaost` SQL SECURITY DEFINER VIEW `bs_v_w_widget` AS select `a`.`version_id` AS `version_id`,`a`.`revision_id` AS `revision_id`,`a`.`contents_id` AS `contents_id`,`a`.`contents_date` AS `contents_date`,`a`.`widget_id` AS `widget_id`,`a`.`html` AS `html`,`a`.`css` AS `css`,`a`.`php` AS `php`,`a`.`del_flag` AS `del_flag`,`a`.`reserve1` AS `reserve1`,`a`.`reserve2` AS `reserve2`,`a`.`reserve3` AS `reserve3`,`a`.`create_user` AS `create_user`,`a`.`create_datetime` AS `create_datetime`,`a`.`update_user` AS `update_user`,`a`.`update_datetime` AS `update_datetime` from `bs_widget` `a` where (concat(`a`.`version_id`,`a`.`revision_id`) = (select max(concat(`b`.`version_id`,`b`.`revision_id`)) from ((`bs_widget` `b` join `bs_v_current_version` `c`) join `bs_version` `d`) where ((`a`.`contents_id` = `b`.`contents_id`) and (`b`.`version_id` = `d`.`version_id`) and (((`b`.`version_id` < `c`.`working_version_id`) and (`b`.`revision_id` < `d`.`private_revision_id`)) or ((`b`.`version_id` = `c`.`working_version_id`) and (`b`.`revision_id` <= `d`.`private_revision_id`)))) group by `b`.`contents_id`));\';\r\n	$new_string = preg_replace(\'/DEFINER=`\\w*`@`\\w*`/\', \'\', $string);\r\n	$new_string = preg_replace(\'/ALGORITHM=\\w*/\', \'\', $new_string);\r\n	$new_string = preg_replace(\'/ SQL SECURITY DEFINER/\', \'\', $new_string);\r\n\r\n?>','','','','','','0','','','','admin','1393027240','admin','1393036396'),
 ('00001','00','0000000010','','0000000001',' | Bstudio','','<div class=\"main-contents\">\r\n	<div id=\"news\">\r\n		<p class=\"title\">NEWS &amp; TOPICS</p>\r\n		<h1><?php echo $title; ?></h1>\r\n		<div class=\"section\">\r\n			<?php echo $contents; ?>\r\n		</div>\r\n	</div>\r\n</div>','','','','p.title {\r\n	margin: 22px 0;\r\n	font-size: 34px;\r\n	font-weight: bold;\r\n}\r\nh1 {\r\n	margin: 20px 0;\r\n	font-size: 26px;\r\n}\r\n.section {\r\n	padding: 20px;\r\n	font-size: 16px;\r\n	font-weight: normal;\r\n}\r\n\r\n.section .textbox-img-right,\r\n.section .textbox-img-left {\r\n	overflow: hidden;\r\n	padding: 20px 0;\r\n}\r\n\r\n.section .textbox-img-right img {\r\n	float: right;\r\n	margin: 0 0 10px 10px;\r\n}\r\n\r\n.section .textbox-img-left img {\r\n	float: left;\r\n	margin: 0 10px 10px 0;\r\n}','<?php\r\n	// view_mode\r\n	if($bs_view_mode == \'preview\') {\r\n		$id = \'0000000001\';\r\n	}\r\n	else {\r\n		$id = $bs_db->real_escape_string($_REQUEST[\'id\']);\r\n		if(!$id) notfound();\r\n	}\r\n\r\n	$sql = \"select * from \" . B_ARTICLE_VIEW . \" where article_id=\'$id\'\";\r\n\r\n	$rs = $bs_db->query($sql);\r\n	$row = $bs_db->fetch_assoc($rs);\r\n	if(!$row) notfound();\r\n\r\n	$article_date = date(\'Y年n月j日\', $row[\'article_date_u\']);\r\n	$title = str_replace(\"n\", \"<br />\", $row[\'title\']);\r\n	$contents = $row[\'contents\'];\r\n\r\n	$bs_html_header->title = $row[\'title\'] . $bs_html_header->title;\r\n	if($row[\'keywords\']) {\r\n		$bs_html_header->appendMeta(\'keywords\', htmlspecialchars($row[\'keywords\'], ENT_QUOTES, B_CHARSET));\r\n	}\r\n\r\n	if($row[\'description\']) {\r\n		$bs_html_header->appendMeta(\'description\', htmlspecialchars($row[\'description\'], ENT_QUOTES, B_CHARSET));\r\n	}\r\n\r\n	$bread_crumb_disp_name = $row[\'title\'];\r\n?>','','','','','','0','','','','admin','1393224181','admin','1440735904'),
 ('00001','00','0000000011','','0000000001','Detail | B-studio','','<div class=\"main-image clearfix\">\r\n	<div class=\"image\">\r\n		<img alt=\"image\" src=\"images/dummy_gray_300x200.png\" />\r\n	</div>\r\n\r\n	<div class=\"text\">\r\n		<p>\r\n			One morning, when Gregor Samsa woke from troubled dreams, he found himself transformed in his bed into a horrible vermin. He lay on his armour-like back, and if he lifted his head a little he could see his brown belly, slightly domed and divided by arches into stiff sections. The bedding was hardly able to cover it and ......\r\n		</p>\r\n	</div>\r\n</div>\r\n\r\n<div class=\"main-contents\">\r\n	<div id=\"detail\">\r\n		<h1>PRODUCT NAME Ver.1</h1>\r\n\r\n		<p>\r\n			A wonderful serenity has taken possession of my entire soul, like these sweet mornings of spring which I enjoy with my whole heart.\r\n		</p>\r\n\r\n		<ul>\r\n			<li class=\"clearfix\">\r\n				<div class=\"image\">\r\n					<img alt=\"image\" src=\"images/dummy_gray_300x200.png\" />\r\n				</div>\r\n\r\n				<div class=\"text\">\r\n					<p>\r\n						A wonderful serenity has taken possession of my entire soul, like these sweet mornings of spring which I enjoy with my whole heart.\r\n					</p>\r\n				</div>\r\n			</li>\r\n			<li class=\"clearfix\">\r\n				<div class=\"image\">\r\n					<img alt=\"image\" src=\"images/dummy_gray_300x200.png\" />\r\n				</div>\r\n\r\n				<div class=\"text\">\r\n					<p>\r\n						A wonderful serenity has taken possession of my entire soul, like these sweet mornings of spring which I enjoy with my whole heart.\r\n					</p>\r\n				</div>\r\n			</li>\r\n			<li class=\"clearfix\">\r\n				<div class=\"image\">\r\n					<img alt=\"image\" src=\"images/dummy_gray_300x200.png\" />\r\n				</div>\r\n\r\n				<div class=\"text\">\r\n					<p>\r\n						A wonderful serenity has taken possession of my entire soul, like these sweet mornings of spring which I enjoy with my whole heart.\r\n					</p>\r\n				</div>\r\n			</li>\r\n			<li class=\"clearfix\">\r\n				<div class=\"image\">\r\n					<img alt=\"image\" src=\"images/dummy_gray_300x200.png\" />\r\n				</div>\r\n\r\n				<div class=\"text\">\r\n					<p>\r\n						A wonderful serenity has taken possession of my entire soul, like these sweet mornings of spring which I enjoy with my whole heart.\r\n					</p>\r\n				</div>\r\n			</li>\r\n			<li class=\"clearfix\">\r\n				<div class=\"image\">\r\n					<img alt=\"image\" src=\"images/dummy_gray_300x200.png\" />\r\n				</div>\r\n\r\n				<div class=\"text\">\r\n					<p>\r\n						A wonderful serenity has taken possession of my entire soul, like these sweet mornings of spring which I enjoy with my whole heart.\r\n					</p>\r\n				</div>\r\n			</li>\r\n			<li class=\"clearfix\">\r\n				<div class=\"image\">\r\n					<img alt=\"image\" src=\"images/dummy_gray_300x200.png\" />\r\n				</div>\r\n\r\n				<div class=\"text\">\r\n					<p>\r\n						A wonderful serenity has taken possession of my entire soul, like these sweet mornings of spring which I enjoy with my whole heart.\r\n					</p>\r\n				</div>\r\n			</li>\r\n		</ul>\r\n	</div>\r\n</div>\r\n','','','','.main-image {\r\n	padding: 30px 0;\r\n	border-bottom: 1px solid #999;\r\n}\r\n.main-image .image {\r\n	float: left;\r\n	width: 400px;\r\n	text-align: center;\r\n	border: 1px solid #999;\r\n	padding: 20px 0 12px 0;\r\n}\r\n.main-image .image img {\r\n	width: 70%;\r\n}\r\n.main-image .text {\r\n	float: right;\r\n	width: 550px;\r\n}\r\n.main-image .text p {\r\n	margin: 0;\r\n	padding: 0 10px;\r\n}\r\n.main-contents {\r\n	padding-bottom: 60px;\r\n}\r\n.main-contents p {\r\n	padding: 4px 20px;\r\n}\r\n#detail {\r\n	padding: 0 10px;\r\n}\r\n#detail ul {\r\n	margin: 0;\r\n	padding: 20px 0;\r\n	list-style: none;\r\n}\r\n#detail ul li {\r\n	border-bottom: 1px solid #e5e5e5;\r\n	margin: 20px 0;\r\n}\r\n#detail ul li .image {\r\n	width: 250px;\r\n	text-align: center;\r\n	padding: 20px 0 12px 0;\r\n}\r\n#detail ul li .image img {\r\n	width: 70%;\r\n}\r\n#detail ul li .text {\r\n	width: 720px;\r\n}\r\n\r\n#detail ul li:nth-child(odd) .image {\r\n	float: right;\r\n}\r\n\r\n#detail ul li:nth-child(odd) .text {\r\n	float: left;\r\n}\r\n\r\n#detail ul li:nth-child(even) .image {\r\n	float: left;\r\n}\r\n\r\n#detail ul li:nth-child(even) .text {\r\n	float: right;\r\n}','<?php\r\n	global $global_navi;\r\n	$global_navi = \'function\';\r\n?>','','','','','','0','','','','admin','1400564115','admin','1421630439'),
 ('00001','00','0000000012','','0000000001','site title','','<div class=\"main-contents\">\r\n	<p class=\"message\">お探しのページは見つかりませんでした。</p>\r\n</div>','','','','p.message {\r\n	text-align: center;\r\n	padding: 180px 0;\r\n}','','','','','','','0','','','','admin','1434940140','admin','1434940231');
/*!40000 ALTER TABLE `%PREFIX%contents` ENABLE KEYS */;


--
-- Definition of table `%PREFIX%contents_node`
--

DROP TABLE IF EXISTS `%PREFIX%contents_node`;
CREATE TABLE `%PREFIX%contents_node` (
  `version_id` char(5) NOT NULL default '',
  `revision_id` char(2) NOT NULL default '',
  `node_id` char(10) NOT NULL default '',
  `parent_node` char(10) default NULL,
  `node_type` char(10) default NULL,
  `node_class` char(10) default NULL,
  `node_name` text,
  `contents_id` char(10) default NULL,
  `disp_seq` int(11) default NULL,
  `del_flag` char(1) default NULL,
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text,
  PRIMARY KEY  (`version_id`,`revision_id`,`node_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `%PREFIX%contents_node`
--

/*!40000 ALTER TABLE `%PREFIX%contents_node` DISABLE KEYS */;
INSERT INTO `%PREFIX%contents_node` (`version_id`,`revision_id`,`node_id`,`parent_node`,`node_type`,`node_class`,`node_name`,`contents_id`,`disp_seq`,`del_flag`,`create_user`,`create_datetime`,`update_user`,`update_datetime`) VALUES 
 ('00001','00','0000000001','root','page','leaf','index.html','0000000001','0','0','admin','1392242516','admin','1393185950'),
 ('00001','00','0000000002','root','folder','folder','news','','1','0','admin','1392433661','admin','1393185950'),
 ('00001','00','0000000003','0000000002','page','leaf','index.html','0000000002','0','0','admin','1392433671','admin','1392433671'),
 ('00001','00','0000000004','root','folder','folder','category2','','4','0','admin','1392435632','admin','1393225391'),
 ('00001','00','0000000005','0000000004','page','leaf','index.html','0000000003','0','0','admin','1392435642','admin','1392435642'),
 ('00001','00','0000000006','root','folder','folder','category1','','3','0','admin','1392453810','admin','1393225386'),
 ('00001','00','0000000007','0000000006','page','leaf','index.html','0000000004','0','0','admin','1392453810','admin','1392453810'),
 ('00001','00','0000000008','root','folder','folder','features','','2','0','admin','1392510099','admin','1393185959'),
 ('00001','00','0000000009','0000000008','page','leaf','index.html','0000000005','0','0','admin','1392510099','admin','1392510099'),
 ('00001','00','0000000010','0000000016','page','leaf','index.html','0000000006','0','0','admin','1392510214','admin','1393225413'),
 ('00001','00','0000000012','0000000017','page','leaf','index.html','0000000007','0','0','admin','1392518007','admin','1393225430'),
 ('00001','00','0000000015','0000000002','page','leaf','detail','0000000010','1','0','admin','1393223707','admin','1393223709'),
 ('00001','00','0000000016','root','folder','folder','category3','','5','0','admin','1393225401','admin','1393225403'),
 ('00001','00','0000000017','root','folder','folder','category4','','6','0','admin','1393225417','admin','1393225421'),
 ('00001','00','0000000019','0000000006','folder','folder','item','','1','0','admin','1400564098','admin','1400564101'),
 ('00001','00','0000000020','0000000019','page','leaf','index.html','0000000011','0','0','admin','1400564115','admin','1400564115'),
 ('00001','00','0000000021','root','page','leaf','notfound.html','0000000012','7','0','admin','1434940100','admin','1434940104');
/*!40000 ALTER TABLE `%PREFIX%contents_node` ENABLE KEYS */;


--
-- Definition of table `%PREFIX%current_version`
--

DROP TABLE IF EXISTS `%PREFIX%current_version`;
CREATE TABLE `%PREFIX%current_version` (
  `id` char(10) NOT NULL default '',
  `current_version_id` char(5) default NULL,
  `reserved_version_id` char(5) default NULL,
  `working_version_id` char(5) default NULL,
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `%PREFIX%current_version`
--

/*!40000 ALTER TABLE `%PREFIX%current_version` DISABLE KEYS */;
INSERT INTO `%PREFIX%current_version` (`id`,`current_version_id`,`reserved_version_id`,`working_version_id`,`create_user`,`create_datetime`,`update_user`,`update_datetime`) VALUES 
 ('0000000001','00001','00001','00001','installer','1392242480','','');
/*!40000 ALTER TABLE `%PREFIX%current_version` ENABLE KEYS */;


--
-- Definition of table `%PREFIX%resource_node`
--

DROP TABLE IF EXISTS `%PREFIX%resource_node`;
CREATE TABLE `%PREFIX%resource_node` (
  `version_id` char(5) NOT NULL default '',
  `revision_id` char(2) NOT NULL default '',
  `node_id` char(10) NOT NULL default '',
  `parent_node` char(10) default NULL,
  `node_type` char(10) default NULL,
  `node_class` char(10) default NULL,
  `node_name` text,
  `file_size` int(11) default NULL,
  `human_file_size` text,
  `image_size` int(11) default NULL,
  `human_image_size` text,
  `contents_id` char(19) default NULL,
  `disp_seq` int(11) default NULL,
  `del_flag` char(1) default NULL,
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text,
  PRIMARY KEY  (`version_id`,`revision_id`,`node_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `%PREFIX%resource_node`
--

/*!40000 ALTER TABLE `%PREFIX%resource_node` DISABLE KEYS */;
INSERT INTO `%PREFIX%resource_node` (`version_id`,`revision_id`,`node_id`,`parent_node`,`node_type`,`node_class`,`node_name`,`file_size`,`human_file_size`,`image_size`,`human_image_size`,`contents_id`,`disp_seq`,`del_flag`,`create_user`,`create_datetime`,`update_user`,`update_datetime`) VALUES 
 ('00001','00','0000000001','root','folder','folder','images','0','','0','','0000000001_00001_00','0','0','admin','1443057535','admin','1443057535'),
 ('00001','00','0000000002','0000000001','file','leaf','dummy_gray_300x200.png','2224','2.2KB','60000','300x200','0000000002_00001_00','0','0','admin','1443057535','admin','1443057535'),
 ('00001','00','0000000003','0000000001','file','leaf','dummy_white_300x200.png','2230','2.2KB','60000','300x200','0000000003_00001_00','1','0','admin','1443057535','admin','1443057535'),
 ('00001','00','0000000004','0000000001','file','leaf','main-image.png','1765','1.8KB','180000','900x200','0000000004_00001_00','2','0','admin','1443057535','admin','1443057535'),
 ('00001','00','0000000005','0000000001','file','leaf','new_image.jpg','17233','16.9KB','59899','301x199','0000000005_00001_00','3','0','admin','1443057535','admin','1443057535'),
 ('00001','00','0000000006','root','folder','folder','visualeditor','0','','0','','0000000006_00001_00','1','0','admin','1443057535','admin','1443057535'),
 ('00001','00','0000000007','0000000006','folder','folder','article1','0','','0','','0000000007_00001_00','0','0','admin','1443057535','admin','1443057535'),
 ('00001','00','0000000008','0000000007','folder','folder','css','0','','0','','0000000008_00001_00','0','0','admin','1443057535','admin','1443057535'),
 ('00001','00','0000000009','0000000008','file','leaf','default.css','2190','2.2KB','0','','0000000009_00001_00','0','0','admin','1443057535','admin','1443057535'),
 ('00001','00','0000000010','0000000007','folder','folder','styles','0','','0','','0000000010_00001_00','1','0','admin','1443057535','admin','1443057535'),
 ('00001','00','0000000011','0000000010','file','leaf','styles.js','3662','3.6KB','0','','0000000011_00001_00','0','0','admin','1443057535','admin','1443057535'),
 ('00001','00','0000000012','0000000007','folder','folder','templates','0','','0','','0000000012_00001_00','2','0','admin','1443057535','admin','1443057535'),
 ('00001','00','0000000013','0000000012','folder','folder','images','0','','0','','0000000013_00001_00','0','0','admin','1443057535','admin','1443057535'),
 ('00001','00','0000000014','0000000013','file','leaf','template1.gif','2181','2.2KB','7000','100x70','0000000014_00001_00','0','0','admin','1443057535','admin','1443057535'),
 ('00001','00','0000000015','0000000013','file','leaf','template2.gif','333','0.4KB','7000','100x70','0000000015_00001_00','1','0','admin','1443057535','admin','1443057535'),
 ('00001','00','0000000016','0000000013','file','leaf','template3.gif','2242','2.2KB','7000','100x70','0000000016_00001_00','2','0','admin','1443057535','admin','1443057535'),
 ('00001','00','0000000017','0000000013','file','leaf','template4.gif','1552','1.6KB','7000','100x70','0000000017_00001_00','3','0','admin','1443057535','admin','1443057535'),
 ('00001','00','0000000018','0000000013','file','leaf','template5.gif','1554','1.6KB','7000','100x70','0000000018_00001_00','4','0','admin','1443057535','admin','1443057535'),
 ('00001','00','0000000019','0000000012','file','leaf','default.js','2289','2.3KB','0','','0000000019_00001_00','1','0','admin','1443057535','admin','1443057535'),
 ('00001','00','0000000020','0000000006','folder','folder','article2','0','','0','','0000000020_00001_00','1','0','admin','1443057535','admin','1443057535'),
 ('00001','00','0000000021','0000000020','folder','folder','css','0','','0','','0000000021_00001_00','0','0','admin','1443057535','admin','1443057535'),
 ('00001','00','0000000022','0000000021','file','leaf','default.css','1841','1.8KB','0','','0000000022_00001_00','0','0','admin','1443057535','admin','1443057535'),
 ('00001','00','0000000023','0000000020','folder','folder','styles','0','','0','','0000000023_00001_00','1','0','admin','1443057535','admin','1443057535'),
 ('00001','00','0000000024','0000000023','file','leaf','styles.js','3662','3.6KB','0','','0000000024_00001_00','0','0','admin','1443057535','admin','1443057535'),
 ('00001','00','0000000025','0000000020','folder','folder','templates','0','','0','','0000000025_00001_00','2','0','admin','1443057535','admin','1443057535'),
 ('00001','00','0000000026','0000000025','folder','folder','images','0','','0','','0000000026_00001_00','0','0','admin','1443057535','admin','1443057535'),
 ('00001','00','0000000027','0000000026','file','leaf','template1.gif','2181','2.2KB','7000','100x70','0000000027_00001_00','0','0','admin','1443057535','admin','1443057535'),
 ('00001','00','0000000028','0000000026','file','leaf','template2.gif','333','0.4KB','7000','100x70','0000000028_00001_00','1','0','admin','1443057535','admin','1443057535'),
 ('00001','00','0000000029','0000000026','file','leaf','template3.gif','2242','2.2KB','7000','100x70','0000000029_00001_00','2','0','admin','1443057535','admin','1443057535'),
 ('00001','00','0000000030','0000000025','file','leaf','default.js','603','0.6KB','0','','0000000030_00001_00','1','0','admin','1443057535','admin','1443057535'),
 ('00001','00','0000000031','0000000006','folder','folder','article3','0','','0','','0000000031_00001_00','2','0','admin','1443057535','admin','1443057535'),
 ('00001','00','0000000032','0000000031','folder','folder','css','0','','0','','0000000032_00001_00','0','0','admin','1443057535','admin','1443057535'),
 ('00001','00','0000000033','0000000032','file','leaf','default.css','1841','1.8KB','0','','0000000033_00001_00','0','0','admin','1443057535','admin','1443057535'),
 ('00001','00','0000000034','0000000031','folder','folder','styles','0','','0','','0000000034_00001_00','1','0','admin','1443057535','admin','1443057535'),
 ('00001','00','0000000035','0000000034','file','leaf','styles.js','3662','3.6KB','0','','0000000035_00001_00','0','0','admin','1443057535','admin','1443057535'),
 ('00001','00','0000000036','0000000031','folder','folder','templates','0','','0','','0000000036_00001_00','2','0','admin','1443057535','admin','1443057535'),
 ('00001','00','0000000037','0000000036','folder','folder','images','0','','0','','0000000037_00001_00','0','0','admin','1443057535','admin','1443057535'),
 ('00001','00','0000000038','0000000037','file','leaf','template1.gif','2181','2.2KB','7000','100x70','0000000038_00001_00','0','0','admin','1443057535','admin','1443057535'),
 ('00001','00','0000000039','0000000037','file','leaf','template2.gif','333','0.4KB','7000','100x70','0000000039_00001_00','1','0','admin','1443057535','admin','1443057535'),
 ('00001','00','0000000040','0000000037','file','leaf','template3.gif','2242','2.2KB','7000','100x70','0000000040_00001_00','2','0','admin','1443057535','admin','1443057535'),
 ('00001','00','0000000041','0000000036','file','leaf','default.js','602','0.6KB','0','','0000000041_00001_00','1','0','admin','1443057535','admin','1443057535');
/*!40000 ALTER TABLE `%PREFIX%resource_node` ENABLE KEYS */;


--
-- Definition of table `%PREFIX%session`
--

DROP TABLE IF EXISTS `%PREFIX%session`;
CREATE TABLE `%PREFIX%session` (
  `row_index` int(11) NOT NULL default '0',
  `col_index` int(11) NOT NULL default '0',
  `code` text,
  `session_number` text,
  `session_category` char(1) default NULL,
  `session_type` char(1) default NULL,
  `title` text,
  `subtitle` text,
  `speaker` text,
  `speaker_detail` text,
  `overview` text,
  `download_file` text,
  `download_file_status` char(1) default NULL,
  `translation` char(1) default NULL,
  `session1_reserve1` text,
  `session1_reserve2` text,
  `session1_reserve3` text,
  `title2` text,
  `subtitle2` text,
  `speaker2` text,
  `speaker_detail2` text,
  `overview2` text,
  `download_file2` text,
  `download_file2_status` char(1) default NULL,
  `translation2` char(1) default NULL,
  `session2_reserve1` text,
  `session2_reserve2` text,
  `session2_reserve3` text,
  `capacity` int(11) default NULL,
  `caution_capacity` int(11) default NULL,
  `session_status` char(1) default NULL,
  `session_count` char(1) default NULL,
  `session_option` text,
  `memo` text,
  `reserve1` text,
  `reserve2` text,
  `reserve3` text,
  PRIMARY KEY  (`row_index`,`col_index`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `%PREFIX%session`
--

/*!40000 ALTER TABLE `%PREFIX%session` DISABLE KEYS */;
INSERT INTO `%PREFIX%session` (`row_index`,`col_index`,`code`,`session_number`,`session_category`,`session_type`,`title`,`subtitle`,`speaker`,`speaker_detail`,`overview`,`download_file`,`download_file_status`,`translation`,`session1_reserve1`,`session1_reserve2`,`session1_reserve3`,`title2`,`subtitle2`,`speaker2`,`speaker_detail2`,`overview2`,`download_file2`,`download_file2_status`,`translation2`,`session2_reserve1`,`session2_reserve2`,`session2_reserve3`,`capacity`,`caution_capacity`,`session_status`,`session_count`,`session_option`,`memo`,`reserve1`,`reserve2`,`reserve3`) VALUES 
 ('1','1','K-1','','1','','<b>ご挨拶</b>','','株式会社テスト<br />\r\n綾小路 公磨','株式会社テスト<br />\r\nソリューション事業部<br />\r\n事業部長<br />\r\n綾小路 公磨','','','','0','','','','','','','','','','','0','','','','1000','80','1','1','','','','',''),
 ('2','1','K-2','','2','d','<b>激動する世界経済　日本企業はどう生き残るのか</b>','<b>～現場取材から紐解く、勝ち残る会社の条件～</b>','経済ジャーナリスト<img alt=\"\" src=\"files/image/takarabe.jpg\" style=\"margin-top: -100px; float: right;\" /><br />\r\n財部 誠一 様','経済ジャーナリスト<br />\r\n財部 誠一 様<br />\r\n<br />\r\n■ プロフィール<br />\r\n慶應義塾大学法学部卒業後、野村證券に入社。同社退社後、3年間の出版社勤務を経てフリーランスジャーナリストに。国内外の企業取材に定評があり、大企業 だけでなく中小企業も積極的に取材している。中国、インド、ASEANなど新興国事情にも詳しい。BSイレブンの対談番組「財部誠一の経済深々」、テレビ 朝日「報道ステーション」、テレビ東京「未来世紀ジパング」、などTVやラジオでも広く活躍中。また、政策シンクタンク「ハーベイロード・ジャパン」を主 宰し、取材レポート「ハーベイロード・ウィークリー」では、取材したばかりのレポートを提供、多くの経営者やビジネスマンに好評を得ている。オフィシャル サイトでは「経営者の輪」、「借金時計」などを展開中。<br />\r\n■ 主な著書<br />\r\n最新著書： 『シェール革命 ～繁栄する企業 消える産業～』（実業之日本社）『ローソンの告白』（PHP研究所）／『メイド・イン・ジャパン消滅！～世界で戦える「製造業」をどう守るか～』（朝日新 聞出版）／『日本経済 起死回生のストーリー』（PHPビジネス新書）／『パナソニックはサムスンに勝てるか』（PHP研究所）／『アジアビジネスで成功する25の視点』 （PHPビジネス新書） 他多数。<br />\r\n■ 連載<br />\r\n・ 日経BPnet「財部誠一ビジネス立体思考」（日経BP社）<br />\r\n・ ダイヤモンド・オンライン「財部誠一の現代日本私観」','アベノミクスによる景気の好転により、日本の製造業にも復活の兆しが見え始めています。こうした成長への軌跡を一過性のものにしないためにも、激動する世 界経済の動向を正しく把握し、早急かつ確実にグローバルレベルでの開発設計・製造生産の連携体制の構築、コスト削減による競争力向上への対応、技術漏洩の 防止といった課題に取り組むことも重要になっています。<br />\r\n世界では今、何が起きているのか。経済ジャーナリストの視点で分析し、日本製造業の勝ち残る条件について解説します。','','','0','','','','','','','','','','','0','','','','0','0','1','2','','','','',''),
 ('3','1','K-3','','2','e','<b>カツオとサバ</b>','～本当に美味いのはどっちだ～','カツオ人間<img alt=\"\" src=\"files/image/katsuo1.jpg\" style=\"width: 178px; height: 124px; float: right; margin-top: -50px; float: right;\" />','カツオ人間','','/DL/Test_K-3_1bitspace.pdf','','1','','','','<b>やっぱりサバが好き</b>','～美味しい鯖の食べ方～','鯖川 サバ尾','鯖川 サバ尾','','','','2','','','','0','0','1','2','','','','',''),
 ('5','1','L-1','','3','','<b>アイシン精機がヴィッツに出資、車載ソフトウェアの複雑化やISO26262に対応</b>','','アイティメディア株式会社','<div>\r\n	<img alt=\"\" src=\"files/image/test_01.gif\" style=\"width: 251px; height: 188px; float: left;\" />アイティメディア株式会社<br />\r\n	車載ソフトウェア<br />\r\n	ダミー記者 田中 太郎 様\r\n</div>\r\n','アイシン精機は2014年8月29日、組み込みソフトウェアの開発用ツールや受託開発を手掛けるヴィッツが実施する第三者割当増資を引き受けることで合意し、同社株式の10.7％を取得したと発表した。<br />\r\n急速な自動車の電子化による車載システムの制御開発が複雑化や車載ソフトウェアの大規模化が進む中で、機能安全やセキュリティに関わる技術開発の重要性が増している。アイシン精機は、システム／メカ／ソフトウェア一体での商品企画と開発を加速し、機能安全設計の体制強化と開発効率の向上を図るため、自動車の機能安全規格であるISO 26262に準拠する車載ソフトウェア開発・・・・・<br />\r\n<br />\r\n出展元：MONOist http://monoist.atmarkit.co.jp/mn/articles/1409/01/news099.html','','','0','','','','','','','','','','','0','','','','200','80','1','1','','','','',''),
 ('5','2','L-2','','3','','<b>場を作る“プレイヤー“になろう。</b>','～プレイヤーになるには？～','Meets Regional','Meets Regional<br />\r\n編集室<br />\r\n副編集長　藤本 和剛 様','船場商人の家系に生まれ、道楽もんだった祖父の街遊び一般を、幼少期より体験してきたことが私の骨肉。長じてMeetsに籍を置いたのは今思えば自然な成り行きと思えますが、先達が作ってきた&ldquo;街的&rdquo;なる考え方を進化発展させるべく、日々の記事作成に努めています。<br />\r\n&ldquo;街的&rdquo;というのは、「都会を使いこなす」「田舎へ帰ろう」といった二項対置ではなく、日本全国ひいては世界どこに行っても、そこにしかない面白さを見つけられる・・・<br />\r\n<br />\r\n出展元：Adver Times http://www.advertimes.com/20140812/article167312/','','','1','','','','<B>場を作る“プレイヤー“になろう。</b>','～プレイヤーになるには？～','Meets Regional','','','/DL/Test_L-2_1bit#sharp.pdf','','2','','','','200','80','1','1','','','','',''),
 ('7','1','A-1','','4','a','次のシリコンバレーはアイオワ州に？IT企業が熱視線の理由は','','CNN.co.jp','CNN.co.jp<br />\r\nダミー記者&nbsp;うんちく 四朗 様<br />\r\n<br />\r\n欧州連合（ＥＵ）は23日から24日未明にかけて開いた首脳会議で、2030年までに温暖化ガス排出量を1990年比で40％削減する目標で合意した。他の主要国に先駆けて20年以降の積極的な目標を掲げることで国際的な議論をリードする狙いがある。日本も24日午後に30年までの削減目標を話し合う環境省と経済産業省による有識者会議の初会合を開いた・・・','出展元：<a href=\"http://www.cnn.co.jp/business/35053906.html?tag=cbox;business\">http://www.cnn.co.jp/business/35053906.html?tag=cbox;business</a>','','','1','','','','','','','','','','','0','','','','100','80','1','2','','','','',''),
 ('9','1','A-2','','4','a','未来を見るソニーの頭脳','～基礎研究は誰のためにあるべきか～　<span style=\"color:#0000FF;\"><span style=\"font-size:11px;\">※サブタイトルはオプションです</span>','日経ビジネス','日経ビジネス<br />\r\nニューヨーク支局長<br />\r\n細田 孝宏 様','コンピューターサイエンスを対象とするソニーの基礎研究所として1988年に設立され、現在は様々なテーマの研究者約30人が在籍するソニーコンピュータサイエンス研究所（ソニーCSL）。9月にニューヨークでイベントを開くなど、海外でのネットワーク拡大に力を入れ始めている。ソニー本体が業績不振に苦しむ中、何を目指すのか。創設者である所眞理雄・ファウンダーと、現在、研究所を率いる北野宏明・社長兼所長の2人に聞いた。<br />\r\n<br />\r\n出展元：http://business.nikkeibp.co.jp/article/interview/20141031/273251/?n_cid=nbpnbo_bv_ru','','','2','','','','未来を見るソニーの頭脳','～基礎研究は誰のためにあるべきか～','日経ビジネス','日経ビジネス<br />\r\nニューヨーク支局長<br />\r\n細田 孝宏 様','コンピューターサイエンスを対象とするソニーの基礎研究所として1988年に設立され、現在は様々なテーマの研究者約30人が在籍するソニーコンピュータ サイエンス研究所（ソニーCSL）。9月にニューヨークでイベントを開くなど、海外でのネットワーク拡大に力を入れ始めている。ソニー本体が業績不振に苦 しむ中、何を目指すのか。創設者である所眞理雄・ファウンダーと、現在、研究所を率いる北野宏明・社長兼所長の2人に聞いた。','','','2','','','','100','80','1','1','','','','',''),
 ('11','1','A-3','','4','b','<b>「黒霧島」で焼酎メーカートップに</b>','','Web R25','Web R25<br />\r\n記者 石原・だれやめ・たきび 様','「これだッ!」。霧島酒造の専務・江夏拓三は閃いた。車を運転中、トンネルに入った瞬間、カーナビの画面が白から黒に変わったのだ。既存の看板商品「霧島」のラベルは白。その時、江夏は開発中の新商品のラベルを黒に変えようと決めた。<br />\r\n「頭打ちだった状況を打破するためには、誰も見たことがない商品を造らないとと思っていたんです。当時、食品業界で黒いラベルはタブーでした。周囲には反対の声もありました・・・<br />\r\n<br />\r\n出展元：http://r25.yahoo.co.jp/fushigi/wxr_detail/?id=20141106-00038720-r25','','','1','','','','','','','','','','','0','','','','100','80','1','1','','','','',''),
 ('13','1','A-4','','4','b','<b>ユニークな機内安全ビデオを制作するニュージーランド航空、新作も人気</b>','','宣伝会議','宣伝会議<br />\r\nAdverTimes ブレーン 編集部<br />\r\nダミー記者 伊藤 はな 様','ニュージーランド航空は10月24日、映画「ホビット」シリーズをモチーフにした機内安全ビデオ「壮大すぎる機内安全ビデオ」の日本語版を公開した。映画に出演している俳優やニュージーランド観光大使である元プロ野球選手の清水直行さんが出演し、映画の世界観で搭乗時の注意事項や非常時の対処方法を伝えている。<br />\r\n<br />\r\n出展元：http://www.advertimes.com/20141104/article174185/','','','1','','','','','','','','','','','0','','','','100','80','1','1','','','','',''),
 ('15','1','A-5','','4','a','<b>Nishorgo Oirabot Nature Interpretation Centre</b>','～バングラデシュの自然保護地域建築計画～\r\n<span style=\"color:#0000FF;\"><span style=\"font-size:11px;\">※サブタイトルはオプションです</span>','JDN Inc.','JDN Inc.<br />\r\n青年海外協力隊 平成24年度4次隊 住宅・公共事業省建築局<br />\r\n建築 河野 洋一郎 様','バングラデシュ南東部に位置し、ミャンマーとの国境に接するコックスバザール県テクナフという地域に、イスラム社会に対し優れた功績を残した建築計画に授与される「Aga Khan Award for Architecture（アガ・カーン建築賞）」にノミネートされた「Nishorgo Oirabot Nature Interpretation Centre」（Nishorgoはベンガル語で自然、Oirabotは象）があります。惜しくも本賞の受賞は逃しましたが、優れた環境計画が評価されたことは誇るべきことです。<br />\r\n<br />\r\n出展元：http://www.japandesign.ne.jp/report/140723_bangladesh.html','','','1','','','','','','','','','','','0','','','','100','80','1','1','','','','',''),
 ('17','1','A-6','','4','a','<b>動画広告市場、2017年に880億円に到達—サイバーエージェントが予測</b>','','宣伝会議','宣伝会議<br />\r\n編集部<br />\r\nダミー記者 鈴木 三朗 様','サイバーエージェントは21日、シード・プランニングと共同で行った国内動画広告の市場動向に関する調査結果を発表した。インターネットを通して配信される動画広告の年間広告出稿額を推計し、市場規模予測を算出したもの。<br />\r\n調査では、2014年の市場規模311億円（前年対比197%）が、2017年に880億円に達すると予想している。拡大を続けるスマートフォン向けの広告は全体の約52％を占めるようになり、2013年の約5.6倍となる見込み。現在もスマートフォンに特化した広告商品の開発が進み、ゲームアプリを提供する広告主企業が出稿し始めており、今後もそうした流れが加速していくとしている・・・<br />\r\n<br />\r\n出展元：Adver Times　<a href=\"http://www.advertimes.com/20141023/article173412/\" target=\"_blank\">http://www.advertimes.com/20141023/article173412/</a>','/DL/Test_A-6_1bit_&and.pdf','','1','','','','','','','','','','','0','','','','100','80','1','1','','','','',''),
 ('7','2','B-1','','4','a','<b>EU、温暖化ガス30年までに４割削減　首脳会議で合意</b>','','日本経済新聞社','日本経済新聞社<br />\r\nダミー記者 山田 四朗 様','欧州連合（ＥＵ）は23日から24日未明にかけて開いた首脳会議で、2030年までに温暖化ガス排出量を1990年比で40％削減する目標で合意した。他の主要国に先駆けて20年以降の積極的な目標を掲げることで国際的な議論をリードする狙いがある。日本も24日午後に30年までの削減目標を話し合う環境省と経済産業省による有識者会議の初会合を開いた・・・<br />\r\n<br />\r\n出展元：日本経済新聞 Web刊 http://www.nikkei.com/article/DGXLASGM24H10_U4A021C1MM0000/?dg=1','','','0','','','','','','','','','','','0','','','','100','0','1','1','','','','',''),
 ('9','2','B-2','','4','c','<b>グーグルグラス依存症の米男性を治療、1日18時間使用も</b>','','CNN.co.jp','CNN.co.jp<br />\r\nダミー記者 山田 桃子 様','米グーグルの眼鏡型端末「グーグルグラス」を使い続けて依存症になり、米海軍の薬物依存症治療施設で治療を受けたという男性の症例について、サンディエゴの医師団が論文を公開した。<br />\r\n医師団によると、治療を受けたのは３１歳の男性。アルコール依存症の治療のため同施設に入院したところ、「グーグルグラスを使えないことに対して極度の苛立ちや興奮状態を示した」。男性には薬物乱用やうつ、強迫神経症などの病歴があった。<br />\r\n男性は２０１３年９月に同施設に入所するまでの２カ月間、１日に最大で１８時間もグーグルグラスをかけていた。職場にもかけたまま出勤し、その方が人との付き合いに自信が持てると告白。グラスが使えないと極端に苛立って怒りっぽくなったといい、外すのは就寝時と入浴時のみ・・・<br />\r\n<br />\r\n出展元：http://www.cnn.co.jp/tech/35055245.html?tag=mcol;relStories','','','0','','','','','','','','','','','0','','','','100','0','1','1','','','','',''),
 ('11','2','B-3','','4','b','<b>IoTの勝負は「人づくり」</b>','～技術でもモノ作りでもない本当の急所～<br />\r\n<span style=\"color:#0000FF;\"><span style=\"font-size:11px;\">※サブタイトルはオプションです</span>','日経ビジネス','<span style=\"color:#A52A2A;\">日経ビジネス<br />\r\n	記者 田中 深一郎 様</span>','10月中旬、米国シカゴで、Internet of Things（IoT、モノのインターネット）をテーマにした世界フォーラムが開かれた。<br />\r\nIoTについて、米ゴールドマン・サックスはパソコン、モバイルに続く「インターネット第3の波」と表現し、米マッキンゼー・アンド・カンパニーは2025年までに年間の経済効果が約3兆～6兆ドル（約300兆～600兆円）に達すると試算する。いわゆる&ldquo;Next Big Thing&rdquo;の候補として、IoTは事実上、業界のコンセンサスになっているトレンドだ。<br />\r\n一方、米ガートナーが発表する「ハイプ・サイクル」によれば、IoTは2014年に「過剰期待（Peak of Inflated Expectations）」の絶頂期を迎え、・・・<br />\r\n<br />\r\n出展元：http://business.nikkeibp.co.jp/article/opinion/20141104/273365/?n_cid=nbpnbo_bv_rd','','','0','','','','','','','','','','','0','','','','100','0','1','1','','','','',''),
 ('13','2','B-4','','4','a','<b>計8700個のLEDで「アナ雪」の魔法再現 ルミネ3館で下旬から</b>','','宣伝会議','宣伝会議<br />\r\nAdverTimes 販促会議 編集部<br />\r\nダミー記者 小林 一郎 様','<img alt=\"\" src=\"files/image/b-4.jpg\" style=\"height: 150px; width: 200px; float: right; margin: 0px 0px 0px 10px;\" />ルミネは11日、映画『アナと雪の女王』をテーマとしたクリスマスキャンペーンを開始する。新宿・有楽町・横浜の3館では今月下旬から、主要キャラクター・エルサが使う氷の魔法をイメージしたイルミネーションを展開。また、ルミネ ザ・キッチン品川を除く全館で、館内の装飾などにまぎれ込んだ雪だるま「オラフ」を見つけて写真をTwitterに投稿すると、抽選で賞品をプレゼントするキャンペーンも実施する。<br />\r\n3館合計で約8700個のLEDを用いるイルミネーションは、来館者の動きに反応し、・・・<br />\r\n<br />\r\n出展元：http://www.advertimes.com/20141107/article174474/','','','0','','','','','','','','','','','0','','','','100','80','1','1','','','','',''),
 ('15','2','B-5','','4','c','<B>人の幸福を考える人がいる限り、広告の価値はベーシックな面で高くなる</b>','','宣伝会議','宣伝会議<br />\r\n宣伝会議 編集部<br />\r\nダミー記者 加藤 二郎 様','今年4月に開催したイベント「AdverTimes DAYS」で実現したパネルディスカッション「広告界『G8』&mdash;&mdash;箭内道彦と大御所クリエイターが語りつくす！」。全日本シーエム放送連盟（ACC）の会報誌『ACCtion!』の人気連載『広告ロックンローラーズ』がきっかけで企画され、会場には多くの広告関係者が詰めかけた。<br />\r\n秋山晶、大島征夫、小田桐昭、葛西薫、坂田耕、副田高行、細谷巖、宮田識&mdash;&mdash;広告界の大全盛期を牽引し、いまも第一線を走り続ける錚々たる面々が集結。60歳、70歳を超えてもなお高みを目指し、自らに課題を課し続ける8人の、作り手としての誇り高き心。その核心に迫る、またとない&ldquo;幻のセッション&rdquo;となった。<br />\r\n<br />\r\n出展元：http://www.advertimes.com/20141104/article174053/','/DL/Test_B-5_2bit_slash.pdf','','0','','','','','','','','','','','0','','','','100','80','1','1','','','','',''),
 ('17','2','B-6','','4','b','<b>漫画家による仏の世界</b>','','ファッションプレス','ファッションプレス<br />\r\nダミー記者 佐々木 四朗 様','レレレのおじさんが千手観音に！両国・回向院で「漫画家による仏の世界展」ゴルゴ13も登場<br />\r\n<br />\r\n本の漫画家が独自のタッチで「仏」を描く、「第4回 漫画家による仏の世界展」が、東京 両国 回向院 本堂2Fホールにて開催される。期間は2014年11月8日(土)から11月24日(月)まで。京都・東寺、東京・増上寺、千葉・梅屋旅館に続いて4回目の開催となる。<br />\r\n<br />\r\n出展元：http://www.fashion-press.net/news/9986','','','0','','','','','','','','','','','0','','','','100','80','1','1','','','','',''),
 ('7','3','C-1','','4','a','<b>ベトナムでAndroidエンジニアを育成、OESFとAITI Educationが共同で</b>','','ITmedia','ITmedia<br />\r\n組み込み開発<br />\r\nダミー記者 佐藤 次郎 様','組み込み分野におけるAndroidの普及・促進を目指す一般社団法人「Open Embedded Software Foundation（以下、OESF）」は2014年4月25日、ベトナム・ハノイ市に拠点を置くAITI Education（以下、AITI）と提携し、ベトナムにおけるAndroid技術者教育を共同で進める方針を明らかにした。<br />\r\nOESFは同年1月、世界各国の企業・団体との提携関係をベースに、世界的なAndroid技術者教育を推進する「OESF Education Consortium」を設立。AITIは同年4月15日に・・・<br />\r\n<br />\r\n出展元：MONOist http://monoist.atmarkit.co.jp/mn/articles/1404/28/news100.html','','','0','','','','','','','','','','','0','','','','100','80','1','1','','','','',''),
 ('9','3','C-2','','4','c','<b>禅の心でアプリ開発　ITエンジニアの「いざ鎌倉」</b>','','日本経済新聞社','日本経済新聞社<br />\r\n映像報道部<br />\r\nダミー記者 杉本 晶子 様','10月中旬の三連休。古都・鎌倉の建長寺に早朝から、行楽客とは違ったいでたちの一団が集まった。プログラマーやウェブデザイナーなど、ＩＴ（情報技術）業界で腕に覚えのある面々だ。１泊２日で寺に泊まり込み、ある使命を果たすという。それは、禅の精神を味わいながら、共通の「お題」をチーム対抗方式で解くこと。創建から700年を超える禅寺と、時代のフロンティアに生きる開発者集団との異色のコラボから生まれたものとは・・・<br />\r\n<br />\r\n出展元：日本経済新聞 Web刊 http://www.nikkei.com/article/DGXMZO78771160T21C14A0000000/','','','0','','','','','','','','','','','0','','','','100','80','1','1','','','','',''),
 ('11','3','C-3','','4','a','<b>113歳女性、フェイスブック楽しむ　誕生年選べず「詐称」</b>','','CNN.co.jp','CNN.co.jp<br />\r\nダミー記者 田中 うめ 様','米ミネソタ州に住む１１３歳の女性が米フェイスブックに登録してデジタルライフを楽しんでいる。自分の誕生年が選択肢になかったため、登録の際は「年齢詐称」したという。<br />\r\nこの女性はミネソタ州の高齢者施設に暮らすアナ・ステアさん。新しいことを覚えるのが大好きで、友人に教えてもらってフェイスブックにユーザー登録しようとした。ところが登録ページで選択できる誕生年は１９０５年まで。そこで９９歳ということにした。ステアさんはＣＮＮ系列局ＫＡＲＥ－ＴＶの取材に「そういうこと」と応じている。<br />\r\n電話も車も電気も普及していなかった時代に生まれたステアさん。インターネットに興味を持ったのは、電話会社ベライゾンの営業担当者ジョセフ・ラミレサさんと知り合ったことがきっかけ・・・<br />\r\n<br />\r\n出展元：http://www.cnn.co.jp/tech/35055149.html?tag=mcol;relStories','','','0','','','','','','','','','','','0','','','','100','80','1','1','','','','',''),
 ('13','3','C-4','','4','b','<b>資源機構、米エネルギー省と砂層型メタンハイドレートの陸上産出で覚書</b>','','日刊工業新聞社','日刊工業新聞社<br />\r\n素材・エネルギー グループ<br />\r\nダミー記者 山田 五郎 様','石油天然ガス・金属鉱物資源機構（JOGMEC）と米エネルギー省国立エネルギー技術研究所は6日、砂層型メタンハイドレートの陸上産出に関する共同研究で覚書を交わしたと発表した。米アラスカ州で５年以内の採掘を目指す。JOGMECでは砂層型メタンハイドレート採掘の知見を蓄え、日本近海での砂層型メタンハイドレートの開発に生かす考えだ。<br />\r\n海底下の深い地層に砂と混じり合って存在するメタンハイドレートを減圧して分解、ガス状にして回収する。<br />\r\n<br />\r\n出展元：http://www.nikkan.co.jp/news/nkx0820141107abat.html','/DL/Test_C-4_1bitspace.pdf','','0','','','','','','','','','','','0','','','','100','80','1','1','','','','',''),
 ('15','3','C-5','','4','a','<b>植物工場で展開、藻類・ユーグレナビジネス</b>','','NPO法人イノプレックス','NPO法人イノプレックス<br />\r\n代表理事 藤本 真狩 様','植物工場とは温湿度や光源など様々な項目を高度に環境制御することで、安定的に周年栽培できるシステムのことを一般的に示すが、生産物は野菜に限らず、広義にとらえれば微細藻類を植物工場にて生産することも可能である。<br />\r\n近年、藻類関連のニュースが取りあげられる機会も多い。例えば、藻類の一つであるミドリムシの学名を社名にしたユーグレナ社が、いすゞ自動車と共同で、ミドリムシから抽出した油をバイオ燃料として使用し、・・・<br />\r\n<br />\r\n出展元：http://www.kankyo-business.jp/column/009023.php','','','0','','','','','','','','','','','0','','','','100','80','1','1','','','','',''),
 ('17','3','C-6','','4','a','<b>残業、満員電車…ネガティブなシーンを一言でポジティブに！</b>','','宣伝会議','宣伝会議<br />\r\n第52回宣伝会議賞 事務局<br />\r\nダミー記者 吉田 三朗 様','第52回宣伝会議賞は、サイバーエージェントが運営するコミュニティサービス「アメーバ大喜利」との共同キャンペーン「ボケで日本を明るく大賞～コピーのチカラで世の中をもっと面白く～」を10月10～23日の期間限定で実施した。<br />\r\n「アメーバ大喜利」は、提示されたお題に対してユーザーが&ldquo;ボケる&rdquo;投稿をして楽しむというユーザー参加型サービス。投稿するだけでなく、他のユーザーの投稿の中で気に入ったものがあれば、「座布団」というボタンで投票することもできる。<br />\r\n<br />\r\n出展元：http://www.advertimes.com/20141104/article174042/','','','0','','','','','','','','','','','0','','','','100','80','1','1','','','','',''),
 ('7','4','D-1','','4','b','<b>サウンド・プラネタリウム 2014</b>','','ファッションプレス','ファッションプレス<br />\r\nダミー記者 小林 華子 様','2014年11月7日(金)から12月25日(木)まで、「サウンド・プラネタリウム 2014」が東京・銀座ソニービルで開催される。<br />\r\n本イベントでは、プラネタリウム・クリエーターの大平貴之が開発した、普段肉眼で見ることのできない1000万個の星を映し出すことのできる光学式プラネタリウム投影機「MEGASTAR-II」を使用し、無数の星々が煌めく宇宙の世界を再現する。<br />\r\n<br />\r\n出展元：http://www.fashion-press.net/news/13420','','','0','','','','<b>映画のストーリーの世界観を再現</b>','','オリコム','オリコム<br />\r\nデジタルサイネージコンソーシアム理事　吉田 勝広 様','<div>\r\n	東宝は、2015年1月9日から上映されたアニメ映画『劇場版PSYCHO-PASSサイコパス』のプロモーションでOOHメディアを使用した。注目は、丸ノ内線新宿駅で一週間実施した展開だ。高さ約2メートル、左右約15メートルの大型ボードに、デジタルサイネージ4台をマルチ画面にして3カ所に設置。映画のストーリーの中心にある世界観を見事に表現した。\r\n</div>\r\n\r\n<div 0px=\"\" padding:15px=\"\">\r\n	この映画にある近未来の日本では、人間のあらゆる感情や社会病質的心理傾向は、「シビュラシステム」と呼ぶものによって計測され、管理されている。その値が「サイコパス（係数）」だ。犯罪を犯す可能性が高い者は数値が高く表示され、係数が一定値を超えると、治安維持にあたる主人公の公安局刑事たちが裁くというものだ。ここでは、このシステムを再現。鏡のように目の前が映るサイネージ画面に通行者が立つと、\r\n</div>\r\n','','','0','','','','100','80','1','1','','','','',''),
 ('9','4','D-2','','4','c','<b>本屋ですが、ベストセラーはおいてません。</b>','','スタンダードブックストア','スタンダードブックストア<br />\r\n代表取締役 中川 和彦 様','本と雑貨を販売していて、併設のカフェには購入前の本を持ち込んで検討することができ、そのカフェではトークショーやワークショップなどのイベントも開催する店。カフェメニューは真っ当な食を心がけ、できる範囲で添加物や化学調味料を使わず提供するようにしている。私が経営するスタンダードブックストアを説明するとそんなところか。<br />\r\n自分たちが行きたくなるような店をやりたいと思って始めたので、基本的に自分たちがいいと思った商品を自分たちがいいと思ったように分類して陳列し、・・・<br />\r\n<br />\r\n出展元：Adver Times http://www.advertimes.com/20141021/article172704/','','','0','','','','','','','','','','','0','','','','100','80','1','1','','','','',''),
 ('11','4','D-3','','4','a','<b>カバの赤ちゃん誕生、動物園びっくり ロサンゼルス</b>','','CNN.co.jp','CNN.co.jp<br />\r\nダミー記者 河馬 赤太郎 様','米ロサンゼルスの動物園で、避妊していたはずのカバが赤ちゃんを出産し、関係者を驚かせている。赤ちゃんはプールの中で母カバと一緒に元気な姿を見せている。<br />\r\n１０歳の母カバ「マラ」の体重が最近になって増えたことには飼育係なども気づいていた。妊娠した可能性もあるとみていたが、検査する手段がほとんどなかったという。<br />\r\nマラは１０月３１日に屋外のプールで産気づき、陸に上がって出産した。係員が近くで見守り、すべて順調だったという。<br />\r\nロサンゼルス動物園でカバの赤ちゃんが生まれたのは２６年ぶり。まだ係員が近付けないため性別は分からず、名前も決まっていない。<br />\r\n<br />\r\n出展元：http://www.cnn.co.jp/fringe/35056100.html?tag=top;topStories','/DL/Test_D-3_1bit_(kakko).pdf','','0','','','','','','','','','','','0','','','','100','80','1','1','','','','',''),
 ('13','4','D-4','','4','a','<b>Champions League: Lionel Messi scores twice to equal record</b>','','BBC Sport','BBC Sport<br />\r\nダミー記者 Mr. Jacob Smith','Lionel Messi drew level with Raul&#39;s all-time Champions League record of 71 goals after scoring twice in Barcelona&#39;s 2-0 victory against Ajax.<br />\r\nArgentina international Messi scored in the 36th minute with a soft header after Ajax failed to clear a free kick. His 71st goal in the competition came after he linked with substitute Pedro in the 76th minute as Barcelona qualified for the last 16.<br />\r\nBayern Munich, Paris St-Germain and Porto join Barca in the next round.<br />\r\n<br />\r\n出展元：http://www.bbc.com/sport/0/football/29925468','','','0','','','','','','','','','','','0','','','','100','80','1','1','','','','',''),
 ('15','4','D-5','','4','a','<b>運動管理もできるスマートウォッチ</b>','','Web R25','Web R25<br />\r\n記者 のび＠びた 様','今注目の最新デジタルガジェットといえばスマホとリンクさせてつかうタイプの腕時計「スマートウォッチ」。各メーカーが様々なタイプのものを発表し、話題となっています。この『ZeWatch2』もそんなスマートウォッチのひとつ。主に電話の応答と、活動量の計測に役立つアイテムです。<br />\r\n着信があればZeWatch2が知らせてくれるので、スマホをカバンにしまっておいたため着信に気づかない、なんてことがなくなります。<br />\r\n<br />\r\n出展元：http://r25.yahoo.co.jp/fushigi/wxr_detail/?id=20141107-00038917-r25','','','0','','','','','','','','','','','0','','','','100','80','1','1','','','','',''),
 ('17','4','D-6','','4','a','<b>植物工場ビジネスの将来性</b>','','NPO法人イノプレックス','NPO法人イノプレックス<br />\r\n代表理事 藤本 真狩 様','複数回にわたって国内外における植物工場事例についてご紹介してきたが、最後に世界市場における日本が保有する技術優位性と植物工場ビジネスの将来性について整理したい。<br />\r\n高度な環境制御と周年栽培を実現する植物工場施設の面積は世界全体でみても非常に小さいものである。太陽光利用型ではトップリーダーであるオランダでは施設園芸の80％以上が植物工場に分類できるほど、ハイテクな施設が普及している一方で、日本の場合は・・・<br />\r\n<br />\r\n出展元：http://www.kankyo-business.jp/column/006021.php','','','0','','','','','','','','','','','0','','','','100','80','1','1','','','','',''),
 ('7','5','E-1','','4','b','<b>もしもの時のデザイン「災害時に役に立つ物や心のデザイン」</b>','','JDN Inc.','JDN Inc.<br />\r\nWorld Report Section<br />\r\nダミー記者 Mr. Jack Williams','日本に住む以上は、地震、噴火、津波、台風といった自然災害とは付き合っていかざるを得ない。そうした災害で日常が断絶されたもしもの時に、パッケージデザインは人々のために役に立つことができるだろうか。<br />\r\n現在、印刷博物館にて『もしもの時のデザイン「災害時に役に立つ物や心のデザイン」展』が開催されている。この展覧会は、ほんの些細な&ldquo;もしも&rdquo;から命にかかわる&ldquo;もしも&rdquo;まで、災害時の様々な&ldquo;もしもの時&rdquo;を解決するデザインを日本パッケージデザイン協会（JPDA）の会員を中心にデザイナー100人が提案しているものだ。<br />\r\n<br />\r\n出展元：http://event.japandesign.ne.jp/2014/08/5929/','','','0','','','','','','','','','','','0','','','','100','1','1','1','','','','',''),
 ('9','5','E-2','','4','a','<b>ねつ造されるから強靱な「民族の伝統」</b>','','日経ビジネス','日経ビジネス<br />\r\n吉田 徹 様','スコットランドに行って、例えば古都エディンバラのオールドタウンを歩けば、タータンチェックのスカートを履き、バグパイプを吹く観光客向けのアトラクションに必ず出くわすはずだ。そして、私たちはそこに「スコティッシュネス（スコットランドらしさ）」をみて、スコットランドに来たという安心と満足を得ることになる。<br />\r\nこのスコットランドがイギリス（正式には『グレートブリテン及び北アイルランド連合王国』）からの「独立」を求めた住民投票は、9月に55％で否決されるに至った。<br />\r\n本コラムで指摘されてきたように、スコットランドが住民投票に至ったのは複合的な要因が絡んだ結果だった。<br />\r\n<br />\r\n出展元：http://business.nikkeibp.co.jp/article/opinion/20141104/273381/?n_cid=nbpnbo_bv_ru','/DL/Test_E-2_1bit_kana_.pdf','','0','','','','','','','','','','','0','','','','100','1','1','1','','','','',''),
 ('11','5','E-3','','4','c','<b>コーヒーショップに「電気」を買いに行く未来</b>','','日経ビジネス','日経ビジネス<br />\r\n江村 英哲 様','2016年に迫る電力の小売り自由化。「日本でも電力をコーヒー店やコンビニで買う時代がすぐそこに到来している」とシーメンス・ジャパンでエネルギー関連事業のトップを務める藤田研一専務執行役員は語る。<br />\r\n<br />\r\n日本では2016年から電力小売市場の自由化が始まります。先行して全面自由化をしたドイツではどのような市場が形成されているのでしょうか。<br />\r\n<br />\r\n出展元：http://business.nikkeibp.co.jp/article/topics/20141030/273195/?ST=eco','','','0','','','','','','','','','','','0','','','','100','1','1','1','','','','',''),
 ('13','5','E-4','','4','a','<b>メトロ日比谷線が五輪前に変身</b>','','日本経済新聞','日本経済新聞<br />\r\n電子版<br />\r\nダミー記者 日比谷 六郎 様','東京北東部（北千住）と<span class=\"marker\">南西部</span> （中目黒）を結ぶ 地下鉄日比谷 線が、大きく変わろうとしている。2016年度からこれまでより２メートル長い新型車両を導入し、全駅にホームドアを設置。20年までには虎ノ門に新駅ができる。駅の改良工事なども行われる予定だ。全線が開通してから今年で50年。東京五輪とともに産声を上げた路線は、東京五輪を前に再び転機を迎えている。\r\n<div>\r\n	<br />\r\n	出展元：<a href=\"http://www.nikkei.com/article/DGXLASFK05H37_W4A101C1000000/?dg=1\" target=\"_blank\">http://www.nikkei.com/article/DGXLASFK05H37_W4A101C1000000/?dg=1</a>\r\n</div>\r\n\r\n<div>\r\n	&nbsp;\r\n</div>\r\n','','','0','','','','','','','','','','','0','','','','100','1','1','1','','','','',''),
 ('15','5','E-5','','4','a','<b>被災地の復興状況に「関心がある」67% - 意識は年々希薄傾向①</b>','','日本経済新聞','日本経済新聞<br />\r\n電子版<br />\r\nダミー記者 肌川 ときこ 様','調整中','','','0','','','','','','','','','','','0','','','','100','1','1','1','','','','',''),
 ('17','5','E-6','','4','c','<b>テニスボール2個の上に寝転がるだけ！　1日5分で腰痛解消、すっきり美尻・美脚効果も期待大</b>','','柔道整復師','柔道整復師<br />\r\n腰痛治療のゴッドハンド<br />\r\n神手 揉人&nbsp;様','用意するものは硬式テニスボール2個だけ！<br />\r\n「仙腸関節矯正法」は、2つくっつけたテニスボールの上で仰向けに寝るだけ。やり方は、\r\n<ul>\r\n	<li>\r\n		2個の硬式テニスボールを並べ、ガムテープなどでしっかり固定する\r\n	</li>\r\n	<li>\r\n		フローリングなど、硬い床の上で、くっつけたボールを仙腸関節部分に当てて仰向けに寝る\r\n	</li>\r\n	<li>\r\n		その姿勢を1～3分間キープする\r\n	</li>\r\n</ul>\r\nというもの。必ず硬い床の上で行うことがポイントです。','','','0','','','','','','','','','','','0','','','','100','1','1','1','','','','',''),
 ('7','6','F-1','','4','a','<b>2020東京招致成功から1年を振り返る</b>','～東京五輪・パラリンピックの準備は今<br />\r\n<span style=\"color:#0000FF;\"><span style=\"font-size:11px;\">※サブタイトルはオプションです</span>','東京2020オリンピック・パラリンピック招致委員会','オリンピック・パラリンピック招致委員会<br />\r\n委員長<br />\r\n東京 五輪&nbsp;様','','/DL/Test_F-1_1bit_+plus.pdf','','0','','','','','','','','','','','0','','','','2','80','1','1','','','','',''),
 ('9','6','F-2','','4','c','<b>「万年２位」東洋大が箱根駅伝で圧勝したワケ</b>','～あと１歩で勝てないチームが、なぜ“壁”を破れたか<br />\r\n<span style=\"color:#0000FF;\"><span style=\"font-size:11px;\">※サブタイトルはオプションです</span>','東洋大学','東洋大学<br />\r\n駅伝部<br />\r\n部長 山神 襷&nbsp;様','正月の箱根駅伝をＴＶで見た人も多いと思う。今年も平均視聴率で26.9％をマーク。同時間帯の中では断トツの数字をマークした。しかし、復路の視聴率は27.0％と、過去10年間で最低の数字になった。その最大の原因は、優勝した東洋大が強すぎたことだろう。<br />\r\n往路を２位の駒澤大と59秒差で折り返すと、６区以降はその差をグングンと拡大。８区終了時で３分40秒もの大差がついて、勝負の行方が見えてしまったのだ。視聴者のハラハラ感を削ぐかたちとなった東洋大だが、この２年間は苦難の連続だった。そこで、今回は&ldquo;箱根王座&rdquo;を奪還した東洋大から&ldquo;壁&rdquo;を突破する方法を学びたい。','','','0','','','','','','','','','','','0','','','','2','80','1','1','','','','',''),
 ('11','6','F-3','','4','c','<b>未だ負けなし無敗の世界チャンピオン達</b>','～ボクシング史上ただひとり全勝で5階級制覇を達成したスーパースター<br />\r\n<span style=\"color:#0000FF;\"><span style=\"font-size:11px;\">※サブタイトルはオプションです</span>','World Boxing Association','World Boxing Association<br />\r\n世界スーパーウェルター級<br />\r\nスーパー王者 フロイド・メイウェザー・ジュニア&nbsp;様','「史上最速のスピードスター」と評価されるほどの圧倒的なスピードと超人的な反応速度、卓越したディフェンステクニックで相手を翻弄する試合を得意とする。階級を上げてからパワーは目減りしたものの、寸分の狂いもないタイミングで打ち出すダイレクトブローと常人離れした高速コンビネーションを武器に芸術的なKOを演出する。プロでの戦績は全戦全勝、史上初めて全勝のまま5階級制覇を達成するなど、2008年に一旦引退するまでの間パウンド・フォー・パウンド最強のボクサーとして評価されていた。','','','0','','','','','','','','','','','0','','','','2','80','1','1','','','','',''),
 ('13','6','F-4','','4','a','<b>錦織圭に芽生えたトップとしての覚悟</b>','～全米後の“２週連続優勝”が持つ意義<br />\r\n<span style=\"color:#0000FF;\"><span style=\"font-size:11px;\">※サブタイトルはオプションです</span>','日比谷公園庭球場','日比谷公園庭球場<br />\r\n管理部<br />\r\n庭球 打子 様','「また一つ、壁を破れたという、うれしさがこみ上げた」<br />\r\n楽天ジャパンオープン優勝後に錦織が残したこの言葉は、さまざまな意味で含蓄に富み、同時に、理屈抜きで共感と感動を呼ぶものでもあった。<br />\r\n全米オープン準優勝という、日本に空前の&ldquo;ニシコリ・フィーバー&rdquo;をもたらした偉業の直後にＡＴＰツアー２大会連続優勝。しかも錦織は試合のみならず、コート外でも日本での会見やスポンサーのあいさつ回り、さらには香港でプロモーションイベント等をこなしてきたのだ。無数のカメラが向けられる中、人前で話し、サイン会等で多くのファンと触れあうことは、テニスとはまた異なる緊張感と疲労をアスリートに強いるだろう。それらの事情も鑑みたとき、彼が突き破った「壁」は、単にコート上に立ちはだかる障壁にとどまらない。','','','0','','','','','','','','','','','0','','','','2','80','1','1','','','','',''),
 ('15','6','F-5','','4','b','<b>ドラフト直前。スカウトは選手の「ココ」を見ている</b>','','日本野球機構','日本野球機構<br />\r\nコミッショナー 巨阪 広 様','ドラフトまであと１日と迫った。各球団とも指名選手の絞り込みに追われ、眠れぬ夜を過ごしているに違いない。春先には300人ほどいるドラフト候補を、半年後にはおよそ５分の１、そして最終的には10人前後まで絞り込む。その作業をするにあたって、大きく関わってくるのが、スカウトたちの&rdquo;目&rdquo;だ。投手なら、球が速い、変化球のキレがいい、野手なら、長打力がある、足が速い、守備うまい&hellip;&hellip;といった単純なものではない。','','','0','','','','','','','','','','','0','','','','2','80','1','1','','','','',''),
 ('17','6','F-6','','4','c','<b>新シーズンへ。羽生結弦が語ったソチ五輪後の「葛藤」</b>','','公益財団法人 日本スケート連盟','公益財団法人 日本スケート連盟<br />\r\n会長<br />\r\n氷上 滑男 様','２月のソチ五輪、男子フィギュアスケートで金メダルを獲得した羽生結弦（ゆづる）が、新たなシーズンに向けての準備を続けている。<br />\r\n羽生は昨シーズン、ＳＰ、フリーの両方で完璧な演技をそろえた試合がひとつもなかったことへの悔しさがある。それが、進化への強い気持ちにつながっているのだろう。今季の目標についてこう口にした。<br />\r\n「今シーズンはいろんな意味でスタートの年になると思います。五輪が終わって、冒険ができる年というとらえ方もあるけど、やはり僕自身は五輪チャンピオンになった今だからこそ、これからの成績や実力というのが、ものすごく試されるようになると思っています。五輪チャンピオンらしい結果と演技を、このシーズンでしっかり印象づけていかなければいけないと思います」<br />\r\nタイトルを独占しても、おごりは一切なし。挑戦者としての姿勢を持ち続けている羽生は、『ファンタジー・オン・アイス新潟』でも今シーズンのＳＰを披露した。アイスショーもプログラムを完成させるための貴重な一歩。ここから、シーズンインへ向けての本格的な準備が始まる。','','','0','','','','','','','','','','','0','','','','2','80','1','1','','','','',''),
 ('19','1','R-1','','5','','<b>懇親会</b>','','','','','','','0','','','','','','','','','','','0','','','','1000','80','1','1','','','','','');
/*!40000 ALTER TABLE `%PREFIX%session` ENABLE KEYS */;


--
-- Definition of table `%PREFIX%settings`
--

DROP TABLE IF EXISTS `%PREFIX%settings`;
CREATE TABLE `%PREFIX%settings` (
  `id` char(5) NOT NULL default '',
  `site_title` text,
  `admin_site_title` text,
  `memo` text,
  `reserve1` text,
  `reserve2` text,
  `reserve3` text,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `%PREFIX%settings`
--

/*!40000 ALTER TABLE `%PREFIX%settings` DISABLE KEYS */;
INSERT INTO `%PREFIX%settings` (`id`,`site_title`,`admin_site_title`,`memo`,`reserve1`,`reserve2`,`reserve3`) VALUES 
 ('00001','','B-studio Contents Management System','','','','');
/*!40000 ALTER TABLE `%PREFIX%settings` ENABLE KEYS */;


--
-- Definition of table `%PREFIX%template`
--

DROP TABLE IF EXISTS `%PREFIX%template`;
CREATE TABLE `%PREFIX%template` (
  `version_id` char(5) NOT NULL default '',
  `revision_id` char(2) NOT NULL default '',
  `contents_id` char(10) NOT NULL default '',
  `contents_date` char(10) default NULL,
  `template_id` char(10) default NULL,
  `start_html` mediumtext,
  `end_html` mediumtext,
  `css` mediumtext,
  `php` mediumtext,
  `external_css` text,
  `external_js` text,
  `header_element` text,
  `del_flag` char(1) default NULL,
  `reserve1` text,
  `reserve2` text,
  `reserve3` text,
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text,
  PRIMARY KEY  (`version_id`,`revision_id`,`contents_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `%PREFIX%template`
--

/*!40000 ALTER TABLE `%PREFIX%template` DISABLE KEYS */;
INSERT INTO `%PREFIX%template` (`version_id`,`revision_id`,`contents_id`,`contents_date`,`template_id`,`start_html`,`end_html`,`css`,`php`,`external_css`,`external_js`,`header_element`,`del_flag`,`reserve1`,`reserve2`,`reserve3`,`create_user`,`create_datetime`,`update_user`,`update_datetime`) VALUES 
 ('00001','00','0000000001','','','<body>\r\n	<div id=\"header-wrapper\">\r\n		<div id=\"header\">\r\n			<p id=\"logo\">\r\n				<a href=\".\" >LOGO HERE</a>\r\n			</p>\r\n	\r\n			<?php widget(\'0000000001\'); // navi ?>\r\n		</div>\r\n	</div>\r\n	\r\n	<div id=\"wrapper\">\r\n		<div id=\"contents\">\r\n','		</div>\r\n	</div>\r\n\r\n	<div id=\"footer-wrapper\">\r\n		<div id=\"footer\">\r\n			<?php widget(\'0000000004\'); // site_map ?>\r\n		</div>\r\n	\r\n		<p class=\"copyright\">\r\n			copyright &copy; <?php echo date(\'Y\', time()); ?> site-name all rights reserved\r\n		</p>\r\n	</div>\r\n</body>','@charset \'UTF-8\';\r\n\r\n/* clear fix */\r\n.clearfix:after {\r\n	content: \"\"; \r\n	display: block; \r\n	clear: both;\r\n}\r\n\r\nbody {\r\n	margin: 0;\r\n	padding: 0;\r\n	background-color: #fff;\r\n	color: #555;\r\n	font-family: \"メイリオ\", \"Meiryo\", \"ヒラギノ角ゴ Pro W3\", \"Hiragino Kaku Gothic Pro\", \"Osaka\", verdana, lucida, arial, helvetica, sans-serif;\r\n	font-size: 17px;\r\n}\r\nh1 {\r\n	margin: 22px 0;\r\n	font-size: 34px;\r\n}\r\nh2 {\r\n	margin: 20px 0;\r\n	font-size: 26px;\r\n}\r\nh3 {\r\n	margin: 0;\r\n	font-size: 17px;\r\n	font-weight: normal;\r\n}\r\na:link,\r\na:visited {\r\n	text-decoration: none;\r\n	color: #555;\r\n	outline: none;\r\n}\r\n#header-wrapper {\r\n	border-bottom: 1px solid #999;\r\n	overflow: hidden;\r\n}\r\n#header {\r\n	margin: 0 auto;\r\n	width: 1000px;\r\n}\r\n#logo {\r\n	float: left;\r\n	margin: 0;\r\n	padding: 18px 200px 12px 10px;\r\n	font-family: helvetica, sans-serif;\r\n	font-size: 20px;\r\n	font-weight: bold;\r\n}\r\n#wrapper {\r\n	width: 1000px;\r\n	margin: 0 auto;\r\n}\r\n#footer-wrapper {\r\n	background-color: #333;\r\n	color: #fff;\r\n}\r\n#footer {\r\n	width: 1000px;\r\n	margin: 0 auto;\r\n	padding: 10px 0;\r\n}\r\n#footer .sitemap {\r\n	margin: 0;\r\n	padding: 10px 0 0 0;\r\n	list-style: none;\r\n	height: 100px;\r\n	font-size: 13px;\r\n}\r\n#footer .sitemap li {\r\n	float: left;\r\n	margin-left: 35px;\r\n}\r\n#footer .sitemap li:first-child {\r\n	margin-left: 20px;\r\n}\r\n#footer-wrapper p.copyright {\r\n	margin: 0;\r\n	padding: 0 40px 15px 0;\r\n	text-align: right;\r\n	font-size: 12px;\r\n}','','','','','0','','','','admin','1392242646','admin','1411161856'),
 ('00001','00','0000000002','','','','','.contents-box {\r\n	margin: 20px 0 60px 0;\r\n	padding: 0 10px;\r\n	font-size: 16px;\r\n}\r\n.contents-box p {\r\n	margin: 6px 0;\r\n}\r\n.contents-box .overflow-none {\r\n	overflow: hidden;\r\n}\r\n.right {\r\n	float: right;\r\n	margin-left: 40px;\r\n}\r\n.left {\r\n	float: left;\r\n	margin-right: 40px;\r\n}\r\n.center {\r\n	text-align: center;\r\n	padding-bottom: 40px;\r\n}\r\n.more-info {\r\n	text-align: right;\r\n	font-weight: normal;\r\n	\r\n}\r\n.more-info {\r\n	margin: 20px 0;\r\n}\r\n.more-info a:link,\r\n.more-info a:visited {\r\n	color: #0088cc;\r\n	text-decoration: none;\r\n}\r\n.more-info a:hover {\r\n	text-decoration: underline;\r\n}\r\n.contents-box .shortcut-list {\r\n	text-align: left;\r\n	margin-left: 20px;\r\n	width: 100%;\r\n}\r\n.contents-box .shortcut-list th {\r\n	font-weight: normal;\r\n	width: 300px;\r\n}\r\n.contents-box .icon-list {\r\n	text-align: left;\r\n	margin: 8px 0 0 10px;\r\n	width: 100%;\r\n}\r\n.contents-box .icon-list th {\r\n	padding: 2px;\r\n	width: 40px;\r\n}\r\nspan.icon {\r\n	background-color: #3a3a3a;\r\n	padding: 2px 8px;\r\n}\r\nspan.icon img {\r\n	vertical-align: -4px;\r\n}\r\nspan.caution {\r\n	color: #d33;\r\n}\r\n','','','','','0','','','','admin','1392524260','admin','1392541259');
/*!40000 ALTER TABLE `%PREFIX%template` ENABLE KEYS */;


--
-- Definition of table `%PREFIX%template_node`
--

DROP TABLE IF EXISTS `%PREFIX%template_node`;
CREATE TABLE `%PREFIX%template_node` (
  `version_id` char(5) NOT NULL default '',
  `revision_id` char(2) NOT NULL default '',
  `node_id` char(10) NOT NULL default '',
  `parent_node` char(10) default NULL,
  `node_type` char(10) default NULL,
  `node_class` char(10) default NULL,
  `node_name` text,
  `contents_id` char(10) default NULL,
  `disp_seq` int(11) default NULL,
  `del_flag` char(1) default NULL,
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text,
  PRIMARY KEY  (`version_id`,`revision_id`,`node_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `%PREFIX%template_node`
--

/*!40000 ALTER TABLE `%PREFIX%template_node` DISABLE KEYS */;
INSERT INTO `%PREFIX%template_node` (`version_id`,`revision_id`,`node_id`,`parent_node`,`node_type`,`node_class`,`node_name`,`contents_id`,`disp_seq`,`del_flag`,`create_user`,`create_datetime`,`update_user`,`update_datetime`) VALUES 
 ('00001','00','0000000001','root','template','template','global','0000000001','0','0','admin','1392242544','admin','1392242548'),
 ('00001','00','0000000002','0000000001','template','template','function','0000000002','0','0','admin','1392443029','admin','1392524245'),
 ('00001','00','0000000003','0000000001','template','template','company','','1','0','admin','1392443048','admin','1392443056'),
 ('00001','00','0000000004','0000000001','template','template','products','','2','0','admin','1392443060','admin','1392443070');
/*!40000 ALTER TABLE `%PREFIX%template_node` ENABLE KEYS */;


--
-- Definition of table `%PREFIX%user`
--

DROP TABLE IF EXISTS `%PREFIX%user`;
CREATE TABLE `%PREFIX%user` (
  `id` char(10) NOT NULL default '',
  `user_id` char(10) default NULL,
  `pwd` char(20) default NULL,
  `user_status` text,
  `user_auth` text,
  `f_name` text,
  `g_name` text,
  `email` text,
  `memo` text,
  `del_flag` char(1) default NULL,
  `reserve1` text,
  `reserve2` text,
  `reserve3` text,
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `%PREFIX%user`
--

/*!40000 ALTER TABLE `%PREFIX%user` DISABLE KEYS */;
/*!40000 ALTER TABLE `%PREFIX%user` ENABLE KEYS */;


--
-- Definition of table `%PREFIX%version`
--

DROP TABLE IF EXISTS `%PREFIX%version`;
CREATE TABLE `%PREFIX%version` (
  `version_id` char(5) NOT NULL default '',
  `private_revision_id` char(2) default NULL,
  `publication_datetime_t` text,
  `publication_datetime_u` text,
  `publication_status` char(1) default NULL,
  `version` text,
  `memo` text,
  `del_flag` char(1) default NULL,
  `reserve1` text,
  `reserve2` text,
  `reserve3` text,
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text,
  PRIMARY KEY  (`version_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `%PREFIX%version`
--

/*!40000 ALTER TABLE `%PREFIX%version` DISABLE KEYS */;
INSERT INTO `%PREFIX%version` (`version_id`,`private_revision_id`,`publication_datetime_t`,`publication_datetime_u`,`publication_status`,`version`,`memo`,`del_flag`,`reserve1`,`reserve2`,`reserve3`,`create_user`,`create_datetime`,`update_user`,`update_datetime`) VALUES 
 ('00001','00','2014/02/13 07:01','1392242480','','V1.0','初期バージョン','0','','','','installer','1392242480','','');
/*!40000 ALTER TABLE `%PREFIX%version` ENABLE KEYS */;


--
-- Definition of table `%PREFIX%widget`
--

DROP TABLE IF EXISTS `%PREFIX%widget`;
CREATE TABLE `%PREFIX%widget` (
  `version_id` char(5) NOT NULL default '',
  `revision_id` char(2) NOT NULL default '',
  `contents_id` char(10) NOT NULL default '',
  `contents_date` char(10) default NULL,
  `widget_id` char(10) default NULL,
  `html` text,
  `css` text,
  `php` text,
  `del_flag` char(1) default NULL,
  `reserve1` text,
  `reserve2` text,
  `reserve3` text,
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text,
  PRIMARY KEY  (`version_id`,`revision_id`,`contents_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `%PREFIX%widget`
--

/*!40000 ALTER TABLE `%PREFIX%widget` DISABLE KEYS */;
INSERT INTO `%PREFIX%widget` (`version_id`,`revision_id`,`contents_id`,`contents_date`,`widget_id`,`html`,`css`,`php`,`del_flag`,`reserve1`,`reserve2`,`reserve3`,`create_user`,`create_datetime`,`update_user`,`update_datetime`) VALUES 
 ('00001','00','0000000001','','','<?php echo $navi->getHtml(); ?>','#gnavi {\r\n	float: left;\r\n	list-style: none;\r\n	margin: 0;\r\n	padding: 0;\r\n	font-size: 14px;\r\n}\r\n#gnavi li {\r\n	float: left;\r\n	width: 140px;\r\n	border-right: 1px solid #999;\r\n	text-align: center;\r\n	padding: 0;\r\n}\r\n#gnavi li:first-child {\r\n	border-left: 1px solid #999;\r\n}\r\n#gnavi li a {\r\n	display: block;\r\n	padding: 20px 0;\r\n	height: 100%;\r\n}\r\n#gnavi li a:hover {\r\n	color: #999;\r\n}\r\n','<?php\r\n	global $global_navi;\r\n	\r\n	$config =\r\n	array(\r\n		\'start_html\'	=> \'<ul class=\"clearfix\" id=\"gnavi\">\',\r\n		\'end_html\'		=> \'</ul>\',\r\n		array(\r\n			\'name\'			=> \'category1\',\r\n			\'start_html\'	=> \'<li>\',\r\n			\'start_html_c\'	=> \'<li class=\"current\">\',\r\n			\'end_html\'		=> \'</li>\',\r\n			\'value\'			=> \'<a href=\"category1\" >CATEGORY1</a>\',\r\n		),\r\n		array(\r\n			\'name\'			=> \'category2\',\r\n			\'start_html\'	=> \'<li>\',\r\n			\'start_html_c\'	=> \'<li class=\"current\">\',\r\n			\'end_html\'		=> \'</li>\',\r\n			\'value\'			=> \'<a href=\"category2\" >CATEGORY2</a>\',\r\n		),\r\n		array(\r\n			\'name\'			=> \'category3\',\r\n			\'start_html\'	=> \'<li>\',\r\n			\'start_html_c\'	=> \'<li class=\"current\">\',\r\n			\'end_html\'		=> \'</li>\',\r\n			\'value\'			=> \'<a href=\"category3\" >CATEGORY3</a>\',\r\n		),\r\n		array(\r\n			\'name\'			=> \'category4\',\r\n			\'start_html\'	=> \'<li>\',\r\n			\'start_html_c\'	=> \'<li class=\"current\">\',\r\n			\'end_html\'		=> \'</li>\',\r\n			\'value\'			=> \'<a href=\"category4\" >CATEGORY4</a>\',\r\n		),\r\n	);\r\n	\r\n	$navi = new B_Element($config);\r\n	\r\n	if($global_navi) {\r\n		$obj = $navi->getElementByName($global_navi);\r\n		if($obj) $obj->start_html = $obj->start_html_c;\r\n	}\r\n?>','0','','','','admin','1392434102','admin','1398238345'),
 ('00001','00','0000000002','','','<ul class=\"news\">\r\n	<?php echo $news_list->getHtml(); ?>\r\n</ul>','.news {\r\n	list-style: none;\r\n	margin: 0;\r\n	padding: 10px 0 10px 20px;\r\n	font-family: \"メイリオ\", \"Meiryo\", \"ヒラギノ角ゴ Pro W3\", \"Hiragino Kaku Gothic Pro\", \"Osaka\", verdana, lucida, arial, helvetica, sans-serif;\r\n	border: 1px solid #999;\r\n}\r\n.news li {\r\n	margin: 10px 0;\r\n}\r\n.news li .datetime {\r\n	font-size: 15px;\r\n	font-weight: bold;\r\n	line-height: 24px;\r\n}\r\n.news li span.category {\r\n	color: #fff;\r\n	padding: 2px 8px 0 8px;\r\n	margin-left: 10px;\r\n	font-size: 12px;\r\n}\r\n.news li .title {\r\n	padding-left: 20px;\r\n	font-size: 17px;\r\n}\r\n.news li .title a:link,\r\n.news li .title a:visited {\r\n	color: #555;\r\n	text-decoration: none;\r\n}\r\n.news li .title a:hover {\r\n	color: #999;\r\n}\r\n','<?php\r\n	$config =\r\n	array(\r\n		\'select_sql\'	=> \"select * from \" . B_ARTICLE_VIEW . \" where 1=1\",\r\n		\'row\'			=>\r\n		array(\r\n			array(\r\n				\'start_html\'	=> \'<li>\',\r\n				\'end_html\'		=> \'</li>\',\r\n				array(\r\n					\'start_html\'	=> \'<div class=\"datetime\">\',\r\n					\'end_html\'		=> \'</div>\',\r\n					array(\r\n						\'name\'			=> \'article_date_t\',\r\n					),\r\n					array(\r\n						\'name\'			=> \'category\',\r\n						\'start_html\'	=> \'<span class=\"category\">\',\r\n						\'end_html\'		=> \'</span>\',\r\n					),\r\n				),\r\n				array(\r\n					\'name\'			=> \'detail_link\',\r\n					\'class\'			=> \'B_Link\',\r\n					\'start_html\'	=> \'<div class=\"title\">\',\r\n					\'end_html\'		=> \'</div>\',\r\n					\'link\'			=> \'news/detail\',\r\n					\'parmalink\'		=>\r\n					array(\r\n						\'id\'		=> \'article_id\',\r\n					),\r\n					array(\r\n						\'name\'			=> \'title\',\r\n						\'class\'			=> \'B_TextField\',\r\n						\'specialchars\'	=> \'none\',\r\n					),\r\n				),\r\n			),\r\n			array(\r\n				\'class\'			=> \'B_Data\',\r\n				\'name\'			=> \'color\',\r\n			),\r\n			array(\r\n				\'class\'			=> \'B_Data\',\r\n				\'name\'			=> \'background_color\',\r\n			),\r\n			array(\r\n				\'class\'			=> \'B_Data\',\r\n				\'name\'			=> \'icon_file\',\r\n			),\r\n			array(\r\n				\'class\'			=> \'B_Data\',\r\n				\'name\'			=> \'article_date_u\',\r\n			),\r\n			array(\r\n				\'class\'			=> \'B_Data\',\r\n				\'name\'			=> \'external_link\',\r\n			),\r\n			array(\r\n				\'class\'			=> \'B_Data\',\r\n				\'name\'			=> \'url\',\r\n			),\r\n			array(\r\n				\'class\'			=> \'B_Data\',\r\n				\'name\'			=> \'external_window\',\r\n			),\r\n			array(\r\n				\'class\'			=> \'B_Data\',\r\n				\'name\'			=> \'description_flag\',\r\n			),\r\n		),\r\n	);\r\n\r\n	$news_list = new B_DataGrid($bs_db, $config);\r\n	$news_list->setCallBack(null, \'_call_back\');\r\n\r\n	$news_list->setSqlOrderBy(\" order by article_date_u desc, article_id desc \");\r\n	$news_list->setRowPerPage(4);\r\n	$news_list->setPage(1);\r\n	$news_list->bind();\r\n\r\n	function _call_back($param) {\r\n		$util = new B_Util();\r\n		$row = $param[\'row\'];\r\n\r\n		$date_u = $row->getElementByName(\'article_date_u\');\r\n		$date_t = $row->getElementByName(\'article_date_t\');\r\n		$date_t->value = date(\'M. jS, Y\', $date_u->value);\r\n		\r\n		// カテゴリ設定\r\n		$icon_file = $row->getElementByName(\'icon_file\');\r\n		$category = $row->getElementByName(\'category\');\r\n		// アイコン\r\n		if($icon_file->value) {\r\n			$category->value = \'<img src=\"\' . B_Util::getPath(B_UPLOAD_URL, $icon_file->value) . \'\" alt=\"\' . $category->value . \'\" />\';\r\n		}\r\n		// 文字色\r\n		$color = $row->getElementByName(\'color\');\r\n		if($color->value) {\r\n			$style.= \'color:\' . $color->value . \';\';\r\n		}\r\n		// 背景色\r\n		$background_color = $row->getElementByName(\'background_color\');\r\n		if($background_color->value) {\r\n			$style.= \'background-color:\' . $background_color->value . \';\';\r\n		}\r\n		if($style) {\r\n			$category->start_html = \'<span class=\"category\" style=\"\' . $style . \'\">\';\r\n		}\r\n\r\n		// リンク設定\r\n		$description_flag = $row->getElementByName(\'description_flag\');\r\n		$detail_link = $row->getElementByName(\'detail_link\');\r\n		if($description_flag->value != \'1\') {\r\n			// 詳細表示なし\r\n			$external_link = $row->getElementByName(\'external_link\');\r\n			if($external_link->value == \'1\') {\r\n				$url = $row->getElementByName(\'url\');\r\n				$detail_link->link = $url->value;\r\n				unset($detail_link->param);\r\n\r\n				$external_window = $row->getElementByName(\'external_window\');\r\n				if($external_window->value == \'1\') {\r\n					$detail_link->special_html = \'onclick=\"window.open(this.href); return false;\"\';\r\n				}\r\n			}\r\n			else {\r\n				$detail_link->link = \'none\';\r\n			}\r\n		}\r\n	}\r\n?>','0','','','','admin','1393122518','admin','1434939934'),
 ('00001','00','0000000003','','','<ul class=\"news\">\r\n	<?php echo $news_list->getHtml(); ?>\r\n</ul>','.news {\r\n	list-style: none;\r\n	margin: 0;\r\n	padding: 10px 0 10px 20px;\r\n	font-family: \"メイリオ\", \"Meiryo\", \"ヒラギノ角ゴ Pro W3\", \"Hiragino Kaku Gothic Pro\", \"Osaka\", verdana, lucida, arial, helvetica, sans-serif;\r\n}\r\n.news li {\r\n	margin: 10px 0;\r\n}\r\n.news li .datetime {\r\n	font-size: 15px;\r\n	font-weight: bold;\r\n	line-height: 24px;\r\n}\r\n.news li span.category {\r\n	color: #fff;\r\n	padding: 2px 8px 0 8px;\r\n	margin-left: 10px;\r\n	font-size: 12px;\r\n}\r\n.news li .title {\r\n	padding-left: 20px;\r\n	font-size: 17px;\r\n}\r\n.news li .title a:link,\r\n.news li .title a:visited {\r\n	color: #555;\r\n	text-decoration: none;\r\n}\r\n.news li .title a:hover {\r\n	color: #999;\r\n}\r\n','<?php\r\n	$config =\r\n	array(\r\n		\'select_sql\'	=> \"select * from \" . B_ARTICLE_VIEW . \" where 1=1\",\r\n		\'row\'			=>\r\n		array(\r\n			array(\r\n				\'start_html\'	=> \'<li>\',\r\n				\'end_html\'		=> \'</li>\',\r\n				array(\r\n					\'start_html\'	=> \'<div class=\"datetime\">\',\r\n					\'end_html\'		=> \'</div>\',\r\n					array(\r\n						\'name\'			=> \'article_date_t\',\r\n					),\r\n					array(\r\n						\'name\'			=> \'category\',\r\n						\'start_html\'	=> \'<span class=\"category\">\',\r\n						\'end_html\'		=> \'</span>\',\r\n					),\r\n				),\r\n				array(\r\n					\'name\'			=> \'detail_link\',\r\n					\'class\'			=> \'B_Link\',\r\n					\'start_html\'	=> \'<div class=\"title\">\',\r\n					\'end_html\'		=> \'</div>\',\r\n					\'link\'			=> \'news/detail\',\r\n					\'parmalink\'		=>\r\n					array(\r\n						\'id\'		=> \'article_id\',\r\n					),\r\n					array(\r\n						\'name\'			=> \'title\',\r\n						\'class\'			=> \'B_TextField\',\r\n						\'specialchars\'	=> \'none\',\r\n					),\r\n				),\r\n			),\r\n			array(\r\n				\'class\'			=> \'B_Data\',\r\n				\'name\'			=> \'color\',\r\n			),\r\n			array(\r\n				\'class\'			=> \'B_Data\',\r\n				\'name\'			=> \'background_color\',\r\n			),\r\n			array(\r\n				\'class\'			=> \'B_Data\',\r\n				\'name\'			=> \'icon_file\',\r\n			),\r\n			array(\r\n				\'class\'			=> \'B_Data\',\r\n				\'name\'			=> \'article_date_u\',\r\n			),\r\n			array(\r\n				\'class\'			=> \'B_Data\',\r\n				\'name\'			=> \'external_link\',\r\n			),\r\n			array(\r\n				\'class\'			=> \'B_Data\',\r\n				\'name\'			=> \'url\',\r\n			),\r\n			array(\r\n				\'class\'			=> \'B_Data\',\r\n				\'name\'			=> \'external_window\',\r\n			),\r\n			array(\r\n				\'class\'			=> \'B_Data\',\r\n				\'name\'			=> \'description_flag\',\r\n			),\r\n		),\r\n	);\r\n\r\n	$news_list = new B_DataGrid($bs_db, $config);\r\n	$news_list->setCallBack(null, \'_call_back\');\r\n\r\n	$news_list->setSqlOrderBy(\" order by article_date_u desc, article_id desc \");\r\n	$news_list->setRowPerPage(\'all\');\r\n	$news_list->setPage(1);\r\n	$news_list->bind();\r\n\r\n	function _call_back($param) {\r\n		$util = new B_Util();\r\n		$row = $param[\'row\'];\r\n\r\n		$date_u = $row->getElementByName(\'article_date_u\');\r\n		$date_t = $row->getElementByName(\'article_date_t\');\r\n		$date_t->value = date(\'M. jS, Y\', $date_u->value);\r\n		\r\n		// カテゴリ設定\r\n		$icon_file = $row->getElementByName(\'icon_file\');\r\n		$category = $row->getElementByName(\'category\');\r\n		// アイコン\r\n		if($icon_file->value) {\r\n			$category->value = \'<img src=\"\' . B_Util::getPath(B_UPLOAD_URL, $icon_file->value) . \'\" alt=\"\' . $category->value . \'\" />\';\r\n		}\r\n		// 文字色\r\n		$color = $row->getElementByName(\'color\');\r\n		if($color->value) {\r\n			$style.= \'color:\' . $color->value . \';\';\r\n		}\r\n		// 背景色\r\n		$background_color = $row->getElementByName(\'background_color\');\r\n		if($background_color->value) {\r\n			$style.= \'background-color:\' . $background_color->value . \';\';\r\n		}\r\n		if($style) {\r\n			$category->start_html = \'<span class=\"category\" style=\"\' . $style . \'\">\';\r\n		}\r\n\r\n		// リンク設定\r\n		$description_flag = $row->getElementByName(\'description_flag\');\r\n		$detail_link = $row->getElementByName(\'detail_link\');\r\n		if($description_flag->value != \'1\') {\r\n			// 詳細表示なし\r\n			$external_link = $row->getElementByName(\'external_link\');\r\n			if($external_link->value == \'1\') {\r\n				$url = $row->getElementByName(\'url\');\r\n				$detail_link->link = $url->value;\r\n				unset($detail_link->param);\r\n\r\n				$external_window = $row->getElementByName(\'external_window\');\r\n				if($external_window->value == \'1\') {\r\n					$detail_link->special_html = \'onclick=\"window.open(this.href); return false;\"\';\r\n				}\r\n			}\r\n			else {\r\n				$detail_link->link = \'none\';\r\n			}\r\n		}\r\n	}\r\n?>','0','','','','admin','1393223792','admin','1434939944'),
 ('00001','00','0000000004','','','<ul class=\"sitemap\">\r\n	<li><a href=\".\">HOME</a></li>\r\n	<li><a href=\"category1\">CATEGORY1</a></li>\r\n	<li><a href=\"category2\">CATEGORY2</a></li>\r\n	<li><a href=\"category3\">CATEGORY3</a></li>\r\n	<li><a href=\"category4\">CATEGORY4</a></li>\r\n</ul>\r\n','.sitemap a:link,\r\n.sitemap a:visited {\r\n	color: #fff;\r\n}\r\n.sitemap a:hover {\r\n	color: #ccc;\r\n}','','0','','','','admin','1393225648','admin','1393236749'),
 ('00001','00','0000000005','','','<div id=\"breadcrumbs\">\r\n	<?php echo $html; ?>\r\n</div>\r\n','','<?php\r\n	for($i=0 ; $i<count($bs_breadcrumbs)-1; $i++) {\r\n		if(trim($bs_breadcrumbs[$i][\'value\']) == \'\') continue;\r\n\r\n		$item = \'<a href=\"\' . $bs_breadcrumbs[$i][\'url\'] . \'\" \';\r\n		$item.= \'title=\"\' . $bs_breadcrumbs[$i][\'value\'] . \'へ\">\';\r\n		$item.= $bs_breadcrumbs[$i][\'value\'] . \'</a>\';\r\n		$bc[] = $item;\r\n	}\r\n	$bc[] = $bs_breadcrumbs[$i][\'value\'];\r\n	$html = implode(\'&nbsp;&gt;&nbsp;\', $bc);\r\n?>','0','','','','admin','1421628423','admin','1421631069');
/*!40000 ALTER TABLE `%PREFIX%widget` ENABLE KEYS */;


--
-- Definition of table `%PREFIX%widget_node`
--

DROP TABLE IF EXISTS `%PREFIX%widget_node`;
CREATE TABLE `%PREFIX%widget_node` (
  `version_id` char(5) NOT NULL default '',
  `revision_id` char(2) NOT NULL default '',
  `node_id` char(10) NOT NULL default '',
  `parent_node` char(10) default NULL,
  `node_type` char(10) default NULL,
  `node_class` char(10) default NULL,
  `node_name` text,
  `contents_id` char(10) default NULL,
  `disp_seq` int(11) default NULL,
  `del_flag` char(1) default NULL,
  `create_user` text,
  `create_datetime` text,
  `update_user` text,
  `update_datetime` text,
  PRIMARY KEY  (`version_id`,`revision_id`,`node_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `%PREFIX%widget_node`
--

/*!40000 ALTER TABLE `%PREFIX%widget_node` DISABLE KEYS */;
INSERT INTO `%PREFIX%widget_node` (`version_id`,`revision_id`,`node_id`,`parent_node`,`node_type`,`node_class`,`node_name`,`contents_id`,`disp_seq`,`del_flag`,`create_user`,`create_datetime`,`update_user`,`update_datetime`) VALUES 
 ('00001','00','0000000001','root','widget','leaf','navi','0000000001','0','0','admin','1392433728','admin','1393226596'),
 ('00001','00','0000000002','root','widget','leaf','news_top','0000000002','2','0','admin','1393122470','admin','1393226596'),
 ('00001','00','0000000003','root','widget','leaf','news_list','0000000003','3','0','admin','1393223792','admin','1393226596'),
 ('00001','00','0000000004','root','widget','leaf','site_map','0000000004','1','0','admin','1393225648','admin','1393226596'),
 ('00001','00','0000000005','root','widget','leaf','breadcrumbs','0000000005','4','0','admin','1421628364','admin','1421628370');
/*!40000 ALTER TABLE `%PREFIX%widget_node` ENABLE KEYS */;


--
-- Definition of view `%PREFIX%v_admin_article`
--

DROP TABLE IF EXISTS `%PREFIX%v_admin_article`;
DROP VIEW IF EXISTS `%PREFIX%v_admin_article`;
CREATE   VIEW `%PREFIX%v_admin_article` AS select `a`.`article_id` AS `article_id`,`a`.`article_date_t` AS `article_date_t`,`a`.`article_date_u` AS `article_date_u`,`a`.`category_id` AS `category_id`,`a`.`keywords` AS `keywords`,`a`.`description` AS `description`,`a`.`publication` AS `publication`,`a`.`title` AS `title`,`a`.`title_img_file` AS `title_img_file`,`a`.`description_flag` AS `description_flag`,`a`.`external_link` AS `external_link`,`a`.`external_window` AS `external_window`,`a`.`url` AS `url`,`a`.`contents` AS `contents`,`a`.`del_flag` AS `del_flag`,`a`.`folder_id` AS `folder_id`,`a`.`reserve1` AS `reserve1`,`a`.`reserve2` AS `reserve2`,`a`.`reserve3` AS `reserve3`,`a`.`create_user` AS `create_user`,`a`.`create_datetime` AS `create_datetime`,`a`.`update_user` AS `update_user`,`a`.`update_datetime` AS `update_datetime`,concat(`a`.`article_date_u`,`a`.`article_id`) AS `article_date`,`b`.`node_name` AS `category`,`b`.`color` AS `color`,`b`.`background_color` AS `background_color`,`b`.`icon_file` AS `icon_file` from (`%PREFIX%article` `a` left join `%PREFIX%v_category` `b` on((`a`.`category_id` = `b`.`node_id`))) where (`a`.`del_flag` = _utf8'0');

--
-- Definition of view `%PREFIX%v_admin_article2`
--

DROP TABLE IF EXISTS `%PREFIX%v_admin_article2`;
DROP VIEW IF EXISTS `%PREFIX%v_admin_article2`;
CREATE   VIEW `%PREFIX%v_admin_article2` AS select `a`.`article_id` AS `article_id`,`a`.`article_date_t` AS `article_date_t`,`a`.`article_date_u` AS `article_date_u`,`a`.`category_id` AS `category_id`,`a`.`keywords` AS `keywords`,`a`.`description` AS `description`,`a`.`publication` AS `publication`,`a`.`title` AS `title`,`a`.`title_img_file` AS `title_img_file`,`a`.`description_flag` AS `description_flag`,`a`.`external_link` AS `external_link`,`a`.`external_window` AS `external_window`,`a`.`url` AS `url`,`a`.`contents` AS `contents`,`a`.`del_flag` AS `del_flag`,`a`.`folder_id` AS `folder_id`,`a`.`reserve1` AS `reserve1`,`a`.`reserve2` AS `reserve2`,`a`.`reserve3` AS `reserve3`,`a`.`create_user` AS `create_user`,`a`.`create_datetime` AS `create_datetime`,`a`.`update_user` AS `update_user`,`a`.`update_datetime` AS `update_datetime`,concat(`a`.`article_date_u`,`a`.`article_id`) AS `article_date`,`b`.`node_name` AS `category`,`b`.`color` AS `color`,`b`.`background_color` AS `background_color`,`b`.`icon_file` AS `icon_file` from (`%PREFIX%article2` `a` left join `%PREFIX%v_category2` `b` on((`a`.`category_id` = `b`.`node_id`))) where (`a`.`del_flag` = _utf8'0');

--
-- Definition of view `%PREFIX%v_admin_article3`
--

DROP TABLE IF EXISTS `%PREFIX%v_admin_article3`;
DROP VIEW IF EXISTS `%PREFIX%v_admin_article3`;
CREATE   VIEW `%PREFIX%v_admin_article3` AS select `a`.`article_id` AS `article_id`,`a`.`article_date_t` AS `article_date_t`,`a`.`article_date_u` AS `article_date_u`,`a`.`category_id` AS `category_id`,`a`.`keywords` AS `keywords`,`a`.`description` AS `description`,`a`.`publication` AS `publication`,`a`.`title` AS `title`,`a`.`title_img_file` AS `title_img_file`,`a`.`description_flag` AS `description_flag`,`a`.`external_link` AS `external_link`,`a`.`external_window` AS `external_window`,`a`.`url` AS `url`,`a`.`contents` AS `contents`,`a`.`del_flag` AS `del_flag`,`a`.`folder_id` AS `folder_id`,`a`.`reserve1` AS `reserve1`,`a`.`reserve2` AS `reserve2`,`a`.`reserve3` AS `reserve3`,`a`.`create_user` AS `create_user`,`a`.`create_datetime` AS `create_datetime`,`a`.`update_user` AS `update_user`,`a`.`update_datetime` AS `update_datetime`,concat(`a`.`article_date_u`,`a`.`article_id`) AS `article_date`,`b`.`node_name` AS `category`,`b`.`color` AS `color`,`b`.`background_color` AS `background_color`,`b`.`icon_file` AS `icon_file` from (`%PREFIX%article3` `a` left join `%PREFIX%v_category3` `b` on((`a`.`category_id` = `b`.`node_id`))) where (`a`.`del_flag` = _utf8'0');

--
-- Definition of view `%PREFIX%v_article`
--

DROP TABLE IF EXISTS `%PREFIX%v_article`;
DROP VIEW IF EXISTS `%PREFIX%v_article`;
CREATE   VIEW `%PREFIX%v_article` AS select `a`.`article_id` AS `article_id`,`a`.`article_date_t` AS `article_date_t`,`a`.`article_date_u` AS `article_date_u`,`a`.`category_id` AS `category_id`,`a`.`keywords` AS `keywords`,`a`.`description` AS `description`,`a`.`publication` AS `publication`,`a`.`title` AS `title`,`a`.`title_img_file` AS `title_img_file`,`a`.`description_flag` AS `description_flag`,`a`.`external_link` AS `external_link`,`a`.`external_window` AS `external_window`,`a`.`url` AS `url`,`a`.`contents` AS `contents`,`a`.`del_flag` AS `del_flag`,`a`.`folder_id` AS `folder_id`,`a`.`reserve1` AS `reserve1`,`a`.`reserve2` AS `reserve2`,`a`.`reserve3` AS `reserve3`,`a`.`create_user` AS `create_user`,`a`.`create_datetime` AS `create_datetime`,`a`.`update_user` AS `update_user`,`a`.`update_datetime` AS `update_datetime`,concat(`a`.`article_date_u`,`a`.`article_id`) AS `article_date`,`b`.`node_name` AS `category`,`b`.`color` AS `color`,`b`.`background_color` AS `background_color`,`b`.`icon_file` AS `icon_file` from (`%PREFIX%article` `a` left join `%PREFIX%v_category` `b` on((`a`.`category_id` = `b`.`node_id`))) where ((`a`.`del_flag` = _utf8'0') and (`a`.`publication` = _utf8'1'));

--
-- Definition of view `%PREFIX%v_article2`
--

DROP TABLE IF EXISTS `%PREFIX%v_article2`;
DROP VIEW IF EXISTS `%PREFIX%v_article2`;
CREATE   VIEW `%PREFIX%v_article2` AS select `a`.`article_id` AS `article_id`,`a`.`article_date_t` AS `article_date_t`,`a`.`article_date_u` AS `article_date_u`,`a`.`category_id` AS `category_id`,`a`.`keywords` AS `keywords`,`a`.`description` AS `description`,`a`.`publication` AS `publication`,`a`.`title` AS `title`,`a`.`title_img_file` AS `title_img_file`,`a`.`description_flag` AS `description_flag`,`a`.`external_link` AS `external_link`,`a`.`external_window` AS `external_window`,`a`.`url` AS `url`,`a`.`contents` AS `contents`,`a`.`del_flag` AS `del_flag`,`a`.`folder_id` AS `folder_id`,`a`.`reserve1` AS `reserve1`,`a`.`reserve2` AS `reserve2`,`a`.`reserve3` AS `reserve3`,`a`.`create_user` AS `create_user`,`a`.`create_datetime` AS `create_datetime`,`a`.`update_user` AS `update_user`,`a`.`update_datetime` AS `update_datetime`,concat(`a`.`article_date_u`,`a`.`article_id`) AS `article_date`,`b`.`node_name` AS `category`,`b`.`color` AS `color`,`b`.`background_color` AS `background_color`,`b`.`icon_file` AS `icon_file` from (`%PREFIX%article2` `a` left join `%PREFIX%v_category2` `b` on((`a`.`category_id` = `b`.`node_id`))) where ((`a`.`del_flag` = _utf8'0') and (`a`.`publication` = _utf8'1'));

--
-- Definition of view `%PREFIX%v_article3`
--

DROP TABLE IF EXISTS `%PREFIX%v_article3`;
DROP VIEW IF EXISTS `%PREFIX%v_article3`;
CREATE   VIEW `%PREFIX%v_article3` AS select `a`.`article_id` AS `article_id`,`a`.`article_date_t` AS `article_date_t`,`a`.`article_date_u` AS `article_date_u`,`a`.`category_id` AS `category_id`,`a`.`keywords` AS `keywords`,`a`.`description` AS `description`,`a`.`publication` AS `publication`,`a`.`title` AS `title`,`a`.`title_img_file` AS `title_img_file`,`a`.`description_flag` AS `description_flag`,`a`.`external_link` AS `external_link`,`a`.`external_window` AS `external_window`,`a`.`url` AS `url`,`a`.`contents` AS `contents`,`a`.`del_flag` AS `del_flag`,`a`.`folder_id` AS `folder_id`,`a`.`reserve1` AS `reserve1`,`a`.`reserve2` AS `reserve2`,`a`.`reserve3` AS `reserve3`,`a`.`create_user` AS `create_user`,`a`.`create_datetime` AS `create_datetime`,`a`.`update_user` AS `update_user`,`a`.`update_datetime` AS `update_datetime`,concat(`a`.`article_date_u`,`a`.`article_id`) AS `article_date`,`b`.`node_name` AS `category`,`b`.`color` AS `color`,`b`.`background_color` AS `background_color`,`b`.`icon_file` AS `icon_file` from (`%PREFIX%article3` `a` left join `%PREFIX%v_category3` `b` on((`a`.`category_id` = `b`.`node_id`))) where ((`a`.`del_flag` = _utf8'0') and (`a`.`publication` = _utf8'1'));

--
-- Definition of view `%PREFIX%v_c_contents`
--

DROP TABLE IF EXISTS `%PREFIX%v_c_contents`;
DROP VIEW IF EXISTS `%PREFIX%v_c_contents`;
CREATE   VIEW `%PREFIX%v_c_contents` AS select `a`.`version_id` AS `version_id`,`a`.`revision_id` AS `revision_id`,`a`.`contents_id` AS `contents_id`,`a`.`contents_date` AS `contents_date`,`a`.`template_id` AS `template_id`,`a`.`title` AS `title`,`a`.`breadcrumbs` AS `breadcrumbs`,`a`.`html1` AS `html1`,`a`.`html2` AS `html2`,`a`.`html3` AS `html3`,`a`.`html4` AS `html4`,`a`.`css` AS `css`,`a`.`php` AS `php`,`a`.`keywords` AS `keywords`,`a`.`description` AS `description`,`a`.`external_css` AS `external_css`,`a`.`external_js` AS `external_js`,`a`.`header_element` AS `header_element`,`a`.`del_flag` AS `del_flag`,`a`.`reserve1` AS `reserve1`,`a`.`reserve2` AS `reserve2`,`a`.`reserve3` AS `reserve3`,`a`.`create_user` AS `create_user`,`a`.`create_datetime` AS `create_datetime`,`a`.`update_user` AS `update_user`,`a`.`update_datetime` AS `update_datetime` from `%PREFIX%contents` `a` where (concat(`a`.`version_id`,`a`.`revision_id`) = (select max(concat(`b`.`version_id`,`b`.`revision_id`)) AS `max(concat(b.version_id, b.revision_id))` from ((`%PREFIX%contents` `b` join `%PREFIX%v_current_version` `c`) join `%PREFIX%version` `d`) where ((`a`.`contents_id` = `b`.`contents_id`) and (`b`.`version_id` = `d`.`version_id`) and (((`b`.`version_id` < `c`.`current_version_id`) and (`b`.`revision_id` < `d`.`private_revision_id`)) or ((`b`.`version_id` = `c`.`current_version_id`) and (`b`.`revision_id` <= `d`.`private_revision_id`)))) group by `b`.`contents_id`));

--
-- Definition of view `%PREFIX%v_c_contents_node`
--

DROP TABLE IF EXISTS `%PREFIX%v_c_contents_node`;
DROP VIEW IF EXISTS `%PREFIX%v_c_contents_node`;
CREATE   VIEW `%PREFIX%v_c_contents_node` AS select `a`.`version_id` AS `version_id`,`a`.`revision_id` AS `revision_id`,`a`.`node_id` AS `node_id`,`a`.`parent_node` AS `parent_node`,`a`.`node_type` AS `node_type`,`a`.`node_class` AS `node_class`,`a`.`node_name` AS `node_name`,`a`.`contents_id` AS `contents_id`,`a`.`disp_seq` AS `disp_seq`,`a`.`del_flag` AS `del_flag`,`a`.`create_user` AS `create_user`,`a`.`create_datetime` AS `create_datetime`,`a`.`update_user` AS `update_user`,`a`.`update_datetime` AS `update_datetime` from `%PREFIX%contents_node` `a` where (concat(`a`.`version_id`,`a`.`revision_id`) = (select max(concat(`b`.`version_id`,`b`.`revision_id`)) AS `max(concat(``b``.``version_id``,``b``.``revision_id``))` from ((`%PREFIX%contents_node` `b` join `%PREFIX%v_current_version` `c`) join `%PREFIX%version` `d`) where ((`a`.`node_id` = `b`.`node_id`) and (`b`.`version_id` = `d`.`version_id`) and (((`b`.`version_id` < convert(`c`.`current_version_id` using utf8)) and (`b`.`revision_id` < `d`.`private_revision_id`)) or ((`b`.`version_id` = convert(`c`.`current_version_id` using utf8)) and (`b`.`revision_id` <= `d`.`private_revision_id`)))) group by `b`.`node_id`));

--
-- Definition of view `%PREFIX%v_c_resource_node`
--

DROP TABLE IF EXISTS `%PREFIX%v_c_resource_node`;
DROP VIEW IF EXISTS `%PREFIX%v_c_resource_node`;
CREATE   VIEW `%PREFIX%v_c_resource_node` AS select `a`.`version_id` AS `version_id`,`a`.`revision_id` AS `revision_id`,`a`.`node_id` AS `node_id`,`a`.`parent_node` AS `parent_node`,`a`.`node_type` AS `node_type`,`a`.`node_class` AS `node_class`,`a`.`node_name` AS `node_name`,`a`.`file_size` AS `file_size`,`a`.`human_file_size` AS `human_file_size`,`a`.`image_size` AS `image_size`,`a`.`human_image_size` AS `human_image_size`,`a`.`contents_id` AS `contents_id`,`a`.`disp_seq` AS `disp_seq`,`a`.`del_flag` AS `del_flag`,`a`.`create_user` AS `create_user`,`a`.`create_datetime` AS `create_datetime`,`a`.`update_user` AS `update_user`,`a`.`update_datetime` AS `update_datetime` from `%PREFIX%resource_node` `a` where (concat(`a`.`version_id`,`a`.`revision_id`) = (select max(concat(`b`.`version_id`,`b`.`revision_id`)) AS `max(concat(b.version_id, b.revision_id))` from ((`%PREFIX%resource_node` `b` join `%PREFIX%v_current_version` `c`) join `%PREFIX%version` `d`) where ((`a`.`node_id` = `b`.`node_id`) and (`b`.`version_id` = `d`.`version_id`) and (((`b`.`version_id` < convert(`c`.`current_version_id` using utf8)) and (`b`.`revision_id` < `d`.`private_revision_id`)) or ((`b`.`version_id` = convert(`c`.`current_version_id` using utf8)) and (`b`.`revision_id` <= `d`.`private_revision_id`)))) group by `b`.`node_id`));

--
-- Definition of view `%PREFIX%v_c_template`
--

DROP TABLE IF EXISTS `%PREFIX%v_c_template`;
DROP VIEW IF EXISTS `%PREFIX%v_c_template`;
CREATE   VIEW `%PREFIX%v_c_template` AS select `a`.`version_id` AS `version_id`,`a`.`revision_id` AS `revision_id`,`a`.`contents_id` AS `contents_id`,`a`.`contents_date` AS `contents_date`,`a`.`template_id` AS `template_id`,`a`.`start_html` AS `start_html`,`a`.`end_html` AS `end_html`,`a`.`css` AS `css`,`a`.`php` AS `php`,`a`.`external_css` AS `external_css`,`a`.`external_js` AS `external_js`,`a`.`header_element` AS `header_element`,`a`.`del_flag` AS `del_flag`,`a`.`reserve1` AS `reserve1`,`a`.`reserve2` AS `reserve2`,`a`.`reserve3` AS `reserve3`,`a`.`create_user` AS `create_user`,`a`.`create_datetime` AS `create_datetime`,`a`.`update_user` AS `update_user`,`a`.`update_datetime` AS `update_datetime` from `%PREFIX%template` `a` where (concat(`a`.`version_id`,`a`.`revision_id`) = (select max(concat(`b`.`version_id`,`b`.`revision_id`)) AS `max(concat(``b``.``version_id``,``b``.``revision_id``))` from ((`%PREFIX%template` `b` join `%PREFIX%v_current_version` `c`) join `%PREFIX%version` `d`) where ((`a`.`contents_id` = `b`.`contents_id`) and (`b`.`version_id` = `d`.`version_id`) and (((`b`.`version_id` < convert(`c`.`current_version_id` using utf8)) and (`b`.`revision_id` < `d`.`private_revision_id`)) or ((`b`.`version_id` = convert(`c`.`current_version_id` using utf8)) and (`b`.`revision_id` <= `d`.`private_revision_id`)))) group by `b`.`contents_id`));

--
-- Definition of view `%PREFIX%v_c_template_node`
--

DROP TABLE IF EXISTS `%PREFIX%v_c_template_node`;
DROP VIEW IF EXISTS `%PREFIX%v_c_template_node`;
CREATE   VIEW `%PREFIX%v_c_template_node` AS select `a`.`version_id` AS `version_id`,`a`.`revision_id` AS `revision_id`,`a`.`node_id` AS `node_id`,`a`.`parent_node` AS `parent_node`,`a`.`node_type` AS `node_type`,`a`.`node_class` AS `node_class`,`a`.`node_name` AS `node_name`,`a`.`contents_id` AS `contents_id`,`a`.`disp_seq` AS `disp_seq`,`a`.`del_flag` AS `del_flag`,`a`.`create_user` AS `create_user`,`a`.`create_datetime` AS `create_datetime`,`a`.`update_user` AS `update_user`,`a`.`update_datetime` AS `update_datetime` from `%PREFIX%template_node` `a` where (concat(`a`.`version_id`,`a`.`revision_id`) = (select max(concat(`b`.`version_id`,`b`.`revision_id`)) AS `max(concat(``b``.``version_id``,``b``.``revision_id``))` from ((`%PREFIX%template_node` `b` join `%PREFIX%v_current_version` `c`) join `%PREFIX%version` `d`) where ((`a`.`node_id` = `b`.`node_id`) and (`b`.`version_id` = `d`.`version_id`) and (((`b`.`version_id` < convert(`c`.`current_version_id` using utf8)) and (`b`.`revision_id` < `d`.`private_revision_id`)) or ((`b`.`version_id` = convert(`c`.`current_version_id` using utf8)) and (`b`.`revision_id` <= `d`.`private_revision_id`)))) group by `b`.`node_id`));

--
-- Definition of view `%PREFIX%v_c_widget`
--

DROP TABLE IF EXISTS `%PREFIX%v_c_widget`;
DROP VIEW IF EXISTS `%PREFIX%v_c_widget`;
CREATE   VIEW `%PREFIX%v_c_widget` AS select `a`.`version_id` AS `version_id`,`a`.`revision_id` AS `revision_id`,`a`.`contents_id` AS `contents_id`,`a`.`contents_date` AS `contents_date`,`a`.`widget_id` AS `widget_id`,`a`.`html` AS `html`,`a`.`css` AS `css`,`a`.`php` AS `php`,`a`.`del_flag` AS `del_flag`,`a`.`reserve1` AS `reserve1`,`a`.`reserve2` AS `reserve2`,`a`.`reserve3` AS `reserve3`,`a`.`create_user` AS `create_user`,`a`.`create_datetime` AS `create_datetime`,`a`.`update_user` AS `update_user`,`a`.`update_datetime` AS `update_datetime` from `%PREFIX%widget` `a` where (concat(`a`.`version_id`,`a`.`revision_id`) = (select max(concat(`b`.`version_id`,`b`.`revision_id`)) AS `max(concat(``b``.``version_id``,``b``.``revision_id``))` from ((`%PREFIX%widget` `b` join `%PREFIX%v_current_version` `c`) join `%PREFIX%version` `d`) where ((`a`.`contents_id` = `b`.`contents_id`) and (`b`.`version_id` = `d`.`version_id`) and (((`b`.`version_id` < convert(`c`.`current_version_id` using utf8)) and (`b`.`revision_id` < `d`.`private_revision_id`)) or ((`b`.`version_id` = convert(`c`.`current_version_id` using utf8)) and (`b`.`revision_id` <= `d`.`private_revision_id`)))) group by `b`.`contents_id`));

--
-- Definition of view `%PREFIX%v_c_widget_node`
--

DROP TABLE IF EXISTS `%PREFIX%v_c_widget_node`;
DROP VIEW IF EXISTS `%PREFIX%v_c_widget_node`;
CREATE   VIEW `%PREFIX%v_c_widget_node` AS select `a`.`version_id` AS `version_id`,`a`.`revision_id` AS `revision_id`,`a`.`node_id` AS `node_id`,`a`.`parent_node` AS `parent_node`,`a`.`node_type` AS `node_type`,`a`.`node_class` AS `node_class`,`a`.`node_name` AS `node_name`,`a`.`contents_id` AS `contents_id`,`a`.`disp_seq` AS `disp_seq`,`a`.`del_flag` AS `del_flag`,`a`.`create_user` AS `create_user`,`a`.`create_datetime` AS `create_datetime`,`a`.`update_user` AS `update_user`,`a`.`update_datetime` AS `update_datetime` from `%PREFIX%widget_node` `a` where (concat(`a`.`version_id`,`a`.`revision_id`) = (select max(concat(`b`.`version_id`,`b`.`revision_id`)) AS `max(concat(``b``.``version_id``,``b``.``revision_id``))` from ((`%PREFIX%widget_node` `b` join `%PREFIX%v_current_version` `c`) join `%PREFIX%version` `d`) where ((`a`.`node_id` = `b`.`node_id`) and (`b`.`version_id` = `d`.`version_id`) and (((`b`.`version_id` < convert(`c`.`current_version_id` using utf8)) and (`b`.`revision_id` < `d`.`private_revision_id`)) or ((`b`.`version_id` = convert(`c`.`current_version_id` using utf8)) and (`b`.`revision_id` <= `d`.`private_revision_id`)))) group by `b`.`node_id`));

--
-- Definition of view `%PREFIX%v_category`
--

DROP TABLE IF EXISTS `%PREFIX%v_category`;
DROP VIEW IF EXISTS `%PREFIX%v_category`;
CREATE   VIEW `%PREFIX%v_category` AS select `%PREFIX%category`.`node_id` AS `node_id`,`%PREFIX%category`.`parent_node` AS `parent_node`,`%PREFIX%category`.`node_type` AS `node_type`,`%PREFIX%category`.`node_class` AS `node_class`,`%PREFIX%category`.`node_name` AS `node_name`,`%PREFIX%category`.`disp_seq` AS `disp_seq`,`%PREFIX%category`.`color` AS `color`,`%PREFIX%category`.`background_color` AS `background_color`,`%PREFIX%category`.`icon_file` AS `icon_file`,`%PREFIX%category`.`del_flag` AS `del_flag`,`%PREFIX%category`.`create_user` AS `create_user`,`%PREFIX%category`.`create_datetime` AS `create_datetime`,`%PREFIX%category`.`update_user` AS `update_user`,`%PREFIX%category`.`update_datetime` AS `update_datetime` from `%PREFIX%category` where (`%PREFIX%category`.`del_flag` = _utf8'0');

--
-- Definition of view `%PREFIX%v_category2`
--

DROP TABLE IF EXISTS `%PREFIX%v_category2`;
DROP VIEW IF EXISTS `%PREFIX%v_category2`;
CREATE   VIEW `%PREFIX%v_category2` AS select `%PREFIX%category2`.`node_id` AS `node_id`,`%PREFIX%category2`.`parent_node` AS `parent_node`,`%PREFIX%category2`.`node_type` AS `node_type`,`%PREFIX%category2`.`node_class` AS `node_class`,`%PREFIX%category2`.`node_name` AS `node_name`,`%PREFIX%category2`.`disp_seq` AS `disp_seq`,`%PREFIX%category2`.`color` AS `color`,`%PREFIX%category2`.`background_color` AS `background_color`,`%PREFIX%category2`.`icon_file` AS `icon_file`,`%PREFIX%category2`.`del_flag` AS `del_flag`,`%PREFIX%category2`.`create_user` AS `create_user`,`%PREFIX%category2`.`create_datetime` AS `create_datetime`,`%PREFIX%category2`.`update_user` AS `update_user`,`%PREFIX%category2`.`update_datetime` AS `update_datetime` from `%PREFIX%category2` where (`%PREFIX%category2`.`del_flag` = _utf8'0');

--
-- Definition of view `%PREFIX%v_category3`
--

DROP TABLE IF EXISTS `%PREFIX%v_category3`;
DROP VIEW IF EXISTS `%PREFIX%v_category3`;
CREATE   VIEW `%PREFIX%v_category3` AS select `%PREFIX%category3`.`node_id` AS `node_id`,`%PREFIX%category3`.`parent_node` AS `parent_node`,`%PREFIX%category3`.`node_type` AS `node_type`,`%PREFIX%category3`.`node_class` AS `node_class`,`%PREFIX%category3`.`node_name` AS `node_name`,`%PREFIX%category3`.`disp_seq` AS `disp_seq`,`%PREFIX%category3`.`color` AS `color`,`%PREFIX%category3`.`background_color` AS `background_color`,`%PREFIX%category3`.`icon_file` AS `icon_file`,`%PREFIX%category3`.`del_flag` AS `del_flag`,`%PREFIX%category3`.`create_user` AS `create_user`,`%PREFIX%category3`.`create_datetime` AS `create_datetime`,`%PREFIX%category3`.`update_user` AS `update_user`,`%PREFIX%category3`.`update_datetime` AS `update_datetime` from `%PREFIX%category3` where (`%PREFIX%category3`.`del_flag` = _utf8'0');

--
-- Definition of view `%PREFIX%v_compare_contents_node`
--

DROP TABLE IF EXISTS `%PREFIX%v_compare_contents_node`;
DROP VIEW IF EXISTS `%PREFIX%v_compare_contents_node`;
CREATE   VIEW `%PREFIX%v_compare_contents_node` AS select `a`.`version_id` AS `version_id`,`a`.`revision_id` AS `revision_id`,`a`.`node_id` AS `node_id`,`a`.`parent_node` AS `parent_node`,`a`.`node_type` AS `node_type`,`a`.`node_class` AS `node_class`,`a`.`node_name` AS `node_name`,`a`.`contents_id` AS `contents_id`,`a`.`disp_seq` AS `disp_seq`,`a`.`del_flag` AS `del_flag`,`a`.`create_user` AS `create_user`,`a`.`create_datetime` AS `create_datetime`,`a`.`update_user` AS `update_user`,`a`.`update_datetime` AS `update_datetime` from `%PREFIX%contents_node` `a` where (concat(`a`.`version_id`,`a`.`revision_id`) = (select max(concat(`b`.`version_id`,`b`.`revision_id`)) AS `max(concat(b.version_id, b.revision_id))` from ((`%PREFIX%contents_node` `b` join `%PREFIX%compare_version` `c`) join `%PREFIX%version` `d`) where ((`a`.`node_id` = `b`.`node_id`) and (`b`.`version_id` = `d`.`version_id`) and (((`b`.`version_id` < `c`.`compare_version_id`) and (`b`.`revision_id` < `d`.`private_revision_id`)) or ((`b`.`version_id` = `c`.`compare_version_id`) and (`b`.`revision_id` <= `d`.`private_revision_id`)))) group by `b`.`node_id`));

--
-- Definition of view `%PREFIX%v_compare_resource_node`
--

DROP TABLE IF EXISTS `%PREFIX%v_compare_resource_node`;
DROP VIEW IF EXISTS `%PREFIX%v_compare_resource_node`;
CREATE   VIEW `%PREFIX%v_compare_resource_node` AS select `a`.`version_id` AS `version_id`,`a`.`revision_id` AS `revision_id`,`a`.`node_id` AS `node_id`,`a`.`parent_node` AS `parent_node`,`a`.`node_type` AS `node_type`,`a`.`node_class` AS `node_class`,`a`.`node_name` AS `node_name`,`a`.`contents_id` AS `contents_id`,`a`.`disp_seq` AS `disp_seq`,`a`.`del_flag` AS `del_flag`,`a`.`create_user` AS `create_user`,`a`.`create_datetime` AS `create_datetime`,`a`.`update_user` AS `update_user`,`a`.`update_datetime` AS `update_datetime` from `%PREFIX%resource_node` `a` where (concat(`a`.`version_id`,`a`.`revision_id`) = (select max(concat(`b`.`version_id`,`b`.`revision_id`)) AS `max(concat(b.version_id, b.revision_id))` from ((`%PREFIX%resource_node` `b` join `%PREFIX%compare_version` `c`) join `%PREFIX%version` `d`) where ((`a`.`node_id` = `b`.`node_id`) and (`b`.`version_id` = `d`.`version_id`) and (((`b`.`version_id` < `c`.`compare_version_id`) and (`b`.`revision_id` < `d`.`private_revision_id`)) or ((`b`.`version_id` = `c`.`compare_version_id`) and (`b`.`revision_id` <= `d`.`private_revision_id`)))) group by `b`.`node_id`));

--
-- Definition of view `%PREFIX%v_compare_template_node`
--

DROP TABLE IF EXISTS `%PREFIX%v_compare_template_node`;
DROP VIEW IF EXISTS `%PREFIX%v_compare_template_node`;
CREATE   VIEW `%PREFIX%v_compare_template_node` AS select `a`.`version_id` AS `version_id`,`a`.`revision_id` AS `revision_id`,`a`.`node_id` AS `node_id`,`a`.`parent_node` AS `parent_node`,`a`.`node_type` AS `node_type`,`a`.`node_class` AS `node_class`,`a`.`node_name` AS `node_name`,`a`.`contents_id` AS `contents_id`,`a`.`disp_seq` AS `disp_seq`,`a`.`del_flag` AS `del_flag`,`a`.`create_user` AS `create_user`,`a`.`create_datetime` AS `create_datetime`,`a`.`update_user` AS `update_user`,`a`.`update_datetime` AS `update_datetime` from `%PREFIX%template_node` `a` where (concat(`a`.`version_id`,`a`.`revision_id`) = (select max(concat(`b`.`version_id`,`b`.`revision_id`)) AS `max(concat(``b``.``version_id``,``b``.``revision_id``))` from ((`%PREFIX%template_node` `b` join `%PREFIX%compare_version` `c`) join `%PREFIX%version` `d`) where ((`a`.`node_id` = `b`.`node_id`) and (`b`.`version_id` = `d`.`version_id`) and (((`b`.`version_id` < `c`.`compare_version_id`) and (`b`.`revision_id` < `d`.`private_revision_id`)) or ((`b`.`version_id` = `c`.`compare_version_id`) and (`b`.`revision_id` <= `d`.`private_revision_id`)))) group by `b`.`node_id`));

--
-- Definition of view `%PREFIX%v_compare_widget_node`
--

DROP TABLE IF EXISTS `%PREFIX%v_compare_widget_node`;
DROP VIEW IF EXISTS `%PREFIX%v_compare_widget_node`;
CREATE   VIEW `%PREFIX%v_compare_widget_node` AS select `a`.`version_id` AS `version_id`,`a`.`revision_id` AS `revision_id`,`a`.`node_id` AS `node_id`,`a`.`parent_node` AS `parent_node`,`a`.`node_type` AS `node_type`,`a`.`node_class` AS `node_class`,`a`.`node_name` AS `node_name`,`a`.`contents_id` AS `contents_id`,`a`.`disp_seq` AS `disp_seq`,`a`.`del_flag` AS `del_flag`,`a`.`create_user` AS `create_user`,`a`.`create_datetime` AS `create_datetime`,`a`.`update_user` AS `update_user`,`a`.`update_datetime` AS `update_datetime` from `%PREFIX%widget_node` `a` where (concat(`a`.`version_id`,`a`.`revision_id`) = (select max(concat(`b`.`version_id`,`b`.`revision_id`)) AS `max(concat(``b``.``version_id``,``b``.``revision_id``))` from ((`%PREFIX%widget_node` `b` join `%PREFIX%compare_version` `c`) join `%PREFIX%version` `d`) where ((`a`.`node_id` = `b`.`node_id`) and (`b`.`version_id` = `d`.`version_id`) and (((`b`.`version_id` < `c`.`compare_version_id`) and (`b`.`revision_id` < `d`.`private_revision_id`)) or ((`b`.`version_id` = `c`.`compare_version_id`) and (`b`.`revision_id` <= `d`.`private_revision_id`)))) group by `b`.`node_id`));

--
-- Definition of view `%PREFIX%v_current_version`
--

DROP TABLE IF EXISTS `%PREFIX%v_current_version`;
DROP VIEW IF EXISTS `%PREFIX%v_current_version`;
CREATE   VIEW `%PREFIX%v_current_version` AS select `b`.`version_id` AS `reserved_version_id`,`b`.`publication_datetime_u` AS `publication_datetime_u`,if(`c`.`version_id`,`c`.`version_id`,`d`.`version_id`) AS `current_version_id`,if(`c`.`version_id`,`c`.`version`,`d`.`version`) AS `current_version`,`a`.`working_version_id` AS `working_version_id`,`e`.`version` AS `working_version`,`e`.`private_revision_id` AS `revision_id` from ((((`%PREFIX%current_version` `a` left join `%PREFIX%version` `b` on(((`a`.`reserved_version_id` = `b`.`version_id`) and (`b`.`publication_datetime_u` > unix_timestamp())))) left join `%PREFIX%version` `c` on(((`a`.`reserved_version_id` = `c`.`version_id`) and (`c`.`publication_datetime_u` <= unix_timestamp())))) left join `%PREFIX%version` `d` on((`a`.`current_version_id` = `d`.`version_id`))) left join `%PREFIX%version` `e` on((`a`.`working_version_id` = `e`.`version_id`)));

--
-- Definition of view `%PREFIX%v_preview_article`
--

DROP TABLE IF EXISTS `%PREFIX%v_preview_article`;
DROP VIEW IF EXISTS `%PREFIX%v_preview_article`;
CREATE   VIEW `%PREFIX%v_preview_article` AS select `a`.`article_id` AS `article_id`,`a`.`article_date_t` AS `article_date_t`,`a`.`article_date_u` AS `article_date_u`,`a`.`category_id` AS `category_id`,`a`.`keywords` AS `keywords`,`a`.`description` AS `description`,`a`.`publication` AS `publication`,`a`.`title` AS `title`,`a`.`title_img_file` AS `title_img_file`,`a`.`description_flag` AS `description_flag`,`a`.`external_link` AS `external_link`,`a`.`external_window` AS `external_window`,`a`.`url` AS `url`,`a`.`contents` AS `contents`,`a`.`del_flag` AS `del_flag`,`a`.`folder_id` AS `folder_id`,`a`.`reserve1` AS `reserve1`,`a`.`reserve2` AS `reserve2`,`a`.`reserve3` AS `reserve3`,`a`.`create_user` AS `create_user`,`a`.`create_datetime` AS `create_datetime`,`a`.`update_user` AS `update_user`,`a`.`update_datetime` AS `update_datetime`,concat(`a`.`article_date_u`,`a`.`article_id`) AS `article_date`,`b`.`node_name` AS `category`,`b`.`color` AS `color`,`b`.`background_color` AS `background_color`,`b`.`icon_file` AS `icon_file` from (`%PREFIX%article` `a` left join `%PREFIX%v_category` `b` on((`a`.`category_id` = `b`.`node_id`))) where ((`a`.`del_flag` = _utf8'0') and (`a`.`publication` in (_utf8'1',_utf8'2')));

--
-- Definition of view `%PREFIX%v_preview_article2`
--

DROP TABLE IF EXISTS `%PREFIX%v_preview_article2`;
DROP VIEW IF EXISTS `%PREFIX%v_preview_article2`;
CREATE   VIEW `%PREFIX%v_preview_article2` AS select `a`.`article_id` AS `article_id`,`a`.`article_date_t` AS `article_date_t`,`a`.`article_date_u` AS `article_date_u`,`a`.`category_id` AS `category_id`,`a`.`keywords` AS `keywords`,`a`.`description` AS `description`,`a`.`publication` AS `publication`,`a`.`title` AS `title`,`a`.`title_img_file` AS `title_img_file`,`a`.`description_flag` AS `description_flag`,`a`.`external_link` AS `external_link`,`a`.`external_window` AS `external_window`,`a`.`url` AS `url`,`a`.`contents` AS `contents`,`a`.`del_flag` AS `del_flag`,`a`.`folder_id` AS `folder_id`,`a`.`reserve1` AS `reserve1`,`a`.`reserve2` AS `reserve2`,`a`.`reserve3` AS `reserve3`,`a`.`create_user` AS `create_user`,`a`.`create_datetime` AS `create_datetime`,`a`.`update_user` AS `update_user`,`a`.`update_datetime` AS `update_datetime`,concat(`a`.`article_date_u`,`a`.`article_id`) AS `article_date`,`b`.`node_name` AS `category`,`b`.`color` AS `color`,`b`.`background_color` AS `background_color`,`b`.`icon_file` AS `icon_file` from (`%PREFIX%article2` `a` left join `%PREFIX%v_category2` `b` on((`a`.`category_id` = `b`.`node_id`))) where ((`a`.`del_flag` = _utf8'0') and (`a`.`publication` in (_utf8'1',_utf8'2')));

--
-- Definition of view `%PREFIX%v_preview_article3`
--

DROP TABLE IF EXISTS `%PREFIX%v_preview_article3`;
DROP VIEW IF EXISTS `%PREFIX%v_preview_article3`;
CREATE   VIEW `%PREFIX%v_preview_article3` AS select `a`.`article_id` AS `article_id`,`a`.`article_date_t` AS `article_date_t`,`a`.`article_date_u` AS `article_date_u`,`a`.`category_id` AS `category_id`,`a`.`keywords` AS `keywords`,`a`.`description` AS `description`,`a`.`publication` AS `publication`,`a`.`title` AS `title`,`a`.`title_img_file` AS `title_img_file`,`a`.`description_flag` AS `description_flag`,`a`.`external_link` AS `external_link`,`a`.`external_window` AS `external_window`,`a`.`url` AS `url`,`a`.`contents` AS `contents`,`a`.`del_flag` AS `del_flag`,`a`.`folder_id` AS `folder_id`,`a`.`reserve1` AS `reserve1`,`a`.`reserve2` AS `reserve2`,`a`.`reserve3` AS `reserve3`,`a`.`create_user` AS `create_user`,`a`.`create_datetime` AS `create_datetime`,`a`.`update_user` AS `update_user`,`a`.`update_datetime` AS `update_datetime`,concat(`a`.`article_date_u`,`a`.`article_id`) AS `article_date`,`b`.`node_name` AS `category`,`b`.`color` AS `color`,`b`.`background_color` AS `background_color`,`b`.`icon_file` AS `icon_file` from (`%PREFIX%article3` `a` left join `%PREFIX%v_category3` `b` on((`a`.`category_id` = `b`.`node_id`))) where ((`a`.`del_flag` = _utf8'0') and (`a`.`publication` in (_utf8'1',_utf8'2')));

--
-- Definition of view `%PREFIX%v_w_contents`
--

DROP TABLE IF EXISTS `%PREFIX%v_w_contents`;
DROP VIEW IF EXISTS `%PREFIX%v_w_contents`;
CREATE   VIEW `%PREFIX%v_w_contents` AS select `a`.`version_id` AS `version_id`,`a`.`revision_id` AS `revision_id`,`a`.`contents_id` AS `contents_id`,`a`.`contents_date` AS `contents_date`,`a`.`template_id` AS `template_id`,`a`.`title` AS `title`,`a`.`breadcrumbs` AS `breadcrumbs`,`a`.`html1` AS `html1`,`a`.`html2` AS `html2`,`a`.`html3` AS `html3`,`a`.`html4` AS `html4`,`a`.`css` AS `css`,`a`.`php` AS `php`,`a`.`keywords` AS `keywords`,`a`.`description` AS `description`,`a`.`external_css` AS `external_css`,`a`.`external_js` AS `external_js`,`a`.`header_element` AS `header_element`,`a`.`del_flag` AS `del_flag`,`a`.`reserve1` AS `reserve1`,`a`.`reserve2` AS `reserve2`,`a`.`reserve3` AS `reserve3`,`a`.`create_user` AS `create_user`,`a`.`create_datetime` AS `create_datetime`,`a`.`update_user` AS `update_user`,`a`.`update_datetime` AS `update_datetime` from `%PREFIX%contents` `a` where (concat(`a`.`version_id`,`a`.`revision_id`) = (select max(concat(`b`.`version_id`,`b`.`revision_id`)) AS `max(concat(b.version_id, b.revision_id))` from ((`%PREFIX%contents` `b` join `%PREFIX%v_current_version` `c`) join `%PREFIX%version` `d`) where ((`a`.`contents_id` = `b`.`contents_id`) and (`b`.`version_id` = `d`.`version_id`) and (((`b`.`version_id` < `c`.`working_version_id`) and (`b`.`revision_id` < `d`.`private_revision_id`)) or ((`b`.`version_id` = `c`.`working_version_id`) and (`b`.`revision_id` <= `d`.`private_revision_id`)))) group by `b`.`contents_id`));

--
-- Definition of view `%PREFIX%v_w_contents_node`
--

DROP TABLE IF EXISTS `%PREFIX%v_w_contents_node`;
DROP VIEW IF EXISTS `%PREFIX%v_w_contents_node`;
CREATE   VIEW `%PREFIX%v_w_contents_node` AS select `a`.`version_id` AS `version_id`,`a`.`revision_id` AS `revision_id`,`a`.`node_id` AS `node_id`,`a`.`parent_node` AS `parent_node`,`a`.`node_type` AS `node_type`,`a`.`node_class` AS `node_class`,`a`.`node_name` AS `node_name`,`a`.`contents_id` AS `contents_id`,`a`.`disp_seq` AS `disp_seq`,`a`.`del_flag` AS `del_flag`,`a`.`create_user` AS `create_user`,`a`.`create_datetime` AS `create_datetime`,`a`.`update_user` AS `update_user`,`a`.`update_datetime` AS `update_datetime` from `%PREFIX%contents_node` `a` where (concat(`a`.`version_id`,`a`.`revision_id`) = (select max(concat(`b`.`version_id`,`b`.`revision_id`)) AS `max(concat(``b``.``version_id``,``b``.``revision_id``))` from ((`%PREFIX%contents_node` `b` join `%PREFIX%v_current_version` `c`) join `%PREFIX%version` `d`) where ((`a`.`node_id` = `b`.`node_id`) and (`b`.`version_id` = `d`.`version_id`) and (((`b`.`version_id` < `c`.`working_version_id`) and (`b`.`revision_id` < `d`.`private_revision_id`)) or ((`b`.`version_id` = `c`.`working_version_id`) and (`b`.`revision_id` <= `d`.`private_revision_id`)))) group by `b`.`node_id`));

--
-- Definition of view `%PREFIX%v_w_resource_node`
--

DROP TABLE IF EXISTS `%PREFIX%v_w_resource_node`;
DROP VIEW IF EXISTS `%PREFIX%v_w_resource_node`;
CREATE   VIEW `%PREFIX%v_w_resource_node` AS select `a`.`version_id` AS `version_id`,`a`.`revision_id` AS `revision_id`,`a`.`node_id` AS `node_id`,`a`.`parent_node` AS `parent_node`,`a`.`node_type` AS `node_type`,`a`.`node_class` AS `node_class`,`a`.`node_name` AS `node_name`,`a`.`file_size` AS `file_size`,`a`.`human_file_size` AS `human_file_size`,`a`.`image_size` AS `image_size`,`a`.`human_image_size` AS `human_image_size`,`a`.`contents_id` AS `contents_id`,`a`.`disp_seq` AS `disp_seq`,`a`.`del_flag` AS `del_flag`,`a`.`create_user` AS `create_user`,`a`.`create_datetime` AS `create_datetime`,`a`.`update_user` AS `update_user`,`a`.`update_datetime` AS `update_datetime` from `%PREFIX%resource_node` `a` where (concat(`a`.`version_id`,`a`.`revision_id`) = (select max(concat(`b`.`version_id`,`b`.`revision_id`)) AS `max(concat(b.version_id, b.revision_id))` from ((`%PREFIX%resource_node` `b` join `%PREFIX%v_current_version` `c`) join `%PREFIX%version` `d`) where ((`a`.`node_id` = `b`.`node_id`) and (`b`.`version_id` = `d`.`version_id`) and (((`b`.`version_id` < `c`.`working_version_id`) and (`b`.`revision_id` < `d`.`private_revision_id`)) or ((`b`.`version_id` = `c`.`working_version_id`) and (`b`.`revision_id` <= `d`.`private_revision_id`)))) group by `b`.`node_id`));

--
-- Definition of view `%PREFIX%v_w_template`
--

DROP TABLE IF EXISTS `%PREFIX%v_w_template`;
DROP VIEW IF EXISTS `%PREFIX%v_w_template`;
CREATE   VIEW `%PREFIX%v_w_template` AS select `a`.`version_id` AS `version_id`,`a`.`revision_id` AS `revision_id`,`a`.`contents_id` AS `contents_id`,`a`.`contents_date` AS `contents_date`,`a`.`template_id` AS `template_id`,`a`.`start_html` AS `start_html`,`a`.`end_html` AS `end_html`,`a`.`css` AS `css`,`a`.`php` AS `php`,`a`.`external_css` AS `external_css`,`a`.`external_js` AS `external_js`,`a`.`header_element` AS `header_element`,`a`.`del_flag` AS `del_flag`,`a`.`reserve1` AS `reserve1`,`a`.`reserve2` AS `reserve2`,`a`.`reserve3` AS `reserve3`,`a`.`create_user` AS `create_user`,`a`.`create_datetime` AS `create_datetime`,`a`.`update_user` AS `update_user`,`a`.`update_datetime` AS `update_datetime` from `%PREFIX%template` `a` where (concat(`a`.`version_id`,`a`.`revision_id`) = (select max(concat(`b`.`version_id`,`b`.`revision_id`)) AS `max(concat(``b``.``version_id``,``b``.``revision_id``))` from ((`%PREFIX%template` `b` join `%PREFIX%v_current_version` `c`) join `%PREFIX%version` `d`) where ((`a`.`contents_id` = `b`.`contents_id`) and (`b`.`version_id` = `d`.`version_id`) and (((`b`.`version_id` < `c`.`working_version_id`) and (`b`.`revision_id` < `d`.`private_revision_id`)) or ((`b`.`version_id` = `c`.`working_version_id`) and (`b`.`revision_id` <= `d`.`private_revision_id`)))) group by `b`.`contents_id`));

--
-- Definition of view `%PREFIX%v_w_template_node`
--

DROP TABLE IF EXISTS `%PREFIX%v_w_template_node`;
DROP VIEW IF EXISTS `%PREFIX%v_w_template_node`;
CREATE   VIEW `%PREFIX%v_w_template_node` AS select `a`.`version_id` AS `version_id`,`a`.`revision_id` AS `revision_id`,`a`.`node_id` AS `node_id`,`a`.`parent_node` AS `parent_node`,`a`.`node_type` AS `node_type`,`a`.`node_class` AS `node_class`,`a`.`node_name` AS `node_name`,`a`.`contents_id` AS `contents_id`,`a`.`disp_seq` AS `disp_seq`,`a`.`del_flag` AS `del_flag`,`a`.`create_user` AS `create_user`,`a`.`create_datetime` AS `create_datetime`,`a`.`update_user` AS `update_user`,`a`.`update_datetime` AS `update_datetime` from `%PREFIX%template_node` `a` where (concat(`a`.`version_id`,`a`.`revision_id`) = (select max(concat(`b`.`version_id`,`b`.`revision_id`)) AS `max(concat(``b``.``version_id``,``b``.``revision_id``))` from ((`%PREFIX%template_node` `b` join `%PREFIX%v_current_version` `c`) join `%PREFIX%version` `d`) where ((`a`.`node_id` = `b`.`node_id`) and (`b`.`version_id` = `d`.`version_id`) and (((`b`.`version_id` < `c`.`working_version_id`) and (`b`.`revision_id` < `d`.`private_revision_id`)) or ((`b`.`version_id` = `c`.`working_version_id`) and (`b`.`revision_id` <= `d`.`private_revision_id`)))) group by `b`.`node_id`));

--
-- Definition of view `%PREFIX%v_w_widget`
--

DROP TABLE IF EXISTS `%PREFIX%v_w_widget`;
DROP VIEW IF EXISTS `%PREFIX%v_w_widget`;
CREATE   VIEW `%PREFIX%v_w_widget` AS select `a`.`version_id` AS `version_id`,`a`.`revision_id` AS `revision_id`,`a`.`contents_id` AS `contents_id`,`a`.`contents_date` AS `contents_date`,`a`.`widget_id` AS `widget_id`,`a`.`html` AS `html`,`a`.`css` AS `css`,`a`.`php` AS `php`,`a`.`del_flag` AS `del_flag`,`a`.`reserve1` AS `reserve1`,`a`.`reserve2` AS `reserve2`,`a`.`reserve3` AS `reserve3`,`a`.`create_user` AS `create_user`,`a`.`create_datetime` AS `create_datetime`,`a`.`update_user` AS `update_user`,`a`.`update_datetime` AS `update_datetime` from `%PREFIX%widget` `a` where (concat(`a`.`version_id`,`a`.`revision_id`) = (select max(concat(`b`.`version_id`,`b`.`revision_id`)) AS `max(concat(``b``.``version_id``,``b``.``revision_id``))` from ((`%PREFIX%widget` `b` join `%PREFIX%v_current_version` `c`) join `%PREFIX%version` `d`) where ((`a`.`contents_id` = `b`.`contents_id`) and (`b`.`version_id` = `d`.`version_id`) and (((`b`.`version_id` < `c`.`working_version_id`) and (`b`.`revision_id` < `d`.`private_revision_id`)) or ((`b`.`version_id` = `c`.`working_version_id`) and (`b`.`revision_id` <= `d`.`private_revision_id`)))) group by `b`.`contents_id`));

--
-- Definition of view `%PREFIX%v_w_widget_node`
--

DROP TABLE IF EXISTS `%PREFIX%v_w_widget_node`;
DROP VIEW IF EXISTS `%PREFIX%v_w_widget_node`;
CREATE   VIEW `%PREFIX%v_w_widget_node` AS select `a`.`version_id` AS `version_id`,`a`.`revision_id` AS `revision_id`,`a`.`node_id` AS `node_id`,`a`.`parent_node` AS `parent_node`,`a`.`node_type` AS `node_type`,`a`.`node_class` AS `node_class`,`a`.`node_name` AS `node_name`,`a`.`contents_id` AS `contents_id`,`a`.`disp_seq` AS `disp_seq`,`a`.`del_flag` AS `del_flag`,`a`.`create_user` AS `create_user`,`a`.`create_datetime` AS `create_datetime`,`a`.`update_user` AS `update_user`,`a`.`update_datetime` AS `update_datetime` from `%PREFIX%widget_node` `a` where (concat(`a`.`version_id`,`a`.`revision_id`) = (select max(concat(`b`.`version_id`,`b`.`revision_id`)) AS `max(concat(``b``.``version_id``,``b``.``revision_id``))` from ((`%PREFIX%widget_node` `b` join `%PREFIX%v_current_version` `c`) join `%PREFIX%version` `d`) where ((`a`.`node_id` = `b`.`node_id`) and (`b`.`version_id` = `d`.`version_id`) and (((`b`.`version_id` < `c`.`working_version_id`) and (`b`.`revision_id` < `d`.`private_revision_id`)) or ((`b`.`version_id` = `c`.`working_version_id`) and (`b`.`revision_id` <= `d`.`private_revision_id`)))) group by `b`.`node_id`));

